﻿$csv_input= Import-Csv -Path "F:\Infra\Scripts\Automation\Inputs\aks_lables_add_input.csv"

$previous_cluster=""
$previous_sub=""
$labels_list=@("application","application_code","environment","owner","project")

foreach( $aks_obj in $csv_input ){
  $cluster_name=$aks_obj.cluster_name
  $rg_grp=$aks_obj.cluster_rg_name
  $subscription=$aks_obj.subscription

  if($previous_cluster -ne $cluster_name){
    az account set --s $subscription
    cmd.exe /c "az aks get-credentials --resource-group $rg_grp --name $cluster_name --admin --overwrite-existing"
    $previous_cluster=$cluster_name
    $previous_sub=$subscription
  }

#  $namespaces_list=""
#  $namespaces_list=kubectl get namespaces -o json | ConvertFrom-Json
#  foreach( $namespace_obj in $namespaces_list.items){
    $namespace=""
    $label_application=$aks_obj.label_application
    $label_application_code=$aks_obj.label_application_code
    $label_environment=$aks_obj.label_environment
    $label_owner=$aks_obj.label_owner
    $label_project=$aks_obj.label_project
    $namespace=$aks_obj.namespace

    foreach($label_name in $labels_list){
      if($label_name -eq "application"){
        kubectl label namespace $namespace application=$label_application --overwrite=true
      }
      elseif($label_name -eq "application_code"){
        kubectl label namespace $namespace application_code=$label_application_code --overwrite=true
      }
      elseif($label_name -eq "environment"){
        kubectl label namespace $namespace environment=$label_environment --overwrite=true
      }
      elseif($label_name -eq "owner"){
        kubectl label namespace $namespace owner=$label_owner --overwrite=true
      }
      elseif($label_name -eq "project"){
        kubectl label namespace $namespace project=$label_project --overwrite=true
      }
      
    }


#  }

}