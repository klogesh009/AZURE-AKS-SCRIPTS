﻿$vms_csv = import-csv "F:\Infra\Scripts\VM Migrate\Disk Migrate\vm_create_details.csv"

$destinationStorageAccountName ="automationpocrgdiag"
$destinationStorageKey = "p0R21WXr7pASrMSP45tQCodrC2qw57PI+5XRx4xYMg0kRp1MNvvz1t94mxEXn4eJ2VgySHN87pSTG3MKD18wFQ=="
$destinationContainer = "vhds"

#$sourceResourceGroupName = "AM-RB-PRDX-SH-FTD-TEST"
#$DestResourceGroupName = "BKPTEST"
#$SourceDiskName = "rbprxstftdvae02-disk"
#$DestinationDiskName = "rbprxstftdvae02-disk-DND-copy"

$deploy = {
   Param($disk_name,$source_rg_name,$SourceSubscription,$StorageAccountName,$storageKey,$Container)
   [Byte[]] $key = (1..16)
   $SecurePassword =Get-Content "F:\Infra\Scripts\azure.txt" | ConvertTo-SecureString -Key $key
   $Credential = new-Object System.Management.Automation.PSCredential ("5035c5b6-a856-4060-88ca-21122c49d5c9", $SecurePassword)
   Login-AzAccount -credential   $Credential -ServicePrincipal -TenantId a095b75b-77a2-4e28-afc2-27edd1d6b0ab -Subscription $SourceSubscription

   $today_Date=Get-Date -Format o
   $today_Date_1=$today_Date.Split('T')[0].replace("-","")
   $managedDisk= Get-AzDisk -ResourceGroupName $source_rg_name -DiskName $disk_name
   $DestinationDiskName = $disk_name+"-copy"

   #Copy to another Subscription
   #Select-AzSubscription -SubscriptionName $SourceSubscription

   #$tags = @{ PROJECT="REBUS"; ENVIRONMENT="DEV-A"; OWNER="INFRASTRUCTURE"; APPLICATION="AZURE KEYVAULT"; COSTCENTERID="NA"; APPLICATION_CODE="PKI" }
   $diskConfig = New-AzDiskConfig -SourceResourceId $managedDisk.id -Location $managedDisk.Location -Tag $managedDisk.Tags -CreateOption Copy

   New-AzDisk -Disk $diskConfig -DiskName $DestinationDiskName -ResourceGroupName $source_rg_name

   Start-Sleep -Seconds 90
   $disk_check = Get-AzDisk -ResourceGroupName $source_rg_name -DiskName $DestinationDiskName
   $i=1
   while(!$disk_check){
      Start-Sleep -Seconds 90
      $disk_check = Get-AzDisk -ResourceGroupName $source_rg_name -DiskName $DestinationDiskName      
      if($i -gt 1){
        break
      }
      $i++
   }
   if($disk_check){
     $vhd_disk_name = $DestinationDiskName + ".vhd"
     $context = New-AzStorageContext -StorageAccountName $StorageAccountName -StorageAccountKey $storageKey
     $sas = Grant-AzDiskAccess -ResourceGroupName $source_rg_name -DiskName $DestinationDiskName -Access Read -DurationInSecond (60*60)
     $blobcopyresult = Start-AzStorageBlobCopy -AbsoluteUri $sas.AccessSAS -DestinationContainer $Container -DestinationBlob $vhd_disk_name -DestinationContext $context
   }
}

foreach ($disks in $vms_csv) {

    $SourceSubscription = $disks.sourcesubscriptionname
    $DestinationSubscription = $disks.SubscriptionName
    $SourceRG = $disks.sourceresourcegroupname
    $SourceVM = $disks.sourcevmname
    $disk_names=@()
    Select-AzSubscription -Subscription $SourceSubscription
    $vm_obj = Get-AzVM -ResourceGroupName $SourceRG -Name $SourceVM
    $disk_names+=$vm_obj.StorageProfile.OsDisk.Name
    foreach($data_disk in $vm_obj.StorageProfile.DataDisks){
      $disk_names+=$data_disk.Name
    }
    foreach($disk_name in $disk_names){
      $j = Start-Job -ScriptBlock $deploy -ArgumentList $disk_name,$SourceRG,$SourceSubscription,$destinationStorageAccountName,$destinationStorageKey,$destinationContainer
    }
    


}

$jobs = Get-Job
$job_result = New-Object System.Collections.ArrayList
while($jobs | Where-Object {$_.State -eq "Running" })
{
    $jobs_completed = $jobs | Where-Object { $_.State -eq "Completed" -and $_.HasMoreData -match "True"}
    foreach( $job in $jobs_completed ){
      $job_id = $job.Id
      $result_1 = Receive-Job -id $job_id
      if($result_1){
        $job_result.Add($result_1)
        $result_1
      }
   }
}




