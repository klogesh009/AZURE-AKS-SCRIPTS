﻿
$context=""
$context_account=(Get-AzContext).Account.Id
if($context_account -ne "5035c5b6-a856-4060-88ca-21122c49d5c9"){
  [Byte[]] $key = (1..16)
       $SecurePassword =Get-Content "F:\Infra\Scripts\azure.txt" | ConvertTo-SecureString -Key $key
       $Credential = new-Object System.Management.Automation.PSCredential ("5035c5b6-a856-4060-88ca-21122c49d5c9", $SecurePassword)
  Login-AzAccount -credential $Credential -ServicePrincipal -TenantId a095b75b-77a2-4e28-afc2-27edd1d6b0ab -Subscription REBUS_TEST
}

$deleteUnattachedDisks=0
$deleteUnattachedVHDs=0

$today_Date=Get-Date -Format o
$directory_path='F:\Infra\Reports\Unattached_DataDisks'
$csv_path=$directory_path+"\Unattached_prod_disks_"+$today_Date.Split('T')[0]+".csv"


$all_subscriptions= Get-AzSubscription | Where-Object {$_.Name -eq "REBUS_PRODUCTION_SHARED_SVCS" -or $_.Name -eq "REBUS_PRODUCTION" -or $_.Name -eq "REBUS_PRODUCTION_COMMON_TOOLS"  }
foreach($current_subscription in $all_subscriptions)
{

 Select-AzSubscription -SubscriptionName $current_subscription.Name

 $outputCollection = @()
 $outputObject = "" | Select subscription,disk_name,rgname,type,managed_by,disk_state,disk_size_in_GB


 $managedDisks = Get-AzDisk
 foreach ($md in $managedDisks) {
    # ManagedBy property stores the Id of the VM to which Managed Disk is attached to
    # If ManagedBy property is $null then it means that the Managed Disk is not attached to a VM
    if($md.ManagedBy -eq $null -and $md.DiskState -eq "Unattached" -and $md.Name -notmatch "ASRReplica"){
        $outputObject.disk_name=""
        $outputObject.rgname=""
        $outputObject.type=""
        $outputObject.managed_by=""
        $outputObject.disk_state=""
        $outputObject.disk_size_in_GB=""
        $outputObject.subscription=""
        if($deleteUnattachedDisks -eq 1){
            
        }
        else{
          $outputObject.disk_name=$md.Name
          $outputObject.rgname=$md.ResourceGroupName
          $outputObject.type="Managed"
          $outputObject.managed_by=$md.ManagedBy
          $outputObject.disk_state=$md.DiskState
          $outputObject.disk_size_in_GB=$md.DiskSizeGB
          $outputObject.subscription=$current_subscription.Name
          
	      Export-Csv -Path $csv_path -inputobject $outputObject -Append -Force -NoTypeInformation
        }
    }




 }
 
} 


Logout-AzAccount
