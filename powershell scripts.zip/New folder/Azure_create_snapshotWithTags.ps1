﻿$vmName="rbsiacotpkold01"
$resourceGroupName="RBSITACORG01"
$subscription="REBUS_TEST"
$location="northeurope"
$disk_name="rbsiacotpkold01-osdisk"
$tags = @{ PROJECT="REBUS"; ENVIRONMENT="SIT-A"; OWNER="CORM"; APPLICATION="IBM BPM Telcom Pack"; COSTCENTERID="NA"; APPLICATION_CODE="TPK" }
Select-AzureRMSubscription -Subscription $subscription
$snapshotName=$disk_name+"-snap01"
#$vm = get-azvm -ResourceGroupName $resourceGroupName -Name $vmName
$disks=Get-AzureRMDisk | Where-Object {$_.Name -eq $disk_name -and $_.Location -eq $location}
$snapshot =  New-AzureRMSnapshotConfig -SourceUri $disks.Id -Location $location -CreateOption copy -tag $tags

New-AzureRMSnapshot  -Snapshot $snapshot -SnapshotName $snapshotName -ResourceGroupName $resourceGroupName 
 
