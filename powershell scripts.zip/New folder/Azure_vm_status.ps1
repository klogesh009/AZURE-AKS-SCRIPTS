﻿Select-AzureRmProfile -Path F:\Infra\Scripts\profile1.json

$outputCollection = @()
$outputObject = "" | Select vm_name,ip_address,status,rg_name,subscription
$today_Date=Get-Date -Format o | foreach {$_ -replace ":", "."}
$directory_path='F:\Infra\Reports\vm_health_check'
 $csv_path=$directory_path+"\vm_status_"+ $today_Date+".csv"

$all_subscriptions= Get-AzureRmSubscription
foreach($current_scubscription in $all_subscriptions)
{
    Select-AzureRmSubscription -SubscriptionName $current_scubscription.Name

    $vms= Get-AzureRmResource | Where-Object {$_.ResourceType -eq  'Microsoft.Compute/virtualMachines'} 
    $AllNetworkInterfaces = Get-AzureRmNetworkInterface
    foreach($vm in $vms)
    {
        $outputObject.vm_name=''
        $outputObject.ip_address=''
        $outputObject.status=''
        $outputObject.rg_name=''
        $outputObject.subscription=''
        $MatchingNic=''
        $NICPrivateIP = @()
        $vm_status = Get-AzureRMVM -ResourceGroupName $vm.ResourceGroupName -Name $vm.ResourceName -Status
        $vmDetails1 = Get-AzureRMVM -ResourceGroupName $vm.ResourceGroupName -Name $vm.ResourceName
        $outputObject.status=[string]$vm_status.Statuses[1].DisplayStatus
        $outputObject.vm_name= $vmDetails1.Name
        $outputObject.rg_name= $vmDetails1.ResourceGroupName
        $outputObject.subscription= $current_scubscription.Name

        foreach($vnic in $vmDetails1.NetworkProfile.NetworkInterfaces) 
        {
            $MatchingNic = $AllNetworkInterfaces | where-object {$_.id -eq $vnic.id}
            $NICPrivateIP += $MatchingNic.IpConfigurations.PrivateIpAddress
        }
        $ip_address = $NICPrivateIP
        
        $outputObject.ip_address=$NICPrivateIP -join "`n"

        Export-Csv -Path $csv_path -inputobject $outputObject -Append -Force

    }




}
