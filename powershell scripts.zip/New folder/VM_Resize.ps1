﻿
$vmlist = Import-Csv F:\Infra\Scripts\Automation\Inputs\VMs.csv

Select-AzSubscription -Subscription 'REBUS_SIT-B_SHARED_SVCS'

foreach ($vm_row in $vmlist)
{
param ($rg_name,$vm_name,$vm_newsize)
  
 $vm = Get-AzVM -ResourceGroupName $rg_name -VM $vm_name
 $vm.HardwareProfile.VmSize = $vm_newsize 
 Update-AzVM -VM $vm_name -ResourceGroupName $rg_name

 Write-Host "Successfully resized $VMName VM to size $NewAzureSize"
 Write-Host "--------------------------------------------"
 
 }
 


 
