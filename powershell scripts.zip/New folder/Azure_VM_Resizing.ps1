﻿$ResourceGroup = "AM-RB-SITB-SS-CYB-RG01" #Provide the resource group name 
$Location = "West Europe (Zone 1)" #Provide the location of the VM
$Type = "Microsoft.Compute/virtualMachines" 
$ProvisioningState = "Succeeded"


$AzVM = Get-AzVM | Select-Object -Property ResourceGroup, Location, Type, ProvisioningState

$VMsList = @("rbsibtestbpvm01") #Provide the VM list that needs to be resized
$NewAzureSize = "Standard_B1s" #Provide the new Azure VM size 

$vm = Get-AzVM -ResourceGroup $ResourceGroup -VM $VM
 $vm.HardwareProfile.VmSize = $NewAzureSize

<#foreach ($VM in $AzVM)
{



$ResourceGroup = $VM.ResourceGroup
$Type = $VM.Type
$Location = $VM.Location
$ProvisioningState = $VM.ProvisioningState

if ($VMsList -contains $VMName)
{ 
 Write-Host "--------------------------------------------"
 Write-Host "Virtual Machine: $VMName"
 Write-Host "ResourceGroup: $ResourceGroup"
 Write-Host "Location: $Location"
 Write-Host "Resource: Type"
 Write-Host "ProvisioningState: $ProvisioningState"
 Write-Host "--------------------------------------------"
 Write-Host "Updating $VMName VMSize"
  
 
 Write-Host "Successfully resized $VMName VM to size $NewAzureSize"
 Write-Host "--------------------------------------------"
 }
 

}

 
 #>