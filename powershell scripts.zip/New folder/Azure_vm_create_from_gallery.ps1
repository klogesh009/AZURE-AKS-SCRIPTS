﻿$vm_name="rbprxsesamvaa04"
$vm_os="Linux"
$vm_image_id="/subscriptions/c87840a5-6710-4aa8-91d4-39fbc87f527d/resourceGroups/SHARED-IMAGE-GALLERY/providers/Microsoft.Compute/galleries/REBUS_IMAGE_GALLERY/images/sailpoint/versions/2345.3.1"

$VMSize = "Standard_B2ms"
$subscription="REBUS_PRODUCTION_SHARED_SVCS"
$LocationName = "WestEurope"
$ResourceGroupName = "AM-RB-PRX-SE-SAM-RG01"
$subnet_id="/subscriptions/c87840a5-6710-4aa8-91d4-39fbc87f527d/resourceGroups/AM-RB-PRDX-SH-SVCS-RG02/providers/Microsoft.Network/virtualNetworks/AM-RB-PRDX-SH-SVCS-VNET02/subnets/AM-RB-PRDX-SH-BASESS-SNET01"
$vm_password="9Uyr3TK&68m7V@#G"


$tags = @{PROJECT="REBUS";APPLICATION="Sailpoint Identity Now";APPLICATION_CODE="SAM";ENVIRONMENT="PRODUCTION - SHARED SERVICES";OWNER="SECURITY";COSTCENTERID="NA";DOMAIN="IT SECURITY";RIGHTSIZE="Y";SL_CATEGORY="Gold";TIER="APP";VENDOR="22";CLUSTER="Active"}

$context_account=(Get-AzContext).Account.Id
if($context_account -ne "5035c5b6-a856-4060-88ca-21122c49d5c9"){
    [Byte[]] $key = (1..16)
   $SecurePassword =Get-Content "F:\Infra\Scripts\azure.txt" | ConvertTo-SecureString -Key $key
   $Credential = new-Object System.Management.Automation.PSCredential ("5035c5b6-a856-4060-88ca-21122c49d5c9", $SecurePassword)
   Login-AzAccount -credential   $Credential -ServicePrincipal -TenantId a095b75b-77a2-4e28-afc2-27edd1d6b0ab -Subscription $subscription
}
else{
  Select-AzSubscription -Subscription $subscription
}


$VMLocalAdminUser = "cloudinfraadmin"
$VMLocalAdminSecurePassword = ConvertTo-SecureString $vm_password -AsPlainText -Force
$ComputerName = $vm_name
$VMName = $vm_name



#$Vnet=Get-AzVirtualNetwork -Name AM-RB-DEMO-RA-APPS-VNET01 
$NICName=$vm_name+"-nic01"
$NIC_check=Get-AzResource -Name $NICName
if(!$NIC_check){
  $NIC = New-AzNetworkInterface -Name $NICName -ResourceGroupName $ResourceGroupName -Location $LocationName -SubnetId $subnet_id -Tag $tags
}
else{
  $NIC = Get-AzNetworkInterface -Name $NICName -ResourceGroupName $ResourceGroupName
}


$Credential = New-Object System.Management.Automation.PSCredential ($VMLocalAdminUser, $VMLocalAdminSecurePassword);

$VirtualMachine = New-AzVMConfig -VMName $VMName -VMSize $VMSize
#$VirtualMachine | Set-AzVMPlan -Publisher kali-linux -Product kali-linux -Name kali
if($vm_os -eq "Linux"){
  $VirtualMachine = Set-AzVMOperatingSystem -VM $VirtualMachine -Linux -ComputerName $ComputerName -Credential $Credential
}
elseif($vm_os -eq "Windows"){
  $VirtualMachine = Set-AzVMOperatingSystem -VM $VirtualMachine -Windows -ComputerName $ComputerName -Credential $Credential
}
$VirtualMachine = Add-AzVMNetworkInterface -VM $VirtualMachine -Id $NIC.Id
$VirtualMachine = Set-AzVMSourceImage -VM $VirtualMachine -Id $vm_image_id
#$VirtualMachine = Set-AzVMSourceImage -VM $VirtualMachine -PublisherName "kali-linux" -Offer "kali-linux" -Skus "kali" -Version "2019.2.0"
$VirtualMachine = Set-AzVMOSDisk -VM $VirtualMachine -StorageAccountType Standard_LRS -CreateOption FromImage
#$VirtualMachine = New-AzDiskConfig -SkuName Standard_LRS -CreateOption 'FromImage'
#Set-AzVMDataDisk -VM $VirtualMachine -StorageAccountType Standard_LRS

New-AzVM -ResourceGroupName $ResourceGroupName -Location $LocationName -VM $VirtualMachine -Verbose -Tag $tags
if($? -eq "True"){
  Stop-AzVM -ResourceGroupName $ResourceGroupName -Name $vm_name -Force

  $vm_obj = Get-AzVM -ResourceGroupName $ResourceGroupName -Name $vm_name
  $storageType="Standard_LRS"

  foreach( $data_disk_obj in $vm_obj.StorageProfile.DataDisks ){
    
    $disk_obj =  Get-AzDisk -DiskName $data_disk_obj.Name -ResourceGroupName $ResourceGroupName
    $disk_obj.Sku = [Microsoft.Azure.Management.Compute.Models.DiskSku]::new($storageType)
    $disk_obj | Update-AzDisk

  }
  Start-AzVM -ResourceGroupName $ResourceGroupName -Name $vm_name
}


Logout-AzAccount

