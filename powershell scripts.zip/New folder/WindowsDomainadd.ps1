﻿$input_csv_path=Import-Csv -Path "F:\Infra\Scripts\Automation\Inputs\serverdomainadd.csv"

$context=(Get-AzContext).Subscription
if($context.Id -ne "5035c5b6-a856-4060-88ca-21122c49d5c9"){
   [Byte[]] $key = (1..16)
   $SecurePassword =Get-Content "F:\Infra\Scripts\azure.txt" | ConvertTo-SecureString -Key $key
   $Credential = new-Object System.Management.Automation.PSCredential ("5035c5b6-a856-4060-88ca-21122c49d5c9", $SecurePassword)
   Login-AzAccount -credential   $Credential -ServicePrincipal -TenantId a095b75b-77a2-4e28-afc2-27edd1d6b0ab -Subscription REBUS_TEST
}

add-computer -computername -path input_csv_path -domainname ad.contoso.com –credential AD\adminuser -restart –force
