﻿#Login-AzAccount -TenantId a095b75b-77a2-4e28-afc2-27edd1d6b0ab

# Cross Region Transfer

    $sourceSubscription = "REBUS_PRE-PRODUCTION"
    $sourceStorageAccountName = "amrbppxifstastg01"
    $sourceKey = "PxWYmZj5F4OOPrBr8a30Cj070m4OksPhs1cWRKqBa9kCVIthANanc5RvbvEKxNjUBv0wBvts8PiP51/g0PXDYg=="
    $sourceContainer = "12-2-0-1-oracle"
    $destinationSubscription = "REBUS_SIT-B_TEST"
    $destinationStorageAccountName = "amrbsibcoomsstg02"
    $destinationKey = "WRFTxnbJrY2lVfUoNB/nSD84EmY3KYtM3H0KDxB2hWIkbrsiqy1FOSmV4zvb7/jRb8sZdb7F4HWttVBXiWndNA=="
    $destinationContainerName = "12-2-0-1-oracle"
    
    Select-AzSubscription -Subscription $sourceSubscription
    $sourceContext = New-AzStorageContext –StorageAccountName $sourceStorageAccountName -StorageAccountKey $sourceKey 
    $blobs=Get-AzStorageBlob -Container $sourceContainer -Context $sourceContext

    Select-AzSubscription -Subscription $destinationSubscription
    
    # Destination Storage Account Information #
    
    $destinationContext = New-AzStorageContext –StorageAccountName $destinationStorageAccountName -StorageAccountKey $destinationKey
    foreach($blob in $blobs){
        $blob_name = $blob.Name
        $blobCopy = Start-AzStorageBlobCopy -DestContainer $destinationContainerName -DestContext $destinationContext -SrcBlob $blob_name -Context $sourceContext -SrcContainer $sourceContainer
    }

   $blobs=get-azstorageblob -Container $destinationContainerName -Context $destinationContext
   $blob_status_check="Pending"
   if($blobs){
     while($blob_status_check -eq "Pending"){
       $blob_status_check=""
       foreach ($blob_obj in $blobs){
         $blob_status = Get-AzStorageBlobCopyState -Blob $blob_obj.Name -Container $destinationContainerName -Context $destinationContext
         $blob_obj.Name+"   "+$blob_status.Status
         if($blob_status.Status -eq "Pending"){
           $blob_status_check="Pending"
         }
       }
       Start-Sleep 180
     }

   }  
   
      
    