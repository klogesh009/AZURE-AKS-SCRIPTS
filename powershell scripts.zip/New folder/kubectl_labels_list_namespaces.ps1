﻿$csv_input= Import-Csv -Path "F:\Infra\Scripts\Automation\Inputs\helm_densify_upgrade_input.csv"

$outputObject = "" | Select cluster,cluster_rg,subscription,namespace,Tag_project,Tag_application,Tag_application_code,Tag_owner,Tag_environment,Tag_others

foreach( $aks_obj in $csv_input ){
  $cluster_name=$aks_obj.cluster_name
  $rg_grp=$aks_obj.rg_name
  $subscription=$aks_obj.subscription

  az account set --s $subscription
  cmd.exe /c "az aks get-credentials --resource-group $rg_grp --name $cluster_name --admin --overwrite-existing"
  $namespaces_json=kubectl get namespace -o json | ConvertFrom-Json
  $namespace_labels_list=@()
  foreach( $namespaces_json_obj in $namespaces_json.items ){
    $namespace_name=$namespaces_json_obj.metadata.name
    $namespace_name
    $namespace_labels=$namespaces_json_obj.metadata.labels
    $namespace_labels.PSObject.Properties | ForEach-Object {
        $_.Name
    }
  }

}