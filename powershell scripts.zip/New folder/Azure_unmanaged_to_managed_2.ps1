﻿$vms_csv = import-csv "F:\Infra\Scripts\VM Migrate\Disk Migrate\vm_create_details.csv"
$disk_vhds=@()

$storageAccount_ResourceId = "/subscriptions/84833e4b-da31-46ab-8eca-de2a18064714/resourceGroups/automationpocrg/providers/Microsoft.Storage/storageAccounts/automationpocrgdiag"
$StorageKey = "p0R21WXr7pASrMSP45tQCodrC2qw57PI+5XRx4xYMg0kRp1MNvvz1t94mxEXn4eJ2VgySHN87pSTG3MKD18wFQ=="
$Container = "vhds"

$storageAccount_name=$storageAccount_ResourceId.Split("/")[-1]
$context = New-AzStorageContext -StorageAccountName $storageAccount_name -StorageAccountKey $StorageKey

$storage_blobs=Get-AzStorageBlob -Container $Container -Context $context


$deploy = {
   Param($vhd_uri,$disk_name,$rg_name,$zone,$location,$storageAccountId,$subscription)
   [Byte[]] $key = (1..16)
   $SecurePassword =Get-Content "F:\Infra\Scripts\azure.txt" | ConvertTo-SecureString -Key $key
   $Credential = new-Object System.Management.Automation.PSCredential ("5035c5b6-a856-4060-88ca-21122c49d5c9", $SecurePassword)
   Login-AzAccount -credential   $Credential -ServicePrincipal -TenantId a095b75b-77a2-4e28-afc2-27edd1d6b0ab -Subscription $subscription

   #Convert Unmanaged VHD into Managed disks in Destination

$storageType = 'Standard_LRS'

$sourceVHDURI = $vhd_uri
$rg_obj = Get-AzResourceGroup -Name $rg_name

if($zone -ne "NA" -and $zone -ne ""){
  $diskConfig = New-AzDiskConfig -AccountType $storageType -Location $location -CreateOption Import -StorageAccountId $storageAccountId -SourceUri $sourceVHDURI -zone $zone -Tag $rg_obj.Tags
}
else{
  $diskConfig = New-AzDiskConfig -AccountType $storageType -Location $location -CreateOption Import -StorageAccountId $storageAccountId -SourceUri $sourceVHDURI -Tag $rg_obj.Tags
}

New-AzDisk -Disk $diskConfig -ResourceGroupName $rg_name -DiskName $disk_name


}

  foreach ($vm_csv_obj in $vms_csv) {
    $disk_vhds=""
    $disk_location = ""
    $Subscription = $vm_csv_obj.SubscriptionName
    Select-AzSubscription -Subscription $Subscription
    #$disk_vhds=$storage_blobs | Where-Object {$_.Name -match $vm_csv_obj.sourcevmname}
    $disk_vhds=$storage_blobs | Where-Object {$_.Name -match "azinfracmdb01"}
    $disk_location = (Get-AzResourceGroup -Name $storageAccount_ResourceId.Split("/")[4]).Location
    Select-AzSubscription -Subscription $vm_csv_obj.SubscriptionName
    foreach( $disk_vhd in $disk_vhds ){
      $disk_vhd_uri=""
      $new_disk_name=""
      $disk_subscription=""
      $disk_name=""
      $disk_vhd_uri=$context.BlobEndPoint+$Container+"/"+$disk_vhd.Name
      #$disk_vhd_uri
      $disk_name=$disk_vhd.Name.TrimEnd("-copy.vhd")
      $new_disk_name=$disk_name.Replace($vm_csv_obj.sourcevmname,$vm_csv_obj.vmName)
      #$new_disk_name
      $disk_subscription=$vm_csv_obj.SubscriptionName   
      
          $j = Start-Job -ScriptBlock $deploy -ArgumentList $disk_vhd_uri,$new_disk_name,$vm_csv_obj.ResourceGroupName,$vm_csv_obj.zone,$disk_location,$storageAccount_ResourceId,$disk_subscription
     
    }
  }
  
$jobs = Get-Job
$job_result = New-Object System.Collections.ArrayList
while($jobs | Where-Object {$_.State -eq "Running" })
{
    $jobs_completed = $jobs | Where-Object { $_.State -eq "Completed" -and $_.HasMoreData -match "True"}
    foreach( $job in $jobs_completed ){
      $job_id = $job.Id
      $result_1 = Receive-Job -id $job_id
      if($result_1){
        $job_result.Add($result_1)
        $result_1
      }
   }
}