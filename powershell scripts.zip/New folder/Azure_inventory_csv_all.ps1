Import-AzureRmContext -Path F:\Infra\Scripts\profile1.json

$outputCollection = @()
$outputObject = "" | Select vm_name,private_ipaddress,public_ipaddress,nic,rg_name,subscription_name,location,sku,offer,os_version,vm_size,vm_status,avset,cores,memory,os_type,os_disk,os_disk_size,os_disk_tier,os_disk_type,data_disk,data_disk_size,data_disk_tier,data_disk_type,key1,value1,key2,value2,key3,value3,key4,value4,key5,value5,rt
$today_Date=Get-Date -Format o
$directory_path='F:\Infra\Inventory\'+$today_Date.Split('T')[0]
if(!(Test-Path -Path $directory_path )){
    New-Item -ItemType directory -Path $directory_path
}
$target_file= $directory_path + "\Consolidated_Inventory_" +$today_Date.Split('T')[0]+".csv"

$all_subscriptions= Get-AzureRmSubscription
foreach($current_scubscription in $all_subscriptions)
{

Select-AzureRmSubscription -SubscriptionName $current_scubscription.Name

$sub_path= '.\' + $current_scubscription.Name + '_profile1.json'


Save-AzureRmProfile -Path $sub_path -Force



$deploy = {

Param($sub_path,$directory_path,$target_file,$subscription_name)

Import-AzureRmContext -Path $sub_path

$today_Date=Get-Date -Format o
$outputCollection = @()
$outputObject = "" | Select vm_name,private_ipaddress,public_ipaddress,nic,rg_name,subscription_name,location,sku,offer,os_version,vm_size,vm_status,avset,cores,memory,os_type,os_disk,os_disk_size,os_disk_tier,os_disk_type,data_disk,data_disk_size,data_disk_tier,data_disk_type,key1,value1,key2,value2,key3,value3,key4,value4,key5,value5,rt

$az_resources = Find-AzureRmResource | where {$_.ResourceType -eq "Microsoft.Compute/virtualMachines"}
$AllDiskObj = Get-AzureRmDisk
$AllPublicIPs�=�get-azurermpublicipaddress
$AllNetworkInterfaces�=�Get-AzureRmNetworkInterface
$AllStorageAccount = Get-AzureRMStorageAccount
foreach ($azureResourceInfo in $az_resources) {

    $trick_disk=0
    $key_temp=""	
    $vmdetails1=""
    $vmdetails1_status=""
    $outputObject.key1=""
    $outputObject.value1=""
    $outputObject.key2=""
    $outputObject.value2=""
    $outputObject.key3=""
    $outputObject.value3=""
    $outputObject.key4=""
    $outputObject.value4=""
    $outputObject.key5=""
    $outputObject.value5=""
    $outputObject.vm_name=""
    $outputObject.rg_name=""
    $outputObject.subscription_name=""
    $outputObject.private_ipaddress=""
    $outputObject.public_ipaddress=""
    $outputObject.nic=""
    $outputObject.vm_size=""
    $outputObject.location=""
    $outputObject.sku=""
    $outputObject.offer=""
    $outputObject.os_version=""
    $outputObject.vm_status=""
    $outputObject.avset=""
    $outputObject.cores=""
    $outputObject.memory=""
    $outputObject.os_type=""
    $outputObject.os_disk=""
    $outputObject.os_disk_size=""
    $outputObject.os_disk_type=""
    $outputObject.os_disk_tier=""
    $outputObject.data_disk=""
    $outputObject.data_disk_size=""
    $outputObject.data_disk_tier=""
    $outputObject.data_disk_type=""
    $outputObject.nic=""
    $outputObject.private_ipaddress=""
    $outputObject.public_ipaddress=""




    $vmdetails1= Get-AzureRMVM -ResourceGroupName $azureResourceInfo.ResourceGroupName -Name $azureResourceInfo.Name
    $vmdetails1_status= Get-AzureRMVM -ResourceGroupName $azureResourceInfo.ResourceGroupName -Name $azureResourceInfo.Name -Status

    ##Location and Size
    $outputObject.vm_size=$vmDetails1.HardwareProfile.VmSize
    $outputObject.location=$vmDetails1.Location

    ##sku,offer,version
    $outputObject.sku=$vmdetails1.StorageProfile.ImageReference.Sku
    $outputObject.offer=$vmdetails1.StorageProfile.ImageReference.Offer
    $outputObject.os_version=$vmdetails1.StorageProfile.ImageReference.Version



##    $nicname=$(($vmDetails1.NetworkProfile.NetworkInterfaces[0]).Id.Split('/')[8])
##    $nicobj=Get-AzureRmNetworkInterface -Name $nicname -ResourceGroupName $azureResourceInfo.ResourceGroupName
    $vm_size=Get-AzureRmVMSize -Location $vmDetails1.Location | Where-Object {$_.Name -eq $outputObject.vm_size}

    ##IP,Status,AVset
    $NICName�=�@()
    $NICPrivateIP�=�@()
    $NICPublicIP =�@()
    $MatchingNic�= ''
    $VMPublicIPID�= ''
    $VMPublicIP�= ''

    foreach($vnic�in�$vmDetails1.NetworkProfile.NetworkInterfaces)�
    {
       $MatchingNic�= $AllNetworkInterfaces | where-object�{$_.id�-eq�$vnic.id}
       $NICName�+=�$MatchingNic.Name
       $NICPrivateIP�+=�$MatchingNic.IpConfigurations.PrivateIpAddress
       if($MatchingNic.IpConfigurations.PublicIpAddress)
       {
            $VMPublicIPID�=�$MatchingNic.IpConfigurations.PublicIpAddress.Id
            $VMPublicIP�=�$AllPublicIPs�|�where-object�{$_.id�-eq�$VMPublicIPID�}
            $NICPublicIP�+=�$VMPublicIP.IPAddress
       }
       
    }
    $outputObject.nic=$NICName -join�"`n"
    $outputObject.private_ipaddress=$NICPrivateIP -join�"`n"
    $outputObject.public_ipaddress=$NICPublicIP -join�"`n"



    $outputObject.vm_status=$vmdetails1_status.Statuses[1].DisplayStatus
    if($vmDetails1.AvailabilitySetReference.Id)
    {
        $outputObject.avset=$vmdetails1.AvailabilitySetReference.Id.Split('/')[8]
    }
     
    ##Cores,Memory,OS
     $outputObject.cores=$vm_size.NumberOfCores
     $outputObject.memory=$vm_size.MemoryInMB/1024
     $outputObject.os_type=$vmDetails1.StorageProfile.OsDisk.OsType

    ##OS Disk name,size,tier and type
    $os_disk_uri = ''
    $os_storage_account_name = ''
    $OSDiskID = ''
    $VMOSDiskObj = ''

            if($vmDetails1.StorageProfile.OsDisk.ManagedDisk -eq $null)
������������{
�               $outputObject.os_disk =�$vmDetails1.StorageProfile.OsDisk.Name
�����           $outputObject.os_disk_size�=�$vmDetails1.StorageProfile.OsDisk.DiskSizeGB 
                $os_disk_uri = $vmDetails1.StorageProfile.OsDisk.vhd.uri
                $os_storage_account_name = $os_disk_uri.split('/')[2].Split('.')[0]  ## To parse the storage account name
                $outputObject.os_disk_tier = ($AllStorageAccount | Where-Object {$_.StorageAccountName -eq $os_storage_account_name}).sku.Tier
                $outputObject.os_disk_type = "Unmanaged Disks"
            }
            else
            {
                $OSDiskID =�$vmDetails1.StorageProfile.OsDisk.ManagedDisk.Id
                $OSDiskName = $vmDetails1.StorageProfile.OsDisk.Name
                $VMOSDiskObj�= $AllDiskObj | where-object�{$_.id�-eq�$OSDiskID}
                if(!$VMOSDiskObj){
                    $VMOSDiskObj� = Get-AzureRmDisk -ResourceGroupName $azureResourceInfo.ResourceGroupName -DiskName $OSDiskName
                }
                $outputObject.os_disk =�$VMOSDiskObj.Name
                $outputObject.os_disk_size�=�$VMOSDiskObj.DiskSizeGB
                $outputObject.os_disk_tier = $VMOSDiskObj.Sku.Tier
                $outputObject.os_disk_type = "Managed Disks"
            }

    
    $DataDiskObj = @()
����$VMDataDisksObj�=�@()
    foreach($DataDisk�in�$vmDetails1.StorageProfile.DataDisks)�
����{
        $VMDataDiskName =�''
��������$VMDataDiskSize�=�0
        $VMDataDiskType = ''
        $VMDataDiskTier = ''
        $DataDiskID = ''
        $data_disk_uri = ''
        $data_storage_account_name = ''
        if($DataDisk.ManagedDisk -eq $null)
        {
           $VMDataDiskName = $DataDisk.Name
           $VMDataDiskSize = $DataDisk.DiskSizeGB
           $data_disk_uri = $DataDisk.vhd.uri
           $data_storage_account_name = $data_disk_uri.split('/')[2].Split('.')[0]  ## To parse the storage account name
           $VMDataDiskTier = ($AllStorageAccount | Where-Object {$_.StorageAccountName -eq $data_storage_account_name}).sku.Tier
           $VMDataDiskType = "Unmanaged Disks"
        }
        else
        {
            $DataDiskName = $DataDisk.Name
            $DataDiskID = $DataDisk.ManagedDisk.Id
            $VMDataDiskObj�= $AllDiskObj | where-object�{$_.id�-eq�$DataDiskID}
            if(!$VMDataDiskObj){
                $VMDataDiskObj�=�Get-AzureRmDisk -ResourceGroupName $azureResourceInfo.ResourceGroupName -DiskName $DataDiskName
            }
            $VMDataDiskName =�$VMDataDiskObj.Name
������������$VMDataDiskSize�=�$VMDataDiskObj.DiskSizeGB
            $VMDataDiskTier = $VMDataDiskObj.Sku.Tier
            $VMDataDiskType = "Managed Disks"
            
        }

        $DataDiskObj += @([pscustomobject]@{'Name'=$VMDataDiskName;'Size'=$VMDataDiskSize;'Type'=$VMDataDiskType;'Tier'=$VMDataDiskTier})
    }�

    $outputObject.data_disk�=�$DataDiskObj.Name�-join�"`n"
    $outputObject.data_disk_size�=�$DataDiskObj.Size�-join�"`n"
    $outputObject.data_disk_tier�=�$DataDiskObj.Tier�-join�"`n"
    $outputObject.data_disk_type�=�$DataDiskObj.Type�-join�"`n"

    ##Tags
	$tags=$azureResourceInfo.tags
	[array]$test=$tags.Keys
	[array]$test1=$tags.Values

	$outputObject.vm_name=$azureResourceInfo.ResourceName
	$outputObject.rg_name=$azureResourceInfo.ResourceGroupName
    $outputObject.subscription_name=$subscription_name
	$outputObject.rt=$azureResourceInfo.ResourceType
	for($i=0;$i -lt $tags.Count;$i=$i+1 )
	{
		$key_temp=$test[$i]
		if($key_temp -match "PROJECT")
		{
			$outputObject.key1 = $key_temp
			$outputObject.value1 = $test1[$i]
		}
		elseif($key_temp -match "ENVIRONMENT")
		{
			$outputObject.key2 = $key_temp
			$outputObject.value2 = $test1[$i]
		}
		elseif($key_temp -match "OWNER")
		{
			$outputObject.key3 = $key_temp
			$outputObject.value3 = $test1[$i]
		}
		elseif($key_temp -match "APPLICATION")
		{
			$outputObject.key4 = $key_temp
			$outputObject.value4 = $test1[$i]
		}
		elseif($key_temp -match "COSTCENTERID")
		{
			$outputObject.key5 = $key_temp
			$outputObject.value5 = $test1[$i]
		}
		else
		{
			$outputObject.key5 = $outputObject.key5 + $test[$i] + ":" + $test1[$i] + ";" 
			
		}
	}
    $current_scubscription=(Get-AzureRmContext).Subscription.Name
    $csv_path=$directory_path+"\Inventory_"+$current_scubscription+"_"+$today_Date.Split('T')[0]+".csv"
	Export-Csv -Path $csv_path -inputobject $outputObject -Append -Force

 }
}

$job = Start-Job -ScriptBlock $deploy -ArgumentList $sub_path,$directory_path,$target_file,$current_scubscription.Name


}

while(Get-Job -State Running)
{
  Start-Sleep -Seconds 5
}

## Consolidate all subscriptions data

$Dir = get-childitem $directory_path -recurse
$csv_files = $Dir | where {$_.Name -match 'inventory'}
$target_file= $directory_path + "\Consolidated_Inventory_" +$today_Date.Split('T')[0]+".csv"

$trick=0;
foreach($file in $csv_files)
{
    $source_file= $directory_path+ "\" + $file.Name
    if($trick -eq 0)
    {
      $content=Get-Content $source_file | select-string -pattern '#TYPE Selected.System.String' -notmatch
      Add-Content $target_file $content
      $trick++
    }
    else
    {
      $content=Get-Content $source_file | select-string -pattern '#TYPE Selected.System.String' -notmatch | select-string -pattern '"vm_name","private_ipaddress"' -notmatch
      Add-Content $target_file $content
    }
    
}