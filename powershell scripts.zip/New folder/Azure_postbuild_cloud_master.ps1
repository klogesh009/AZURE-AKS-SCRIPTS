﻿$input_csv=Import-Csv -Path "F:\Infra\Scripts\Automation\Inputs\master_postbuild_input.csv"

$console_output=@"
1. Diagnostics extension
2. Dynamic to Static nic
3. Locks
4. All
"@
echo $console_output
$option_input = Read-Host 'Please select one option'


$input_csv | ft

Write-Output "Do you want to perform the installation for above? Enter number"
Write-Output "1.Yes`r`n2.No"
$user_input = Read-Host "Option No"
if($user_input -ne "1"){
  exit
}

#Select-AzSubscription -Subscription $subscription

$storageAccount_details_westEurope = @{
    REBUS_MAYA_CEM_PRODUCTION = 'ammyprxifamodset01'
	REBUS_COMPONENT_TEST = 'amrbciaifamodset01'
	REBUS_INSIGHTS_NEW_TEST = 'amrbciaifamodset02'
	REBUS_DEVELOPMENT = 'amrbdeaifamodset01'
	REBUS_INSIGHTS_NEW_DEVELOPMENT = 'amrbdeaifamodset02'
	REBUS_DWH_POC = 'amrbdwhifamodset01'
	'REBUS_PRE-PRODUCTION' = 'amrbppxifamodset01'
	'REBUS_PRE-PRODUCTION_SHARED_SVCS' = 'amrbppxifamodset02'
	REBUS_PRODUCTION = 'amrbprxifamodset01'
	REBUS_PRODUCTION_SHARED_SVCS = 'amrbprxifamodset02'
	REBUS_PRODUCTION_COMMON_TOOLS = 'amrbprxifamodset03'
	REBUS_INSIGHTS_NEW_PRODUCTION = 'amrbprxifamodset04'
	'REBUS_SIT-B_TEST' = 'amrbsibifamodset01'
	'REBUS_INSIGHTS_NEW_SIT-B' = 'amrbsibifamodset02'
	'REBUS_SIT-B_SHARED_SVCS' = 'amrbsibifamodset03'
	REBUS_UAT = 'amrbuaaifamodset01'	
}
$storageAccount_details_northEurope = @{
    REBUS_COMPONENT_TEST = 'durbciaifamodset01'
    'REBUS_PRE-PRODUCTION' = 'durbppxifamodset01'
    REBUS_PRODUCTION = 'durbprxifamodset01'
	REBUS_PRODUCTION_SHARED_SVCS = 'durbprxifamodset02'
	'REBUS_SIT-B_TEST' = 'durbsibifamodset01'
	REBUS_NEW_SHARED_SVCS = 'durbssxifamodset01'
	REBUS_SHARED_SVCS = 'durbssxifamodset02'
    REBUS_MAYA_CEM_POC = 'dumydexifamodset01'
    REBUS_TEST = 'durbdeaifamodset01'
	REBUS_COMMON_TOOLS = 'durbdoxifamodset01'
}



## Function to get the Resource ID
function get_azure_resourceID_with_subscription {

  $IP_Address=$args[0]
  $subscription_id_func=$args[1]
  $break=$false
  $resource_ID="NIL"
  
  $subscription_check=Get-AzSubscription | Where-Object {$_.Name -eq $subscription_id_func} 
  if($subscription_check){
    Select-AzSubscription -Subscription $subscription_id_func -ErrorAction Stop | Out-Null
    foreach($NIC in Get-AzNetworkInterface)
    {
        foreach($IP in $NIC.IpConfigurations)
        {
            if ($IP.PrivateIpAddress -eq $IP_Address)
            {
                $resource_ID=$NIC.VirtualMachine.id
                $break=$true
            }
            if($break -eq $true)
            {
                break
            }
        }
        if($break -eq $true)
        {
            break
        }
    }
    Write-Output  "$resource_ID"
  }
  else{
    Write-Output "NIL"
  }
    
}



## To install the diagnostics extension
$deploy = {
   Param($vmName,$VMresourceGroup,$subscription,$storageAccountName,$storageAccountResourceGroup)
   $csv_path="F:\Infra\Scripts\Automation\Outputs\vm-diagnostics-extension_report.csv"
   $outputCollection = @()
   $outputObject =  "" | Select vm_name,rg_name,subscription,diagnostic_extension,diagnostic_extension_version,diagnostic_extension_state
   
  $context_account=(Get-AzContext).Account.Id
  if($context_account -ne "5035c5b6-a856-4060-88ca-21122c49d5c9"){
     [Byte[]] $key = (1..16)
     $SecurePassword =Get-Content "F:\Infra\Scripts\azure.txt" | ConvertTo-SecureString -Key $key
     $Credential = new-Object System.Management.Automation.PSCredential ("5035c5b6-a856-4060-88ca-21122c49d5c9", $SecurePassword)
     Login-AzAccount -credential   $Credential -ServicePrincipal -TenantId a095b75b-77a2-4e28-afc2-27edd1d6b0ab -Subscription $subscription
   }
   else{
     Select-AzSubscription -Subscription $subscription
   }

   # Get the VM object
  $vm = Get-AzVM -Name $vmName -ResourceGroupName $VMresourceGroup
  $os_type=$vm.StorageProfile.OsDisk.OsType
  $outputObject.vm_name=$vm.Name
  $outputObject.rg_name=$vm.ResourceGroupName
  $outputObject.subscription=$subscription
  $vm.Name,$vm.ResourceGroupName

  if($os_type -eq "Linux"){
    $publicSettings = Get-Content -Path F:\Syed\Scripts\templates\public_settings_LinuxDiagnostic.json
    $publicSettings = $publicSettings.Replace('__DIAGNOSTIC_STORAGE_ACCOUNT__', $storageAccountName)
    $publicSettings = $publicSettings.Replace('__VM_RESOURCE_ID__', $vm.Id)
    $publicSettings = [string]$publicSettings
  }
  elseif($os_type -eq "Windows"){
    $publicSettings_path = "F:\Syed\Scripts\templates\public_settings_WindowsDiagnostic.json"
  }

  
  
  if($os_type -eq "Linux"){ 
    # Generate a SAS token for the agent to use to authenticate with the storage account
    $sasToken = New-AzStorageAccountSASToken -Service Blob,Table -ResourceType Service,Container,Object -Permission "racwdlup" -Context (Get-AzStorageAccount -ResourceGroupName $storageAccountResourceGroup -AccountName $storageAccountName).Context -ExpiryTime $([System.DateTime]::Now.AddYears(20))

    # Build the protected settings (storage account SAS token)
    $protectedSettings="{'storageAccountName': '$storageAccountName', 'storageAccountSasToken': '$sasToken'}"
    $old_ext_install_check = Get-AzVMExtension -ResourceGroupName $VMresourceGroup -VMName $vmName | Where-Object {$_.Name -match "LinuxDiagnostic"}
    if($old_ext_install_check){
      if($old_ext_install_check.TypeHandlerVersion -ne "4.0"){
        Remove-AzVMExtension -ResourceGroupName $VMresourceGroup -VMName $vmName -Name LinuxDiagnostic -Force
        Set-AzVMExtension -ResourceGroupName $VMresourceGroup -VMName $vmName -Location $vm.Location -ExtensionType LinuxDiagnostic -Publisher Microsoft.Azure.Diagnostics -Name LinuxDiagnostic -SettingString $publicSettings -ProtectedSettingString $protectedSettings -TypeHandlerVersion 4.0 
      }
    }
    else{
      Set-AzVMExtension -ResourceGroupName $VMresourceGroup -VMName $vmName -Location $vm.Location -ExtensionType LinuxDiagnostic -Publisher Microsoft.Azure.Diagnostics -Name LinuxDiagnostic -SettingString $publicSettings -ProtectedSettingString $protectedSettings -TypeHandlerVersion 4.0 
    }
    
  }
  elseif($os_type -eq "Windows"){
    #Set-AzVMExtension -ResourceGroupName $VMresourceGroup -VMName $vmName -Location $vm.Location -ExtensionType IaaSDiagnostics -Publisher Microsoft.Azure.Diagnostics -Name Microsoft.Insights.VMDiagnosticsSettings -SettingString $publicSettings -ProtectedSettingString $protectedSettings -TypeHandlerVersion 1.5
    $storageAccountKey = (Get-AzStorageAccountKey -ResourceGroupName $storageAccountResourceGroup -Name $storageAccountName)[0].Value
    $old_ext_install_check = Get-AzVMExtension -ResourceGroupName $VMresourceGroup -VMName $vmName | Where-Object {$_.Name -match "Microsoft.Insights.VMDiagnosticsSettings"}
    if($old_ext_install_check){
      if($old_ext_install_check.TypeHandlerVersion -ne "1.5"){
        Remove-AzVMExtension -ResourceGroupName $VMresourceGroup -VMName $vmName -Name Microsoft.Insights.VMDiagnosticsSettings -Force
        Set-AzVMDiagnosticsExtension -ResourceGroupName $VMresourceGroup -VMName $vmName -DiagnosticsConfigurationPath $publicSettings_path -StorageAccountName $storageAccountName -StorageAccountKey $storageAccountKey
      }
    }
    else{
      Set-AzVMDiagnosticsExtension -ResourceGroupName $VMresourceGroup -VMName $vmName -DiagnosticsConfigurationPath $publicSettings_path -StorageAccountName $storageAccountName -StorageAccountKey $storageAccountKey
    }
    
  }

  $ext_install_check = Get-AzVMExtension -ResourceGroupName $VMresourceGroup -VMName $vmName | Where-Object {$_.Name -match "diagnostic"}
  if($ext_install_check){
    $outputObject.diagnostic_extension= $ext_install_check.Name
    $outputObject.diagnostic_extension_version= $ext_install_check.TypeHandlerVersion
    $outputObject.diagnostic_extension_state= $ext_install_check.ProvisioningState
    $outputObject
  }
  else{
    $outputObject.diagnostic_extension="Not Installed"
    $outputObject.diagnostic_extension_version="NA"
    $outputObject.diagnostic_extension_state="NA"
  }
  Export-Csv -Path $csv_path -inputobject $outputObject -Append -Force -NoTypeInformation

}

## Logging into Lock SP

if($option_input -eq "3" -or $option_input -eq "4"){
  $context_account=(Get-AzContext).Account.Id
    if($context_account -ne "34e6895d-60a6-4a1d-b9c8-5e0b3f3c52a0" -or !$context_account){
    #   Logout-AzAccount
       $get_pwd = Get-Content "F:\Infra\Scripts\azure_lock.txt"
       $SecurePassword = ConvertTo-SecureString $get_pwd -AsPlainText -Force
       $Credential = new-Object System.Management.Automation.PSCredential ("34e6895d-60a6-4a1d-b9c8-5e0b3f3c52a0", $SecurePassword)
       Login-AzAccount -credential $Credential -ServicePrincipal -TenantId a095b75b-77a2-4e28-afc2-27edd1d6b0ab -Subscription REBUS_TEST
    }


 foreach( $csv_obj in $input_csv ){
  
  $resource_vm=""
  $vm_obj=""
  $Nic =""
  $resource_ID_get=""
  #$resource_vm = Get-AzResource -Name $csv_obj.vm_name -ResourceType Microsoft.Compute/virtualMachines
  $resource_ID_get= get_azure_resourceID_with_subscription $csv_obj.ips $csv_obj.subscription
  if($resource_ID_get -ne "NIL" -and $resource_ID_get -ne ""){
    $vm_name=$resource_ID_get.Split("/")[-1]
    $vm_rg_name=$resource_ID_get.Split("/")[4]
    $subscription_id=$resource_ID_get.Split("/")[2]
    Select-AzSubscription -Subscription $subscription_id
    $vm_obj=Get-AzVM -ResourceGroupName $vm_rg_name -Name $vm_name
    switch($option_input)
    {
      {($_ -eq "3") -or ($_ -eq "4")} 
      {
        
        $lock_check = Get-AzResourceLock -ResourceName $vm_name -ResourceType Microsoft.Compute/virtualMachines -ResourceGroupName $vm_rg_name
        if($lock_check){
           $resource_name =  $vm_name
           echo "Lock for $resource_name already exists"
        #   $lock_check
        }
        else{
          New-AzResourceLock -LockLevel CanNotDelete -LockName LockVM -ResourceName $vm_name -ResourceType Microsoft.Compute/virtualMachines -ResourceGroupName $vm_rg_name -Force
        }
        
        
      }
    }
    
    
  }
  else{
    $vm_name=$csv_obj.vm_name
    "$vm_name not part of subscription $subscription"
  }
 }
}
Logout-AzAccount


## Logging to different SP

if($option_input -eq "1" -or $option_input -eq "2" -or $option_input -eq "4"){
  $context_account=(Get-AzContext).Account.Id
  if($context_account -ne "5035c5b6-a856-4060-88ca-21122c49d5c9"){
      [Byte[]] $key = (1..16)
     $SecurePassword =Get-Content "F:\Infra\Scripts\azure.txt" | ConvertTo-SecureString -Key $key
     $Credential = new-Object System.Management.Automation.PSCredential ("5035c5b6-a856-4060-88ca-21122c49d5c9", $SecurePassword)
     Login-AzAccount -credential   $Credential -ServicePrincipal -TenantId a095b75b-77a2-4e28-afc2-27edd1d6b0ab -Subscription REBUS_TEST
  }


## Installing diagnostics and coverting nic to Static

 foreach( $csv_obj in $input_csv ){
  $resource_vm=""
  $vm_obj=""
  $Nic =""
  $resource_ID_get=""
  #$resource_vm = Get-AzResource -Name $csv_obj.vm_name -ResourceType Microsoft.Compute/virtualMachines
  $resource_ID_get= get_azure_resourceID_with_subscription $csv_obj.ips $csv_obj.subscription  
  if($resource_ID_get -ne "NIL" -and $resource_ID_get -ne ""){
    $vm_name=$resource_ID_get.Split("/")[-1]
    $vm_rg_name=$resource_ID_get.Split("/")[4]
    $subscription_id=$resource_ID_get.Split("/")[2]
    Select-AzSubscription -Subscription $subscription_id
    $vm_obj=Get-AzVM -ResourceGroupName $vm_rg_name -Name $vm_name
    switch($option_input)
    {
      {($_ -eq "1") -or ($_ -eq "4")} 
      {
        $jobs_running = Get-Job | where {$_.State -eq "Running"}
        while($jobs_running.Count -ge 30){
           Start-Sleep -Seconds 5
           $jobs_running = Get-Job | where {$_.State -eq "Running"}
        }
        $subscription=$csv_obj.subscription
        if($vm_obj.Location -eq "westeurope"){
          $storage_account_name=$storageAccount_details_westEurope[$subscription]
        }
        else{
          $storage_account_name=$storageAccount_details_northEurope[$subscription]
        }
        if($storage_account_name){
          $storage_account_rg=(Get-AzResource -Name $storage_account_name).ResourceGroupName
          $job = Start-Job -ScriptBlock $deploy -ArgumentList $vm_name,$vm_rg_name,$subscription_id,$storage_account_name,$storage_account_rg
        }
        else{
          $csv_obj.subscription
          echo "Storage account not configured for diagnostics extension for this subscription"
        }
      }
      {($_ -eq "2") -or ($_ -eq "4")} 
      {        
        $Nic = Get-AzNetworkInterface -ResourceGroupName $vm_rg_name -Name $vm_obj.NetworkProfile.NetworkInterfaces.id.Split("/")[-1]
        if( $Nic.IpConfigurations[0].PrivateIpAllocationMethod -match "Dynamic" ){
          $Nic.IpConfigurations[0].PrivateIpAllocationMethod = "Static"
          Set-AzNetworkInterface -NetworkInterface $Nic -AsJob
        }
        else{
          echo "$vm_name nic is already in static mode"
        }
      }
      
    }
    
    
  }
  else{
    $ip=$csv_obj.ips
    "$ip not part of subscription $subscription"
  }
 }
}

$jobs = Get-Job
$job_result = New-Object System.Collections.ArrayList
while($jobs | Where-Object {$_.State -eq "Running" })
{
    $jobs_completed = $jobs | Where-Object { $_.State -eq "Completed" -and $_.HasMoreData -match "True"}
    foreach( $job in $jobs_completed ){
      $job_id = $job.Id
      $result_1 = Receive-Job -id $job_id
      if($result_1){
        $job_result.Add($result_1)
        $result_1
      }
   }
}
    $jobs_completed = $jobs | Where-Object { $_.State -eq "Completed" -and $_.HasMoreData -match "True"}
    foreach( $job in $jobs_completed ){
      $job_id = $job.Id
      $result_1 = Receive-Job -id $job_id
      if($result_1){
        $job_result.Add($result_1)
        $result_1
      }
   }

Logout-AzAccount