﻿$csv_input= Import-Csv -Path "F:\Infra\Scripts\Automation\Inputs\aks_cluster_input.csv"

$today_Date=Get-Date -Format o
$directory_path='F:\Infra\Scripts\Automation\Outputs\aks_labels_details\'
$csv_path=$directory_path+"aks_namespaces_labels_details_"+ $today_Date.Split('T')[0]+".csv"

$outputCollection = @()
$outputObject = "" | Select cluster_name,cluster_rg_name,subscription,namespace,label_project,label_application,label_application_code,label_owner,label_environment

foreach( $aks_obj in $csv_input ){
  $outputObject.cluster_name=""
  $outputObject.cluster_rg_name=""
  $outputObject.subscription=""
  $cluster_name=$aks_obj.cluster_name
  $rg_grp=$aks_obj.rg_name
  $subscription=$aks_obj.subscription
  $outputObject.cluster_name=$cluster_name
  $outputObject.cluster_rg_name=$rg_grp
  $outputObject.subscription=$subscription
  az account set --s $subscription
  cmd.exe /c "az aks get-credentials --resource-group $rg_grp --name $cluster_name --admin --overwrite-existing"

  $namespaces_list=""
  $namespaces_list=kubectl get namespaces -o json | ConvertFrom-Json
  foreach( $namespace_obj in $namespaces_list.items){
    $label_properties=""
    $outputObject.namespace=""
    
    $outputObject.namespace=$namespace_obj.metadata.name
    if($namespace_obj.metadata.labels){
      $label_properties=$namespace_obj.metadata.labels | Get-Member -MemberType Properties
      $outputObject.label_project=""
      $outputObject.label_application=""
      $outputObject.label_application_Code=""
      $outputObject.label_environment=""
      $outputObject.label_owner=""
      foreach( $label_property in $label_properties ){
        $label_property_name=""
        $label_property_value=""
        
        $label_property_name=$label_property.Name
        $label_property_value=$namespace_obj.metadata.labels.$label_property_name
        if($label_property_name -eq "application"){
          $outputObject.label_application=$label_property_value
        }
        elseif($label_property_name -eq "application_code"){
          $outputObject.label_application_Code=$label_property_value
        }
        elseif($label_property_name -eq "environment"){
          $outputObject.label_environment=$label_property_value
        }
        elseif($label_property_name -eq "owner"){
          $outputObject.label_owner=$label_property_value
        }
        elseif($label_property_name -eq "project"){
          $outputObject.label_project=$label_property_value
        }
              
      
      }
    }
      Export-Csv -Path $csv_path -inputobject $outputObject -Append -Force -NoTypeInformation
  }
}

#$namespaces_list[0].items[1].metadata.name