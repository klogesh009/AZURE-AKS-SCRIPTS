﻿Import-AzureRmContext -Path F:\Infra\Scripts\profile1.json

$tags = import-csv "F:\Syed\2019\Jan\vm_start.csv"

Select-AzureRmSubscription -SubscriptionName REBUS_TEST

Save-AzureRmProfile -Path .\profile1.json -Force

$az_resources = Find-AzureRmResource | where {$_.ResourceType -eq "Microsoft.Compute/virtualMachines"}



foreach ($tag in $tags) {

$deploy = {
                Param($rgname,$vmname)
                Import-AzureRmContext -Path .\profile1.json
                start-azurermvm -Name $vmname -ResourceGroupName $rgname
                Write-Output ("Started"+"  "+$vmname)
           }


$vm_obj=$az_resources | where-object {$_.ResourceName -eq $tag.VmName}
#Write-Output ($vm_obj.ResourceName+"    "+$vm_obj.ResourceGroupName)

$job = Start-Job -ScriptBlock $deploy -ArgumentList $vm_obj.ResourceGroupName,$vm_obj.ResourceName

}

$jobs = Get-Job
$job_result = New-Object System.Collections.ArrayList
while($jobs | Where-Object {$_.State -eq "Running" })
{
    $jobs_completed = $jobs | Where-Object { $_.State -eq "Completed" -and $_.HasMoreData -match "True"}
    foreach( $job in $jobs_completed ){
      $job_id = $job.Id
      $result_1 = Receive-Job -id $job_id
      if($result_1){
        $job_result.Add($result_1)
        $result_1 -match "Started"
      }
   }
}