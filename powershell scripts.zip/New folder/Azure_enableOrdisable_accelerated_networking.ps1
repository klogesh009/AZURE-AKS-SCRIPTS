﻿#Login-AzAccount -TenantId a095b75b-77a2-4e28-afc2-27edd1d6b0ab
$accelerated_network_input=import-csv -Path "F:\Infra\Scripts\linux\accelerated_nic_input.csv"

$context=(Get-AzContext).Subscription
   if(!$context){
       [Byte[]] $key = (1..16)
       $SecurePassword =Get-Content "F:\Infra\Scripts\azure_nonprod.txt" | ConvertTo-SecureString -Key $key
       $Credential = new-Object System.Management.Automation.PSCredential ("962a8e28-2e38-486f-aa23-0dd7befe0c53", $SecurePassword)
       Login-AzAccount -credential   $Credential -ServicePrincipal -TenantId a095b75b-77a2-4e28-afc2-27edd1d6b0ab -Subscription REBUS_TEST
   }

$accelerated_network_output='F:\Infra\Scripts\linux\accelerated_nic_output.csv'

## Input CSV Columns
##IPs,subscription

#Clear-Content -Path $accelerated_network_output

 function get_azure_resourceID {
  $IP_Address=$args[0]
  $break=$false
  $resource_ID=$null
  
  $subscriptions_list=Get-AzSubscription | Where-Object {$_.Name -notmatch "MAYA" -and $_.Name -notmatch "INSIGHTS" -and $_.Name -notmatch "REBUS_PRODUCTION" -and $_.Name -notmatch "REBUS_DWH_POC"}
  foreach($sub in $subscriptions_list)
  {
    Select-AzSubscription -Subscription $sub.Name -ErrorAction Stop
    foreach($NIC in Get-AzNetworkInterface)
    {
        foreach($IP in $NIC.IpConfigurations)
        {
            if ($IP.PrivateIpAddress -eq $IP_Address)
            {
                $resource_ID=$NIC.VirtualMachine.id
                $break=$true
            }
            if($break -eq $true)
            {
                break
            }
        }
        if($break -eq $true)
        {
            break
        }
    }
    if($break -eq $true)
    {
        break
    }
    
  }
  $resource_ID
}

 function get_azure_resourceID_with_sub {
  $IP_Address=$args[0]
  $subscription=$args[1]
  $break=$false
  $resource_ID=$null
  
    if($subscription -ne "5576cd57-8380-4f15-9f9b-ce99513b2fe9" -and $subscription -ne "63c66a85-58c5-4575-b371-e08257fd691a" -and $subscription -ne "c87840a5-6710-4aa8-91d4-39fbc87f527d" -and $subscription -ne "3a1e46ba-9c92-4cb1-850f-be8d1de51d4a" -and $subscription -ne "e20cb50b-17f1-431f-8f6a-4406e14dd04e"){
      Select-AzSubscription -Subscription $subscription -ErrorAction Stop | Out-Null
    }
    else{
      Write-Output "The Subscription is a Production"
      exit
    }
    foreach($NIC in Get-AzNetworkInterface)
    {
        foreach($IP in $NIC.IpConfigurations)
        {
            if ($IP.PrivateIpAddress -eq $IP_Address)
            {
                $resource_ID=$NIC.VirtualMachine.id
                $break=$true
            }
            if($break -eq $true)
            {
                break
            }
        }
        if($break -eq $true)
        {
            break
        }
    }
    

  Write-Output "$resource_ID"
}

$deploy = {
   Param($vmName,$ResourceGroupName,$subscription,$accelerated_network_output,$enable_disable_input)

   $vmName
   $accelerated_network_status=""
   $nics_list=""
   $vm_obj=""
   $vm_obj_1=""
   $vm_status=""
   $context=(Get-AzContext).Subscription
   (Get-AzContext).Account.Id
   if(!$context){
       [Byte[]] $key = (1..16)
       $SecurePassword =Get-Content "F:\Infra\Scripts\azure_nonprod.txt" | ConvertTo-SecureString -Key $key
       $Credential = new-Object System.Management.Automation.PSCredential ("962a8e28-2e38-486f-aa23-0dd7befe0c53", $SecurePassword)
       Login-AzAccount -credential   $Credential -ServicePrincipal -TenantId a095b75b-77a2-4e28-afc2-27edd1d6b0ab -Subscription $subscription
   }
   else{
       Select-AzSubscription -Subscription $subscription
   }

  $vm_obj = Get-AzVM -ResourceGroupName $ResourceGroupName -Name $vmName
  $vm_obj_1 = Get-AzVM -ResourceGroupName $ResourceGroupName -Name $vmName -Status
  $vm_status=$vm_obj_1.Statuses[1].DisplayStatus
  if($vm_status -notmatch "deallocated"){
   #  Stop-AzVM -ResourceGroup $ResourceGroupName -Name $vmName -force   
   }
  
  $nics_list=$vm_obj.NetworkProfile.NetworkInterfaces
  foreach($nic in $nics_list){
    $nic_name=$nic.Id.Split("/")[-1]
    $nic_rg=$nic.Id.Split("/")[4]
    $nic_obj= Get-AzNetworkInterface -ResourceGroupName $nic_rg -Name $nic_name 
    if($enable_disable_input -eq "1"){
      if( $nic_obj.EnableAcceleratedNetworking -ne $true ){
        $nic_obj.EnableAcceleratedNetworking = $true
        $accelerated_network_status=$nic_obj | Set-AzNetworkInterface
      }
      else{
        Write-Output "Accelerated Networking already enabled"
      }
    }
    elseif($enable_disable_input -eq "2"){
      if( $nic_obj.EnableAcceleratedNetworking -ne $false ){
        $nic_obj.EnableAcceleratedNetworking = $false
        $accelerated_network_status=$nic_obj | Set-AzNetworkInterface
      }
      else{
        Write-Output "Accelerated Networking already disabled"
      }
    }
  }

  if($vm_status -match "running"){
    Start-AzVM -ResourceGroup $ResourceGroupName -Name $vmName
  }
  $nic_obj= Get-AzNetworkInterface -ResourceGroupName $nic_rg -Name $nic_name
  $nic_status=$nic_obj.EnableAcceleratedNetworking

  "$vmName;$nic_name;$nic_status" >> $accelerated_network_output
}


foreach($vm_csv in $accelerated_network_input){
  $resource_ID_get= get_azure_resourceID_with_sub $vm_csv.IPs $vm_csv.subscription
  "VM: "+$resource_ID_get.Split("/")[-1]+" RG: "+$resource_ID_get.Split("/")[4]+" Subscription: "+$vm_csv.subscription
}
Write-Output "Do you want to execute Accelerated Networking for above servers. Enter number?"
Write-Output "1.Yes`r`n2.No"
$user_input = Read-Host "Option No"
Write-Output "Do you want to enable/disable Accelerated Networking for above servers. Enter number?"
Write-Output "1.Enable`r`n2.Disable"
$enable_disable_input = Read-Host "Option No"
if($user_input -ne "1"){
  exit
}


foreach($vm_csv in $accelerated_network_input){
 
   $jobs_running = Get-Job | where {$_.State -eq "Running"}
   while($jobs_running.Count -ge 15){
        Start-Sleep -Seconds 10
        $jobs_running = Get-Job | where {$_.State -eq "Running"}
   }
    
    $resource_ID_get= get_azure_resourceID_with_sub $vm_csv.IPs $vm_csv.subscription
    $resource_ID_get
    $vm_name=$resource_ID_get.Split("/")[-1]
    $vm_rg_name=$resource_ID_get.Split("/")[4]
    $subscription_id=$resource_ID_get.Split("/")[2]

    $j = Start-Job -ScriptBlock $deploy -ArgumentList $vm_name,$vm_rg_name,$subscription_id,$accelerated_network_output,$enable_disable_input

}


$jobs = Get-Job
$job_result = New-Object System.Collections.ArrayList
while($jobs | Where-Object {$_.State -eq "Running" })
{
    $jobs_completed = $jobs | Where-Object { $_.State -eq "Completed" -and $_.HasMoreData -match "True"}
    foreach( $job in $jobs_completed ){
      $job_id = $job.Id
      $result_1 = Receive-Job -id $job_id
      if($result_1){
        $job_result.Add($result_1)
        $result_1
      }
   }
}
$jobs_completed = $jobs | Where-Object { $_.State -eq "Completed" -and $_.HasMoreData -match "True"}
    foreach( $job in $jobs_completed ){
      $job_id = $job.Id
      $result_1 = Receive-Job -id $job_id
      if($result_1){
        $job_result.Add($result_1)
        $result_1
      }
}
