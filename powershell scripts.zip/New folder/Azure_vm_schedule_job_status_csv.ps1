﻿Import-AzureRmContext -Path F:\Infra\Scripts\profile1.json

$outputCollection = @()
$outputObject = "" | Select runbook_name,job_id,job_status,job_executed_date,job_errors

 $date1= (Get-Date -Format g).Split(' ')

$today_Date=Get-Date -Format o | foreach {$_ -replace ":", "."}
$directory_path='F:\Infra\Reports\vm_schedule'
$csv_path=$directory_path+"\Runbook_job_status_"+ $today_Date+".csv"


function runbooks_execute {

$automation_account_name = $args[0]
$automation_account_rg_name = $args[1]
$csv_path = $args[2]



$runbooks= Get-AzureRmAutomationRunbook -AutomationAccountName $automation_account_name -ResourceGroupName $automation_account_rg_name | Where-Object {$_.name -match 'channels' -or $_.name -match 'corm' -or $_.Name -match 'integ' -or $_.Name -match 'CHANNALS'} 

foreach( $runbook in $runbooks)
{
   $job_errors = @()
   $job_obj = ''
   $job_outputs = ''
   $outputObject.runbook_name=''
    $outputObject.job_status=''
    $outputObject.job_id=''
    $outputObject.job_executed_date=''
    $outputObject.job_errors=''

    $outputObject.runbook_name=$runbook.Name
   $job_obj= Get-AzureRmAutomationJob -AutomationAccountName $automation_account_name -ResourceGroupName $automation_account_rg_name -RunbookName $runbook.Name | select -first 1
    $outputObject.job_id=$job_obj.JobId
    $outputObject.job_status=$job_obj.Status
    $outputObject.job_executed_date=$job_obj.StartTime

    $job_outputs= Get-AzureRmAutomationJobOutput -AutomationAccountName $automation_account_name -Id $job_obj.JobId -ResourceGroupName $automation_account_rg_name -Stream "Error"
    
    foreach($job_output_error in $job_outputs)
    {
        if($job_output_error.summary -notmatch 'Please provide a valid tenant')
        {
            $job_errors += (Get-AzureRmAutomationJobOutputRecord -ResourceGroupName $automation_account_rg_name -JobId $job_output_error.JobId -AutomationAccountName $automation_account_name -id $job_output_error.StreamRecordId).Value.Values.Message
        }
        
    }
     
    $outputObject.job_errors= $job_errors -join "`n"
    Export-Csv -Path $csv_path -inputobject $outputObject -Append -Force
}

}

Select-AzureRmSubscription -SubscriptionName 'REBUS_TEST'
runbooks_execute 'RB-CT-AUT01' 'RB-CT-AUT-RG01' $csv_path

Select-AzureRmSubscription -SubscriptionName 'REBUS_SIT-B_SHARED_SVCS'
runbooks_execute 'RB-SIT-B-AUT01' 'AM-RB-SITB-SS-AUTO-RG01' $csv_path