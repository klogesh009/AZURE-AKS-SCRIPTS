﻿$outputCollection = @()
$outputObject = "" 
$directory_path='F:\Infra\Backup_Report_Azure'
$csv_path=$directory_path+"\ASR_list.csv"
$subscriptions = Get-AzSubscription | Where-Object {$_.Name -notmatch "production"}
$outputObject = "" | Select vm_name,vault,ReplicationHealth,subscription

# get the list of recovery services vaults in the subscription
    $VaultObjs = Get-AzRecoveryServicesVault
    foreach ($VaultObj in $VaultObjs) 
    {
        # get and import vault settings file
        Set-AzRecoveryServicesAsrVaultContext -Vault $VaultObj

        # get the list of fabrics in a vault
        $Fabrics = Get-AzRecoveryServicesAsrFabric       
        foreach ($Fabric in $Fabrics)
        {
            # get containers and protected items in a container
            $Containers = Get-AzRecoveryServicesAsrProtectionContainer -Fabric $Fabric
            foreach ($Container in $Containers)
            {
                $items = Get-AzRecoveryServicesAsrReplicationProtectedItem -ProtectionContainer $Container
                foreach ($item in $items)
                {
                    $outputObject.vm_name=""
                    $outputObject.vault=""
                    $outputObject.ReplicationHealth=""
                    $outputObject.subscription=""
                    Export-Csv -Path $csv_path -inputobject $outputObject -Append -Force

                    
                }
            }
        }
   }         