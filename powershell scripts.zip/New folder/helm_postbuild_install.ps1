﻿$csv_input= Import-Csv -Path "F:\Infra\Scripts\Automation\Inputs\helm_install_postbuild.csv"

$csv_input | ft

Write-Output "Components to Install. Enter number?"
Write-Output "1.Densify`r`n2.Dynatrace`r`n3.All"
$user_input_component = Read-Host "Option No"

[Byte[]] $key = (1..16)
   $SecurePassword =Get-Content "F:\Infra\Scripts\azure.txt" | ConvertTo-SecureString -Key $key
   $Credential = new-Object System.Management.Automation.PSCredential ("5035c5b6-a856-4060-88ca-21122c49d5c9", $SecurePassword)
$az_login=az login --service-principal -u $Credential.GetNetworkCredential().UserName -p $Credential.GetNetworkCredential().Password --tenant "a095b75b-77a2-4e28-afc2-27edd1d6b0ab"

<#
if($user_input_component -eq 1 -or $user_input_component -eq 3){
  Write-Output "Do you want to remove existing densify. Enter number?"
  Write-Output "1.Yes`r`n2.No"
  $user_input = Read-Host "Option No"
}
#>
$user_input=2

$kube_state_metrics_path="F:\Infra\Scripts\AKS\CAAS\helm\kube-state-metrics"
$prometheus_path_server="F:\Infra\Scripts\AKS\CAAS\helm\prometheus"
$prometheus_path_nodeExporter="F:\Infra\Scripts\AKS\CAAS\helm\prometheus\node-exporter"
$densify_container_path="F:\Infra\Scripts\AKS\CAAS\helm\container-optimization-data-forwarder"
$dynatrace_path="F:\Infra\Scripts\AKS\CAAS\helm\dynatrace"
$dynatrace_cr_path="F:\Infra\Scripts\AKS\CAAS\helm\dynatrace\cr_files"


foreach( $aks_obj in $csv_input ){
  $env_name=""
  $cluster_name=""
  $rg_grp=""
  $subscription=""
  $taints_added=""
  $taints_name=""
  $cluster_name=$aks_obj.cluster_name
  $rg_grp=$aks_obj.rg_name
  $subscription=$aks_obj.subscription
  $taints_added=$aks_obj.taints_added
  $taints_name=$aks_obj.taints_name
  if($taints_name){ $taints_name=$taints_name.replace(";",",") }

  ## logic to update taints_added to yes_infra for aks code
  if($taints_name -match "aks"){
    if($taints_added -notmatch "yes_infra"){
      $taints_added="yes_infra"
    }
  }


az account set --s $subscription
cmd.exe /c "az aks get-credentials --resource-group $rg_grp --name $cluster_name --admin --overwrite-existing"
#az aks get-credentials --resource-group am-rb-sib-it-ftl-arg01 --name rbsibitftlkaa01 --admin

$env_name=$cluster_name.Substring(2,3)

if($user_input_component -eq 1 -or $user_input_component -eq 3){
  if( $user_input -eq "1" ){
    #Removal of previous resources
    kubectl delete serviceaccount kube-state-metrics -n densify
    kubectl delete service kube-state-metrics -n densify
    kubectl delete deployment kube-state-metrics -n densify
    kubectl delete clusterrole kube-state-metrics
    kubectl delete clusterrolebinding kube-state-metrics
    
    kubectl delete deployment prometheus-deployment -n densify
    kubectl delete service node-exporter -n densify
    kubectl delete daemonset node-exporter -n densify
    kubectl delete service prometheus-service -n densify
    kubectl delete cronjob densify-job -n densify
  
    #kubectl delete namespace densify
  }

  #Installation of kube-state-metrics
  kubectl create namespace densify
  cd $kube_state_metrics_path
  helm install kube-state-metrics -n densify --set taints_added=$taints_added --set env=$env_name .
  
  $pods_kubeMetrics_status=""
  $pods_kubeMetrics=""
  $pods_kubeMetrics_notRunning=$true
  
  while($pods_kubeMetrics_notRunning){
    $pods_kubeMetrics=kubectl get pods -n densify
    $pods_status = $pods_kubeMetrics | Select-String -SimpleMatch "kube-state-metrics" | Select-String -SimpleMatch "Running"
    if($pods_status){
      $pods_kubeMetrics_notRunning=$false
    }else{
      Start-Sleep -Seconds 10
    }
  }
  
  if($?){
    echo "kube-state-metrics installed successfully"
  }
  
  #Installation of Prometheus

  if($taints_added -match "yes"){
    cd $prometheus_path_server
    cmd.exe /c "helm install prometheus --set taints_added=yes --set app_code=$taints_name -n densify --set env=$env_name . --atomic"
  }
  else{
   cd $prometheus_path_server
   cmd.exe /c "helm install prometheus --set taints_added=$taints_added --set app_code={aks,nil} -n densify --set env=$env_name . --atomic"
   #cd $prometheus_path_nodeExporter
   #cmd.exe /c "helm install prometheus-2 --set taints_added=$taints_added --set app_code={aks,nil} -n densify --set env=$env_name . --atomic"
  }

  if($?){
    echo "Prometheus installed successfully"
  }
  
  Start-Sleep -Seconds 10
  
  #Installation of densify-forwarder
  cd $densify_container_path
  helm install densify-forwarder --set taints_added=$taints_added --set config.prometheus.clustername=$cluster_name --set config.zipname="data/$cluster_name" -n densify --set env=$env_name . --atomic
  
  if($?){
    echo "Densify Forwarder installed successfully"
  }
  ##--dry-run --debug
}

if($user_input_component -eq 2 -or $user_input_component -eq 3){
  ## Dynatrace install
  $env_name=$cluster_name.Substring(2,3)
  $owner_name=$cluster_name.Substring(5,2)
  $app_code=$cluster_name.Substring(7,3)
  $helm_dyn_name="dynatrace-"+$env_name+"-"+$app_code
  $helm_dyn_cr_name=$helm_dyn_name+"-cr"
  cd $dynatrace_path
  kubectl create namespace dynatrace

  if($taints_added -match "yes_infra"){
    helm install $helm_dyn_name -n dynatrace --set env=$env_name --set app_code=$app_code --set owner=$owner_name --set namespace_create=no --set tolerations_set=yes_infra . --atomic
  }
  else{
    helm install $helm_dyn_name -n dynatrace --set env=$env_name --set app_code=$app_code --set owner=$owner_name --set namespace_create=no --set tolerations_set=no . --atomic
  }

  Start-Sleep -Seconds 10
  cd $dynatrace_cr_path
  if($taints_added -match "yes"){
    helm install $helm_dyn_cr_name -n dynatrace --set env=$env_name --set tolerations_app_codes=$taints_name --set app_code=$app_code --set owner=$owner_name --set tolerations_set=$taints_added . --atomic
  }
  else{
    helm install $helm_dyn_cr_name -n dynatrace --set env=$env_name --set app_code=$app_code --set owner=$owner_name --set tolerations_set=no . --atomic
    #$helm_dyn_cr_name=$helm_dyn_cr_name+"-ag"
    #helm install $helm_dyn_cr_name -n dynatrace --set env=$env_name --set app_code=$app_code --set owner=$owner_name --set tolerations_set=no --set activeGate_resources.enabled=true --set oneAgent_resources.enabled=false . --atomic
  }
  Start-Sleep -Seconds 20
}


}

az logout

kubectl get pods -n densify
kubectl get pods -n dynatrace