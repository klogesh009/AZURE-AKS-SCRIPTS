﻿$csv_input= Import-Csv -Path "F:\Infra\Scripts\Automation\Inputs\aks_resize_details_input.csv"
#$csv_input= Import-Csv -Path "F:\Syed\2022\Apr\aks_cluster_input.csv"

$today_Date=Get-Date -Format o
$directory_path='F:\Infra\Scripts\Automation\Outputs\aks_cpu_memory_details\'
$csv_path=$directory_path+"aks_cpu_memory_details_"+ $today_Date.Split('T')[0]+".csv"

$outputCollection = @()
$outputObject = "" | Select cluster_name,cluster_rg_name,subscription,namespace,pod_name,container_name,cpu_requests,cpu_limits,memory_requests,memory_limits,pod_status

foreach( $aks_obj in $csv_input ){
  $cluster_name=""
  $rg_grp=""
  $subscription=""

  $cluster_name=$aks_obj.cluster_name
  $rg_grp=$aks_obj.rg_name
  $subscription=$aks_obj.subscription

  az account set --s $subscription
  cmd.exe /c "az aks get-credentials --resource-group $rg_grp --name $cluster_name --admin --overwrite-existing"

  $densify_pods=kubectl get pods -n densify -o json | ConvertFrom-Json
  foreach($densify_pod in $densify_pods.items){ 
    $outputObject.cluster_name=""
    $outputObject.cluster_rg_name=""
    $outputObject.subscription=""
    $outputObject.namespace=""
    $outputObject.pod_name=""
    $outputObject.pod_status=""

    $outputObject.cluster_name=$cluster_name
    $outputObject.cluster_rg_name=$rg_grp
    $outputObject.subscription=$subscription
    if($densify_pod.metadata.name -match "kube-state-metrics" -or $densify_pod.metadata.name -match "prometheus"){
      $ksm_pod_name=$densify_pod.metadata.name
      $outputObject.namespace="densify"
      $outputObject.pod_name=$ksm_pod_name
      
      $ksm_pod=kubectl get pods $ksm_pod_name -n densify -o json | ConvertFrom-Json
      $outputObject.pod_status=$ksm_pod.status.phase
      foreach($ksm_pod_container in $densify_pod.spec.containers){
        
        $outputObject.cpu_requests=""
        $outputObject.cpu_limits=""
        $outputObject.memory_requests=""
        $outputObject.memory_limits=""
        $outputObject.container_name=""
        if($ksm_pod_container.resources){
          $ksm_pod_res=$ksm_pod_container.resources
          $ksm_pod_res_limits_cpu=$ksm_pod_res.limits.cpu
          $ksm_pod_res_limits_memory=$ksm_pod_res.limits.memory
          $ksm_pod_res_requests_cpu=$ksm_pod_res.requests.cpu
          $ksm_pod_res_requests_memory=$ksm_pod_res.requests.memory
          
          $outputObject.cpu_requests=$ksm_pod_res_requests_cpu
          $outputObject.cpu_limits=$ksm_pod_res_limits_cpu
          $outputObject.memory_requests=$ksm_pod_res_requests_memory
          $outputObject.memory_limits=$ksm_pod_res_limits_memory
        }
        $outputObject.container_name=$ksm_pod_container.name
        

        Export-Csv -Path $csv_path -inputobject $outputObject -Append -Force -NoTypeInformation
      }

    }
    
  }

  $dynatrace_pods=kubectl get pods -n dynatrace -o json | ConvertFrom-Json
  foreach($dynatrace_pod in $dynatrace_pods.items){ 
    $outputObject.cluster_name=""
    $outputObject.cluster_rg_name=""
    $outputObject.subscription=""
    $outputObject.namespace=""
    $outputObject.pod_name=""
    $outputObject.pod_status=""

    $outputObject.cluster_name=$cluster_name
    $outputObject.cluster_rg_name=$rg_grp
    $outputObject.subscription=$subscription
    if($dynatrace_pod){
      $dyn_pod_name=$dynatrace_pod.metadata.name
      $outputObject.namespace="dynatrace"
      $outputObject.pod_name=$dyn_pod_name

      $dyn_pod=kubectl get pods $dyn_pod_name -n dynatrace -o json | ConvertFrom-Json
      $outputObject.pod_status=$dyn_pod.status.phase
      foreach($dyn_pod_container in $dynatrace_pod.spec.containers){
        
        $outputObject.cpu_requests=""
        $outputObject.cpu_limits=""
        $outputObject.memory_requests=""
        $outputObject.memory_limits=""
        $outputObject.container_name=""
        if($dyn_pod_container.resources){
          $dyn_pod_res=$dyn_pod_container.resources
          $dyn_pod_res_limits_cpu=$dyn_pod_res.limits.cpu
          $dyn_pod_res_limits_memory=$dyn_pod_res.limits.memory
          $dyn_pod_res_requests_cpu=$dyn_pod_res.requests.cpu
          $dyn_pod_res_requests_memory=$dyn_pod_res.requests.memory
          
          $outputObject.cpu_requests=$dyn_pod_res_requests_cpu
          $outputObject.cpu_limits=$dyn_pod_res_limits_cpu
          $outputObject.memory_requests=$dyn_pod_res_requests_memory
          $outputObject.memory_limits=$dyn_pod_res_limits_memory
        }
        $outputObject.container_name=$dyn_pod_container.name
        
        Export-Csv -Path $csv_path -inputobject $outputObject -Append -Force -NoTypeInformation
      }
    }
  }

  $trident_pods=kubectl get pods -n trident -o json | ConvertFrom-Json
  
  foreach($trident_pod in $trident_pods.items){ 
    $outputObject.cluster_name=""
    $outputObject.cluster_rg_name=""
    $outputObject.subscription=""
    $outputObject.namespace=""
    $outputObject.pod_name=""
    $outputObject.pod_status=""

    $outputObject.cluster_name=$cluster_name
    $outputObject.cluster_rg_name=$rg_grp
    $outputObject.subscription=$subscription
    if($trident_pod){
      $trid_pod_name=$trident_pod.metadata.name
      $outputObject.namespace="trident"
      $outputObject.pod_name=$trid_pod_name

      $trid_pod=kubectl get pods $trid_pod_name -n trident -o json | ConvertFrom-Json
      $outputObject.pod_status=$trid_pod.status.phase
      foreach($trid_pod_container in $trident_pod.spec.containers){
        
        $outputObject.cpu_requests=""
        $outputObject.cpu_limits=""
        $outputObject.memory_requests=""
        $outputObject.memory_limits=""
        $outputObject.container_name=""
        if($trid_pod_container.resources){
          $trid_pod_res=$trid_pod_container.resources
          $outputObject.cpu_requests=$trid_pod_res.requests.cpu
          $outputObject.cpu_limits=$trid_pod_res.limits.cpu
          $outputObject.memory_requests=$trid_pod_res.requests.memory
          $outputObject.memory_limits=$trid_pod_res.limits.memory 
        }
        $outputObject.container_name=$trid_pod_container.name
        
        Export-Csv -Path $csv_path -inputobject $outputObject -Append -Force -NoTypeInformation
      }

      
    }
  }

}