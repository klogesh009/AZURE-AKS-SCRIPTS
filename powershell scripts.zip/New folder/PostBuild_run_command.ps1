﻿## Input Columns : IP,UCD_Relay,subscription
$IPs_input_csv=Import-Csv -Path "F:\Infra\Scripts\linux\postbuild_input_details.csv"

$context=(Get-AzContext).Subscription
if(!$context){
   [Byte[]] $key = (1..16)
   $SecurePassword =Get-Content "F:\Infra\Scripts\azure.txt" | ConvertTo-SecureString -Key $key
   $Credential = new-Object System.Management.Automation.PSCredential ("5035c5b6-a856-4060-88ca-21122c49d5c9", $SecurePassword)
   Login-AzAccount -credential   $Credential -ServicePrincipal -TenantId a095b75b-77a2-4e28-afc2-27edd1d6b0ab -Subscription REBUS_TEST
}

$deploy = {
   Param($rgname,$vmname,$subscription,$relay)

   echo $vmname

   $context=(Get-AzContext).Subscription
   if(!$context){
       [Byte[]] $key = (1..16)
       $SecurePassword =Get-Content "F:\Infra\Scripts\azure.txt" | ConvertTo-SecureString -Key $key
       $Credential = new-Object System.Management.Automation.PSCredential ("5035c5b6-a856-4060-88ca-21122c49d5c9", $SecurePassword)
       Login-AzAccount -credential   $Credential -ServicePrincipal -TenantId a095b75b-77a2-4e28-afc2-27edd1d6b0ab -Subscription $subscription
   }
   else{
       Select-AzSubscription -Subscription $subscription
   }

   $vm_obj=Get-AzVM -ResourceGroupName $rgname -Name $vmname
   $os_type=$vm_obj.StorageProfile.OsDisk.OsType
   
   if($os_type -match "linux"){
      $ucd_agent_name="Lin_"+$vm_obj.tags["ENVIRONMENT"]+"_"+$vm_obj.ResourceGroupName
      $ucd_name = $ucd_agent_name -replace "\s",""
      $ucd_name=$ucd_name.ToUpper()
      echo "Linux"
      $ucd_name+" "+$relay+" "+$vm_obj.Location
      Invoke-AzVMRunCommand -ResourceGroupName $rgname -Name $vmname -CommandId 'RunShellScript' -ScriptPath 'F:\Syed\Scripts\templates\Linux\Non-Prod\Run-command\All-Linux-PostBuild-NonProd.sh' -Parameter @{"UCD_NAME"=$ucd_name;"RELAY"=$relay;"Location"=$vm_obj.Location}
   }
   elseif($os_type -match "windows"){
      $ucd_agent_name="Win_"+$vm_obj.tags["ENVIRONMENT"]+"_"+$vm_obj.ResourceGroupName
      $ucd_name = $ucd_agent_name -replace "\s",""
      $ucd_name=$ucd_name.ToUpper()
      echo "Windows"
      $ucd_name+" "+$relay+" "+$vm_obj.Location
      Invoke-AzVMRunCommand -ResourceGroupName $rgname -Name $vmname -CommandId 'RunPowerShellScript' -ScriptPath 'F:\Syed\Scripts\UCD\ucd_install_windows_blob_v3.ps1' -Parameter @{"UCD_NAME"=$ucd_name;"RELAY"=$relay;"Location"=$vm_obj.Location}
   }
}


foreach($IPs_input in $IPs_input_csv){
    $IP_Address=$IPs_input.IP
    Select-AzSubscription -Subscription $IPs_input.subscription
    $break=$false
    $resource_ID=$null
    foreach($NIC in Get-AzNetworkInterface)
    {
        foreach($IP in $NIC.IpConfigurations)
        {
            if ($IP.PrivateIpAddress -eq $IP_Address)
            {
                $resource_ID=$NIC.VirtualMachine.id
                $break=$true
            }
            if($break -eq $true)
            {
                break
            }
        }
        if($break -eq $true)
        {
            break
        }
    }

    $vm_resource=Get-AzResource -ResourceId $resource_ID
    $resource_ID
    if($vm_resource){

     $j = Start-Job -ScriptBlock $deploy -ArgumentList $vm_resource.ResourceGroupName,$vm_resource.Name,$IPs_input.subscription,$IPs_input.UCD_Relay
    }

}


$jobs = Get-Job
$job_result = New-Object System.Collections.ArrayList
while($jobs | Where-Object {$_.State -eq "Running" })
{
    $jobs_completed = $jobs | Where-Object { $_.State -eq "Completed" -and $_.HasMoreData -match "True"}
    foreach( $job in $jobs_completed ){
      $job_id = $job.Id
      $result_1 = Receive-Job -id $job_id
      if($result_1){
        $job_result.Add($result_1)
        $result_1
      }
   }
}