﻿$storageAccount_ResourceId = '/subscriptions/061336d1-0feb-40ed-8df3-f456532d8f76/resourceGroups/AM-RB-SIB-CO-ICT-DRG01/providers/Microsoft.Storage/storageAccounts/amrbsibcoictddiag01'
$StorageKey = "R1y6EFi4xEEM0Ky1kmaa031Iu8EP8OUeDsNLjCHsmeZ/NAEnEzEU2jSl/Bn036gXvDAYVjj9ythRsNOfDx62Jg=="
$Container = "vhds"
$vhd_uri="https://amrbsibcoictddiag01.blob.core.windows.net/vhds/rbsibcoictrlw01-datadisk06.vhd"
$disk_name="rbsibcoictrlw01-datadisk05"
$disk_rg_name="am-rb-sitb-ra-ict-rg01"
$zone=""
$storageAccount_location="westeurope"

$storageAccount_name=$storageAccount_ResourceId.Split("/")[-1]
$context = New-AzStorageContext -StorageAccountName $storageAccount_name -StorageAccountKey $StorageKey

#$storage_blobs=Get-AzStorageBlob -Container $Container -Context $context

$storageType = 'Standard_LRS'

$sourceVHDURI = $vhd_uri
$rg_obj = Get-AzResourceGroup -Name $disk_rg_name

if($zone -ne "NA" -and $zone -ne ""){
  $diskConfig = New-AzDiskConfig -AccountType $storageType -Location $storageAccount_location -CreateOption Import -StorageAccountId $storageAccount_ResourceId -SourceUri $sourceVHDURI -zone $zone -Tag $rg_obj.Tags
}
else{
  $diskConfig = New-AzDiskConfig -AccountType $storageType -Location $storageAccount_location -CreateOption Import -StorageAccountId $storageAccount_ResourceId -SourceUri $sourceVHDURI -Tag $rg_obj.Tags
}

New-AzDisk -Disk $diskConfig -ResourceGroupName $disk_rg_name -DiskName $disk_name