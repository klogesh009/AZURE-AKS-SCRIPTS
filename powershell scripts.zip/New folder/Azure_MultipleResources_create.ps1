﻿
$resources_csv=Import-Csv -Path "F:\Infra\Scripts\Network\MultipleResources_input.csv"


$temp=az login --service-principal -u "5035c5b6-a856-4060-88ca-21122c49d5c9" -p "f/hXCw59QbWNBsJvfa4qvfboNIvMq49MKY9psGmbmSU=" --tenant "a095b75b-77a2-4e28-afc2-27edd1d6b0ab" 

$context=(Get-AzContext).Subscription
if(!$context){
    Login-AzAccount -TenantId a095b75b-77a2-4e28-afc2-27edd1d6b0ab
}

$console_output=@"
1. Storage Account
2. Availability set
3. Resource Group
"@

echo $console_output
$option_input = Read-Host 'Please select one option'
$location_input = Read-Host 'Location'
$subscription_input = Read-Host 'Subscription ID'


az account set -s $subscription_input
Select-AzSubscription -Subscription $subscription_input

foreach($resource_csv in $resources_csv){
$resource_name=$resource_csv.resource_name
$rg_name=$resource_csv.rg_name
$Tag_Project=$resource_csv.Tag_Project
$Tag_Owner=$resource_csv.Tag_Owner
$Tag_Environment=$resource_csv.Tag_Environment
$Tag_Application=$resource_csv.Tag_Application
$Tag_Application_code=$resource_csv.Tag_Application_code
$Tag_CostcenterID=$resource_csv.Tag_CostcenterID

$tags = @{ PROJECT=$Tag_Project; ENVIRONMENT=$Tag_Environment; OWNER=$Tag_Owner; APPLICATION=$Tag_Application; COSTCENTERID=$Tag_CostcenterID; APPLICATION_CODE=$Tag_Application_code }
#$tags="PROJECT=$Tag_Project ENVIRONMENT=$Tag_Environment OWNER=$Tag_Owner APPLICATION=$Tag_Application COSTCENTERID=$Tag_CostcenterID APPLICATION_CODE=$Tag_Application_code"
switch($option_input)
{
    1
    {      
      New-AzStorageAccount -ResourceGroupName $rg_name -Name $resource_name -Tag $tags -Location $location_input -SkuName Standard_LRS -Kind StorageV2
    }
    2
    {
      az vm availability-set create --name $resource_name --resource-group $rg_name --location $location_input --platform-fault-domain-count 3 --platform-update-domain-count 20 --tags PROJECT=$Tag_Project ENVIRONMENT=$Tag_Environment OWNER=$Tag_Owner APPLICATION=$Tag_Application COSTCENTERID=$Tag_CostcenterID APPLICATION_CODE=$Tag_Application_code
    } 
    3
    {
      New-AzResourceGroup -Name $resource_name -Location $location_input -Tag $tags
    }


}

}




