﻿$console_output=@"
1. UDR
2. NSG
"@
echo $console_output
$option_input = Read-Host 'Please select one option'

$context=(Get-AzContext).Subscription
if(!$context){
    Login-AzAccount -TenantId a095b75b-77a2-4e28-afc2-27edd1d6b0ab
}

#Input Parameters
$subscription=Read-Host 'Subscription Name'
$vnet_name=Read-Host 'AM-RB-PPDX-RA-APPS-VNET02'
$vnet_rg_name=Read-Host 'AM-RB-PPDX-RA-APPS-RG02'
$location=Read-Host 'westeurope'
$name=Read-Host 'AM-RB-PPDX-RA-INTNAS-UDR01'

#Actual Script
Select-AzSubscription -Subscription $subscription
$vnet=Get-AzResource | Where-Object {$_.Name -eq $vnet_name}
if($option_input -eq 1){
  New-AzRouteTable -ResourceGroupName $vnet_rg_name -Name $name -Tag $vnet.Tags -Location $location
}
elseif($option_input -eq 2){
  New-AzNetworkSecurityGroup -ResourceGroupName $vnet_rg_name -Name $name -Tag $vnet.Tags -Location $location
}