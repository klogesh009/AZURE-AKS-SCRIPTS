﻿
$subscription="REBUS_SIT-B_TEST"
$outputCollection = @()
$outputObject = "" | Select Subscription,ResourceGroupName,route_table,route_name,AddressPrefix,NextHopType

$date_form=Get-Date -Format "MM_dd_yyyy+HHmm"
$csv_path="F:\Infra\Scripts\Network\Reports\UDR_details_"+$subscription+"_"+$date_form+".csv"

$context=(Get-AzContext).Subscription
if(!$context){
    Login-AzAccount -TenantId a095b75b-77a2-4e28-afc2-27edd1d6b0ab
}
Select-AzSubscription -Subscription $subscription
$outputObject.Subscription=$subscription

$resource_groups=Get-AzResourceGroup 
foreach($resource_group in $resource_groups){
    $outputObject.ResourceGroupName=""
    $outputObject.ResourceGroupName=$resource_group.ResourceGroupName
    $route_tables=Get-AzRouteTable -ResourceGroupName $resource_group.ResourceGroupName
    foreach($route_table in $route_tables){      
      $outputObject.route_table=""
      $outputObject.route_table=$route_table.Name
      foreach($routes in $route_table.Routes){
        $outputObject.route_name=""
        $outputObject.AddressPrefix=""
        $outputObject.NextHopType=""
        $outputObject.route_name=$routes.Name
        $outputObject.AddressPrefix=$routes.AddressPrefix
        $outputObject.NextHopType=$routes.NextHopType
        Export-Csv -Path $csv_path -inputobject $outputObject -Append -Force -NoTypeInformation
      }
      

    }

}

echo "The report path is $csv_path"