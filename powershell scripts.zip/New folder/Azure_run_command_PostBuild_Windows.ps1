﻿$subscription = Read-Host 'Subscription Name'
$IPs_input_csv=Import-Csv -Path "F:\Infra\Scripts\Windows\windows_postbuild_input.csv"
$break=$false
$resource_ID=$null
foreach($IPs_input in $IPs_input_csv){
    $IP_Address=$IPs_input.ips
    Select-AzSubscription -Subscription $subscription
    foreach($NIC in Get-AzNetworkInterface)
    {
        foreach($IP in $NIC.IpConfigurations)
        {
            if ($IP.PrivateIpAddress -eq $IP_Address)
            {
                $resource_ID=$NIC.VirtualMachine.id
                $break=$true
            }
            if($break -eq $true)
            {
                break
            }
        }
        if($break -eq $true)
        {
            break
        }
    }

    $deploy = {
             Param($rgname,$vmname,$ucd_name,$relay,$subscription,$location,$environment)
             [Byte[]] $key = (1..16)
             $SecurePassword =Get-Content "F:\Infra\Scripts\azure.txt" | ConvertTo-SecureString -Key $key
             $Credential = new-Object System.Management.Automation.PSCredential ("5035c5b6-a856-4060-88ca-21122c49d5c9", $SecurePassword)
             Login-AzAccount -credential $Credential -ServicePrincipal -TenantId a095b75b-77a2-4e28-afc2-27edd1d6b0ab -Subscription $subscription
            $environment
			
            echo $vmname
			$environment = $environment -replace "\s",""
            Invoke-AzVMRunCommand -ResourceGroupName $rgname -Name $vmname -CommandId 'RunPowerShellScript' -ScriptPath 'F:\Syed\Scripts\templates\Windows\All-Windows-PostBuild.ps1' -Parameter @{"NAME"=$ucd_name;"RELAY"=$relay;"LOCATION"=$location;"Environment"=$environment}

	
   }

    $vm_resource=Get-AzResource -ResourceId $resource_ID
    $resource_ID
    if($vm_resource){
     $ucd_agent_name="Win_"+$vm_resource.tags["ENVIRONMENT"]+"_"+$vm_resource.ResourceGroupName
     $ucd_agent_name_1 = $ucd_agent_name -replace "\s",""
     $ucd_agent_name_1=$ucd_agent_name_1.ToUpper()

     $j = Start-Job -ScriptBlock $deploy -ArgumentList $vm_resource.ResourceGroupName,$vm_resource.Name,$ucd_agent_name_1,$IPs_input.UCD_Relay,$subscription,$vm_resource.location,$vm_resource.Tags["ENVIRONMENT"]
    }

}