﻿#$StorageAccountName ="rbcitbcoictstgdiag01"
#$storageKey = "H+jhjPVT9h7dyVjEQ2Gm+GgZmVZGB4sHhBlu+/BedoCdK/CK5SFw8IWjSjdOjBtYK3fubsMTdsB62e1hj9a1LA=="
### Choose Destination storage account
$StorageAccountName ="amrbsibcoictddiag01"
$storageKey = "Df76DOv9wZb3YoHwUu76Ot+Xp3N0b5yHocpCtnd/zY1k8liL05bdIiaJoIQ4jc2ECsa5y1ZVBU4mmXVnF/97Aw=="
$Container = "vhds"
$DiskName="rbsibcoictrlw01-datadisk06"
$Disk_rg_name="am-rb-sitb-ra-ict-rg01"
$Disk_subscription="REBUS_SIT-B_TEST"

Select-AzSubscription -Subscription $Disk_subscription

$vhd_disk_name = $DiskName + ".vhd"
     $context = New-AzStorageContext -StorageAccountName $StorageAccountName -StorageAccountKey $storageKey
     $sas = Grant-AzDiskAccess -ResourceGroupName $Disk_rg_name -DiskName $DiskName -Access Read -DurationInSecond (60*60*60)
     $blobcopyresult = Start-AzStorageBlobCopy -AbsoluteUri $sas.AccessSAS -DestinationContainer $Container -DestinationBlob $vhd_disk_name -DestinationContext $context