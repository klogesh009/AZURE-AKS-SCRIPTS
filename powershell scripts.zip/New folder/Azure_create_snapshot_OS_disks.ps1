﻿#Login-AzAccount -TenantId a095b75b-77a2-4e28-afc2-27edd1d6b0ab

$context=(Get-AzContext).Subscription
if(!$context){
   [Byte[]] $key = (1..16)
   $SecurePassword =Get-Content "F:\Infra\Scripts\azure.txt" | ConvertTo-SecureString -Key $key
   $Credential = new-Object System.Management.Automation.PSCredential ("5035c5b6-a856-4060-88ca-21122c49d5c9", $SecurePassword)
   Login-AzAccount -credential   $Credential -ServicePrincipal -TenantId a095b75b-77a2-4e28-afc2-27edd1d6b0ab -Subscription REBUS_TEST
}


$outputCollection = @()
$outputObject = "" | Select vm_name,snapshot_name
$vm_list = import-csv "F:\Infra\Scripts\Snapshot\snapshot_vmList_input.csv"

$deploy = {
                Param($location,$disk_id,$disk_name,$rg_name,$tags,$subscription)
                [Byte[]] $key = (1..16)
                $SecurePassword =Get-Content "F:\Infra\Scripts\azure.txt" | ConvertTo-SecureString -Key $key
                $Credential = new-Object System.Management.Automation.PSCredential ("5035c5b6-a856-4060-88ca-21122c49d5c9", $SecurePassword)
                Login-AzAccount -credential   $Credential -ServicePrincipal -TenantId a095b75b-77a2-4e28-afc2-27edd1d6b0ab -Subscription $subscription
 
                $disk_name
                $today_Date=Get-Date -Format o
                $today_Date_1=$today_Date.Split('T')[0].replace("-","")
                $outputCollection = @()
                $outputObject = "" | Select snapshot_name,rg_name,disk_name,location,timestamp,user
                $outputObject.snapshot_name=""
                $outputObject.rg_name=""
                $outputObject.disk_name=""
                $outputObject.location=""
                $outputObject.timestamp=""
                $outputObject.user=""
                #$tags = @{ PROJECT=$tags["PROJECT"]; ENVIRONMENT=$tags["ENVIRONMENT"]; OWNER=$tags["OWNER"]; APPLICATION=$tags["APPLICATION"]; COSTCENTERID=$tags["COSTCENTERID"]; APPLICATION_CODE=$tags["APPLICATION_CODE"] }
               # $tags = @{ PROJECT="REBUS"; ENVIRONMENT="PRE PRODUCTION"; OWNER="CORM"; APPLICATION="IBM Operational Decision Manager"; COSTCENTERID="NA"; APPLICATION_CODE="ODM" }
                
                $snapshot =  New-AzSnapshotConfig -SourceUri $disk_id -Location $location -Tag $tags -SkuName Standard_LRS -CreateOption copy
                if($disk_name.Length -gt 65){
                    $disk_parse=$disk_name.Split("_")
                    $disk_name=$disk_parse[0]+"_"+$disk_parse[1]
                }
                $snapshotName = "$disk_name-snap-$today_Date_1"
                New-AzSnapshot -Snapshot $snapshot -SnapshotName $snapshotName -ResourceGroupName $rg_name
                $outputObject.snapshot_name=$snapshotName
                $outputObject.rg_name=$rg_name
                $outputObject.disk_name=$disk_name
                $outputObject.location=$location
                $outputObject.timestamp = Get-Date -format "dd-MM-yyyyTHH:mm"
                $outputObject.user=[System.Security.Principal.WindowsIdentity]::GetCurrent().Name
                $csv_path="F:\Infra\Scripts\Snapshot\snapshot_output_list"+".csv"
	            Export-Csv -Path $csv_path -inputobject $outputObject -Append -Force
         }

$previous_sub=''

foreach ($vm_row in $vm_list) {
   $outputObject.vm_name=""
   if($vm_row.'Expiry_comments(dd-mm-yyyy-Octane/Remedy#ReferenceNo)'){
    $subscription=$vm_row.subscription.trim()
    $snapshot_comment=$vm_row.'Expiry_comments(dd-mm-yyyy-Octane/Remedy#ReferenceNo)'
    if($previous_sub -ne $vm_row.subscription)
    {
        Select-AzSubscription -Subscription $vm_row.subscription.trim()
        $previous_sub=$vm_row.subscription
        $vm_obj_list = Get-AzVM
    }
    $vm_obj = $vm_obj_list | Where-Object { $_.Name -eq $vm_row.vmName}
    if($vm_obj.Count -gt 1){
        foreach($vm_obj1 in $vm_obj){
          $outputObject.vm_name=$vm_obj1.Name
         if($vm_obj1.Name){
          $vm_details = Get-AzVM -ResourceGroupName $vm_obj1.ResourceGroupName -Name $vm_obj1.Name
          $vm_osdisk_id = $vm_details.StorageProfile.OsDisk.ManagedDisk.id
          $tags=$vm_details.tags
          $tags.Add("EXPIRY",$snapshot_comment)
          $job = Start-Job -ScriptBlock $deploy -ArgumentList $vm_details.Location,$vm_osdisk_id,$vm_details.StorageProfile.OsDisk.Name,$vm_details.ResourceGroupName,$tags,$subscription
        
         }
        }
    }
    else{
      $outputObject.vm_name=$vm_obj.Name
      if($vm_obj.Name){
       $vm_details = Get-AzVM -ResourceGroupName $vm_obj.ResourceGroupName -Name $vm_obj.Name        
        
        $vm_osdisk_id = $vm_details.StorageProfile.OsDisk.ManagedDisk.id
        $tags=$vm_details.tags
        $tags.Add("EXPIRY",$snapshot_comment)
        $job = Start-Job -ScriptBlock $deploy -ArgumentList $vm_details.Location,$vm_osdisk_id,$vm_details.StorageProfile.OsDisk.Name,$vm_details.ResourceGroupName,$tags,$subscription
      }

    }
   
   }
   else{
     $vm_name=$vm_row.vmName
     echo "Error : Expiry comments missing for $vm_name Snapshot"
   }

}

$jobs = Get-Job
$job_result = New-Object System.Collections.ArrayList
while($jobs | Where-Object {$_.State -eq "Running" })
{
    $jobs_completed = $jobs | Where-Object { $_.State -eq "Completed" -and $_.HasMoreData -match "True"}
    foreach( $job in $jobs_completed ){
      $job_id = $job.Id
      $result_1 = Receive-Job -id $job_id
      if($result_1){
        $job_result.Add($result_1)
        $result_1
      }
   }
}

Logout-AzAccount