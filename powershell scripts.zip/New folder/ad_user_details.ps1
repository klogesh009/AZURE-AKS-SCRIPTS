﻿import-module activedirectory

$outputCollection = @()
$outputObject = "" | Select Name,id,OU,LastLogonDate

$csv_path="F:\Infra\Reports\ad_users.csv"

$users_all = Get-ADUser -filter *

foreach($user in $users_all)
{
  
  $outputObject.Name=''
    $outputObject.id=''
    $outputObject.OU=''
    $outputObject.LastLogonDate=''

    $outputObject.id= $user.SamAccountName
    $outputObject.OU= ( (($user.DistinguishedName -split ",")[2]) -split "=")[1]

    $user_details = Get-ADUser -identity $outputObject.id -properties *

    $outputObject.Name= $user_details.DisplayName
       
    $outputObject.LastLogonDate= [datetime]::FromFileTime($user_details.lastLogon) 

    Export-Csv -Path $csv_path -inputobject $outputObject -Append -Force
}