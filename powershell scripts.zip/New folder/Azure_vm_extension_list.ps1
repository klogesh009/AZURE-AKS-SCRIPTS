﻿#$subscription="REBUS_PRODUCTION_COMMON_TOOLS"
$input_csv_path=Import-Csv -Path "F:\Infra\Scripts\Automation\Production\vm_DiagnosticsExtension_input.csv"

$outputCollection = @()
   $outputObject =  "" | Select vm_name,rg_name,subscription,diagnostic_extension,diagnostic_extension_version,diagnostic_extension_state
    $csv_path="F:\Syed\2021\Jan\vm_extensions_260120_2.csv"

$prev_subscription=""
    

foreach( $csv_obj in $input_csv_path ){
  
  $subscription=$csv_obj.subscription
  if($prev_subscription -ne $subscription){
    Select-AzSubscription -Subscription $subscription
    $prev_subscription=$subscription
  }

  $outputObject.subscription=$subscription
  $outputObject.vm_name=""
  $outputObject.rg_name=""
  $ext_install_checks =""
  $outputObject.diagnostic_extension=""
  $outputObject.diagnostic_extension_version=""
  $outputObject.diagnostic_extension_state=""
  $diagnostic_extension_1=@()
  $diagnostic_extension_version_1=@()
  $diagnostic_extension_state_1=@()
  $outputObject.vm_name=$csv_obj.vm_name
  $outputObject.rg_name=$csv_obj.rg_name
  $ext_install_checks = Get-AzVMExtension -ResourceGroupName $csv_obj.rg_name -VMName $csv_obj.vm_name | Where-Object {$_.Name -match "diagnostic"}
  if($ext_install_checks){
    foreach( $ext_install_check in $ext_install_checks ){
      $diagnostic_extension_1+=$ext_install_check.Name
      $diagnostic_extension_version_1+=$ext_install_check.TypeHandlerVersion
      $diagnostic_extension_state_1+=$ext_install_check.ProvisioningState
    }
  }
  $outputObject.diagnostic_extension=$diagnostic_extension_1 -join "`n"
  $outputObject.diagnostic_extension_version=$diagnostic_extension_version_1 -join "`n"
  $outputObject.diagnostic_extension_state=$diagnostic_extension_state_1 -join "`n"

  Export-Csv -Path $csv_path -inputobject $outputObject -Append -Force -NoTypeInformation
}

