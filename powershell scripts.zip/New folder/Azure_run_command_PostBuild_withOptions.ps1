﻿$IPs_input_csv=Import-Csv -Path "F:\Infra\Scripts\Automation\Inputs\clone_postbuild_input.csv"

$console_output=@"
1. Splunk Agent
2. Dynatrace Agent
3. All
"@
echo $console_output
$option_input = Read-Host 'Please select one option'
#$subscription_input = Read-Host 'Enter Subscription Name(Optional)'


 function get_azure_resourceID {

  $IP_Address=$args[0]
  $break=$false
  $resource_ID=$null
  
  #$subscriptions_list=Get-AzSubscription | Where-Object {$_.Name -notmatch "MAYA" -and $_.Name -notmatch "INSIGHTS" -and $_.Name -notmatch "REBUS_PRODUCTION"}
  #$subscriptions_list=Get-AzSubscription | Where-Object {$_.Name -notmatch "MAYA" -and $_.Name -notmatch "REBUS_PRODUCTION"}
  $subscriptions_list=Get-AzSubscription
  foreach($sub in $subscriptions_list)
  {
    Select-AzSubscription -Subscription $sub.Name -ErrorAction Stop | Out-Null
    foreach($NIC in Get-AzNetworkInterface)
    {
        foreach($IP in $NIC.IpConfigurations)
        {
            if ($IP.PrivateIpAddress -eq $IP_Address)
            {
                $resource_ID=$NIC.VirtualMachine.id
                $break=$true
            }
            if($break -eq $true)
            {
                break
            }
        }
        if($break -eq $true)
        {
            break
        }
    }
    if($break -eq $true)
    {
        break
    }
    
  }
  if($resource_ID){
    Write-Output "$resource_ID"
  }
  else{
    
    Write-Output "NIL"
  }

 }


  function get_azure_resourceID_with_subscription {

  $IP_Address=$args[0]
  $subscription_id_func=$args[1]
  $break=$false
  $resource_ID="NIL"
  
  $subscription_check=Get-AzSubscription | Where-Object {$_.Id -eq $subscription_id_func} 
  if($subscription_check){
    Select-AzSubscription -Subscription $subscription_id_func -ErrorAction Stop | Out-Null
    foreach($NIC in Get-AzNetworkInterface)
    {
        foreach($IP in $NIC.IpConfigurations)
        {
            if ($IP.PrivateIpAddress -eq $IP_Address)
            {
                $resource_ID=$NIC.VirtualMachine.id
                $break=$true
            }
            if($break -eq $true)
            {
                break
            }
        }
        if($break -eq $true)
        {
            break
        }
    }
    Write-Output  "$resource_ID"
  }
  else{
    Write-Output "NIL"
  }
    

 }


$prev_subscription=""
foreach($IP_input in $IPs_input_csv){

   $jobs_running = Get-Job | where {$_.State -eq "Running"}
   while($jobs_running.Count -ge 15){
        Start-Sleep -Seconds 10
        $jobs_running = Get-Job | where {$_.State -eq "Running"}
   }

  $vm_name=""
  $vm_rg_name=""
  $subscription_id=""
  $resource_ID_get=""
  if($IP_input.subscription -ne ""){
    $resource_ID_get= get_azure_resourceID_with_subscription $IP_input.ips $IP_input.subscription
    if($resource_ID_get -eq "NIL"){
      $resource_ID_get= get_azure_resourceID $IP_input.ips
    }
  }
  else{
    if($prev_subscription -eq ""){
      $resource_ID_get= get_azure_resourceID $IP_input.ips
    }
    else{
      $resource_ID_get= get_azure_resourceID_with_subscription $IP_input.ips $prev_subscription
      if($resource_ID_get -eq "NIL"){
        $resource_ID_get= get_azure_resourceID $IP_input.ips
      }
    }
  }
  if($resource_ID_get -ne "" -and $resource_ID_get -ne "NIL"){
#    echo $resource_ID_get
    $resource_ID_get="$resource_ID_get"
    $vm_name=$resource_ID_get.Split("/")[-1]
    $vm_rg_name=$resource_ID_get.Split("/")[4]
    $subscription_id=$resource_ID_get.Split("/")[2]
    $prev_subscription=$subscription_id
    
    Select-AzSubscription -Subscription $subscription_id
    $vm_obj=Get-AzVM -ResourceGroupName $vm_rg_name -Name $vm_name
    $Tag_environment=$vm_obj.Tags["ENVIRONMENT"]
    $Tag_environment = $Tag_environment -replace "\s",""

    if($vm_obj){
      $os_type=$vm_obj.StorageProfile.OsDisk.OsType
      if($os_type -match "linux"){
 #         Invoke-AzVMRunCommand -ResourceGroupName $vm_rg_name -Name $vm_name -CommandId 'RunShellScript' -ScriptPath 'G:\Syed\Scripts\UCD\ucd_install_linux_v1.sh' -Parameter @{"UCD_NAME"=$ucd_name;"RELAY"=$Relay_1;"Location"=$vm_obj.Location} -asJob
      }
      elseif($os_type -match "windows"){
        switch($option_input)
        {
          {($_ -eq "1") -or ($_ -eq "3")} 
          {
            $vm_name+" "+$vm_rg_name+"  "+"Windows"

            Invoke-AzVMRunCommand -ResourceGroupName $vm_rg_name -Name $vm_name -CommandId 'RunPowerShellScript' -ScriptPath 'F:\Syed\Scripts\Windows\Windows_postBuild_Splunkinstall.ps1' -Parameter @{"Environment"=$Tag_environment;"Location"=$vm_obj.Location} -asJob
            
          }
          {($_ -eq "2") -or ($_ -eq "3")} 
          {
            $vm_name+" "+$vm_rg_name+"  "+"Windows"
            $HostGroup=$IP_input.Dynatrace_HostGroup
            Invoke-AzVMRunCommand -ResourceGroupName $vm_rg_name -Name $vm_name -CommandId 'RunPowerShellScript' -ScriptPath 'F:\Syed\Scripts\Windows\Windows_postBuild_Dynatraceinstall.ps1' -Parameter @{"Environment"=$Tag_environment;"Location"=$vm_obj.Location;"HostGroup"=$HostGroup} -asJob
            
          }
        }
       
        
      }

    }
  }
  else{
        echo "Resource Not found"
        echo "PROCESS FAILURE"
  }    

}

$jobs = Get-Job
$job_result = New-Object System.Collections.ArrayList
while($jobs | Where-Object {$_.State -eq "Running" })
{
    $jobs_completed = $jobs | Where-Object { $_.State -eq "Completed" -and $_.HasMoreData -match "True"}
    foreach( $job in $jobs_completed ){
      $job_id = $job.Id
      $result_1 = Receive-Job -id $job_id
      if($result_1){
        $job_result.Add($result_1)
        $result_1
      }
   }
}
$jobs_completed = $jobs | Where-Object { $_.State -eq "Completed" -and $_.HasMoreData -match "True"}
    foreach( $job in $jobs_completed ){
      $job_id = $job.Id
      $result_1 = Receive-Job -id $job_id
      if($result_1){
        $job_result.Add($result_1)
        $result_1
      }
}

