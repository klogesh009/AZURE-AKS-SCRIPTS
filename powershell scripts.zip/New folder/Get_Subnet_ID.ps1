﻿param (
    [Parameter(Mandatory=$true)][string]$Subscription,
    [Parameter(Mandatory=$false)][string]$UserList
)
$CertPath = 'F:\Infra\037\Azure\ITCO_Certificate.cer'
$ApplicationDisplayName='Jarvis'
$PFXCert = New-Object -TypeName System.Security.Cryptography.X509Certificates.X509Certificate2 -ArgumentList @($CertPath)
$TenantId='a095b75b-77a2-4e28-afc2-27edd1d6b0ab'
Login-AzureRmAccount -ServicePrincipal -CertificateThumbprint $PFXCert.Thumbprint -ApplicationId 'b5467bf3-7127-4718-9955-39cc8a110379' -TenantId $TenantId
$index=0;
$subArray=@((Get-AzureRmSubscription).Count+1)
foreach($sub in Get-AzureRmSubscription){
    echo $index
    $subArray[$index]=$sub.Name
    Write-Host $index $sub.Name
    $index=$index+1;
}
Read-Host $input
if($input -lt $subArray.Count-1){
    Select-AzureRmSubscription -Subscription $subArray[$input]
}