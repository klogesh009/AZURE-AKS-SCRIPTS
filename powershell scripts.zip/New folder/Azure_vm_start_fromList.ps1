﻿$tags = import-csv "F:\Infra\Scripts\Automation\Inputs\vm_start_input.csv"

$vm_list_input = Import-Csv -Path "F:\Syed\Reports\vm_status_with_uptime.csv"

foreach ($tag in $tags) {

$deploy = {
   Param($vm_name,$rg_name,$location,$subscription)
   $context=(Get-AzContext).Subscription
   if(!$context){
       [Byte[]] $key = (1..16)
       $SecurePassword =Get-Content "F:\Infra\Scripts\azure.txt" | ConvertTo-SecureString -Key $key
       $Credential = new-Object System.Management.Automation.PSCredential ("5035c5b6-a856-4060-88ca-21122c49d5c9", $SecurePassword)
       Login-AzAccount -credential   $Credential -ServicePrincipal -TenantId a095b75b-77a2-4e28-afc2-27edd1d6b0ab -Subscription $subscription
   }
   else{
       Select-AzSubscription -Subscription $subscription
   }

   $vm_name
   $vm_status=Get-AzVM -ResourceGroupName $rg_name -Name $vm_name -Status
   if( $vm_status.Statuses[1].DisplayStatus -match "Running"){
     echo "$vm_name already running"
   }
   else{
     start-azvm -Name $vm_name -ResourceGroupName $rg_name
     Write-Output ("Started"+"  "+$vm_name)
   }
              
                
}


#$vm_obj=$vm_list_input | where-object {$_.vm_name -eq $tag.VmName -and $_.subscription -eq $tag.subscription -and $_.rg_name -eq $tag.rgName}
$vm_obj=$vm_list_input | where-object {$_.vm_name -eq $tag.VmName }

 $jobs_running = Get-Job | where {$_.State -eq "Running"}
 while($jobs_running.Count -ge 50){
        Start-Sleep -Seconds 5
        $jobs_running = Get-Job | where {$_.State -eq "Running"}
 }

foreach($vm in $vm_obj){
    $job = Start-Job -ScriptBlock $deploy -ArgumentList $vm.vm_name,$vm.rg_name,$vm.location,$vm.subscription

}

}

$jobs = Get-Job
$job_result = New-Object System.Collections.ArrayList
while($jobs | Where-Object {$_.State -eq "Running" })
{
    $jobs_completed = $jobs | Where-Object { $_.State -eq "Completed" -and $_.HasMoreData -match "True"}
    foreach( $job in $jobs_completed ){
      $job_id = $job.Id
      $result_1 = Receive-Job -id $job_id
      if($result_1){
        $job_result.Add($result_1)
        $result_1
      }
   }
}

