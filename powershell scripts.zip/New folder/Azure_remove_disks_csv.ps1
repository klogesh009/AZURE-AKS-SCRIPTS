﻿$context=(Get-AzContext).Subscription
if(!$context){
  [Byte[]] $key = (1..16)
  $SecurePassword =Get-Content "F:\Infra\Scripts\azure_nonprod.txt" | ConvertTo-SecureString -Key $key
  $Credential = new-Object System.Management.Automation.PSCredential ("962a8e28-2e38-486f-aa23-0dd7befe0c53", $SecurePassword)
  Login-AzAccount -credential $Credential -ServicePrincipal -TenantId a095b75b-77a2-4e28-afc2-27edd1d6b0ab -Subscription REBUS_TEST
}
$disks_csv=Import-Csv -Path "F:\Infra\Scripts\Snapshot\Deletion\Disks\disks_delete_080520.csv"
$disks_csv | ft

Write-Output "Do you want to delete above disks? Enter number"
Write-Output "1.Yes`r`n2.No"
$user_input = Read-Host "Option No"
if($user_input -ne "1"){
  exit
}

$previous_sub=""
foreach($disk_csv in $disks_csv){
  $deploy = {
          Param($rg_name,$disk_name,$subscription)            
           [Byte[]] $key = (1..16)
       $SecurePassword =Get-Content "F:\Infra\Scripts\azure_nonprod.txt" | ConvertTo-SecureString -Key $key
       $Credential = new-Object System.Management.Automation.PSCredential ("962a8e28-2e38-486f-aa23-0dd7befe0c53", $SecurePassword)
       Login-AzAccount -credential   $Credential -ServicePrincipal -TenantId a095b75b-77a2-4e28-afc2-27edd1d6b0ab -Subscription $subscription
       
       "$disk_name $subscription"      
       Remove-AzDisk -DiskName $disk_name -ResourceGroupName $rg_name -Force
    }
  
  $disk_obj=""
   
   $jobs_running = Get-Job | where {$_.State -eq "Running"}
     while($jobs_running.Count -ge 25){
        Start-Sleep -Seconds 10
        $jobs_running = Get-Job | where {$_.State -eq "Running"}
     }

  if($previous_sub -ne $disk_csv.subscription){
    Select-AzSubscription -Subscription $disk_csv.subscription
    $previous_sub=$disk_csv.subscription
  }
  $disk_obj=get-azdisk -ResourceGroupName $disk_csv.rgname -DiskName $disk_csv.disk_name
  if($disk_obj.DiskState -eq "Unattached" -and $disk_obj.Name -notmatch "ASRReplica" -and $disk_obj.Tags["DISK-SHRINK"] -notmatch "OLDDATADISK"){
    $disk_obj.DiskState+"  "+$disk_obj.Name+"  "+$disk_csv.subscription
    $job = Start-Job -ScriptBlock $deploy -ArgumentList $disk_csv.rgname,$disk_obj.Name,$disk_csv.subscription
  }
  else{
    $disk_name=$disk_csv.disk_name
    "$disk_name is not Deleted"
  }
}

$jobs = Get-Job
$job_result = New-Object System.Collections.ArrayList
while($jobs | Where-Object {$_.State -eq "Running" })
{
    $jobs_completed = $jobs | Where-Object { $_.State -eq "Completed" -and $_.HasMoreData -match "True"}
    foreach( $job in $jobs_completed ){
      $job_id = $job.Id
      $result_1 = Receive-Job -id $job_id
      if($result_1){
        $job_result.Add($result_1)
        $result_1
      }
   }
}