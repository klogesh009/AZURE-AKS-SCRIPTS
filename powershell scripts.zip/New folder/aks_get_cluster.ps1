﻿$csv_input= Import-Csv -Path "F:\Infra\Scripts\Automation\Inputs\aks_cluster_input.csv"

$csv_path="F:\Syed\2022\Mar\aks_images_output.csv"

$outputCollection = @()
   $outputObject =  "" | Select cluster_name,rg_name,subscription,images
 

foreach( $aks_obj in $csv_input ){
  $cluster_name=$aks_obj.cluster_name
  $rg_grp=$aks_obj.rg_name
  $subscription=$aks_obj.subscription
    $outputObject.cluster_name=""
   $outputObject.rg_name=""
   $outputObject.subscription=""
   $outputObject.images=""

  $outputObject.cluster_name=$aks_obj.cluster_name
   $outputObject.rg_name=$aks_obj.rg_name
   $outputObject.subscription=$subscription
  az account set --s $subscription
  cmd.exe /c "az aks get-credentials --resource-group $rg_grp --name $cluster_name --admin --overwrite-existing" 
  #$cluster_name+" : "+$rg_grp+" : "+$subscription >> F:\Syed\2022\Mar\repo-check.txt
  $image_output=kubectl get pods -n kube-system -o yaml | Select-String -Pattern "image:"
  $outputObject.images=$image_output -join "`n"

  Export-Csv -Path $csv_path -inputobject $outputObject -Append -Force -NoTypeInformation
}

