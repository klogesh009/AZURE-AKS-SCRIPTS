﻿add-type @"
    using System.Net;
    using System.Security.Cryptography.X509Certificates;
    public class TrustAllCertsPolicy : ICertificatePolicy {
        public bool CheckValidationResult(
            ServicePoint srvPoint, X509Certificate certificate,
            WebRequest request, int certificateProblem) {
            return true;
        }
    }
"@
[System.Net.ServicePointManager]::CertificatePolicy = New-Object TrustAllCertsPolicy

$user = "PasswordIsAuthToken"
$pass= ""
$uri = "https://10.60.102.5:9443/cli/agentCLI"

$secpasswd = ConvertTo-SecureString $pass -AsPlainText -Force
$cred = New-Object -TypeName System.Management.Automation.PSCredential -ArgumentList $user,$secpasswd

$rest_result=Invoke-RestMethod -Uri $uri -Method GET -Credential $cred

Import-AzureRmContext -Path F:\Infra\Scripts\profile1.json


$outputCollection = @()
$outputObject = "" | Select vm_name,ip_address,rg_name,table_name,provisioning_state,status,Last_stop,Last_start,ucd_agent_name,ucd_agent_status
$today_Date=Get-Date -Format o | foreach {$_ -replace ":", "."}
$directory_path='F:\Infra\Reports\vm_schedule'

$csv_path=$directory_path+"\VM_ScheduleStatus_"+$today_Date+".csv"

function vm_execute{

$StorageAccountName = $args[0]
$StorageAccountRGName = $args[1]
$csv_path = $args[2]

$yesterday_3_Date=(get-date (get-date).addDays(-3) -Format o).Split('T')[0]
$start_date_of_log=$yesterday_3_Date + 'T00:00'

$az_resources = Find-AzureRmResource
$AllNetworkInterfaces = Get-AzureRmNetworkInterface


$Ctx=(Get-AzureRmStorageAccount -ResourceGroupName $StorageAccountRGName -Name $StorageAccountName).Context
$stop_tables_1= Get-AzureStorageTable -Context $Ctx | Where-Object {$_.name -match 'channels' -or $_.name -match 'corm' -or $_.Name -match 'integ'} 

$stop_tables = $stop_tables_1 | Where-Object {$_.name -match 'stop' -or $_.Name -match 'SP'}
  
foreach($table_name in $stop_tables.Name)
{
     
  $table = Get-AzureStorageTable -Context $Ctx –Name $table_name
  $table_obj=Get-AzureStorageTableRowAll -table $table
  foreach($a in $table_obj)
  {
    $vm=''
    $vm_status=''
    $MatchingNic=''
    $NICPrivateIP = @()

    $outputObject.vm_name=''
    $outputObject.rg_name=''
    $outputObject.status=''
    $outputObject.provisioning_state=''
    $outputObject.ip_address=''
    $outputObject.table_name=''
    $outputObject.ucd_agent_name=''
    $outputObject.ucd_agent_status=''
    $outputObject.Last_stop=''
    $outputObject.Last_start=''
    [string]$vmname=$a.VmName
    [string]$ResourceGroupName=$a.ResourceGroupName

    $vm = $az_resources | where {$_.ResourceType -eq "Microsoft.Compute/virtualMachines" -and $_.ResourceName -eq $vmname}    

    if($vm)
    {
        $vm_status = Get-AzureRMVM -ResourceGroupName $ResourceGroupName -Name $vmname -Status
        $vmDetails1 = Get-AzureRMVM -ResourceGroupName $ResourceGroupName -Name $vmname
        $outputObject.provisioning_state=[string]$vmDetails1.ProvisioningState
        $outputObject.status=[string]$vm_status.Statuses[1].DisplayStatus
        $outputObject.vm_name= $vm_status.Name
        $outputObject.rg_name= $vm_status.ResourceGroupName
        $outputObject.table_name= $table_name

        $log_contents=Get-AzureRmLog -ResourceId $vmDetails1.Id -StartTime $start_date_of_log | Where-Object {$_.Authorization.Action -match 'deallocate' -or $_.Authorization.Action -match 'start'}
        $start_log=$log_contents | Where-Object {$_.Authorization.action -match 'start'} | select -first 1
        $start_log_date=get-date $start_log.EventTimestamp -Format "dd-MMM-yyyy HH:mm"
        $outputObject.Last_start=$start_log_date

        $stop_log=$log_contents | Where-Object {$_.Authorization.action -match 'deallocate'} | select -first 1
        $stop_log_date=get-date $stop_log.EventTimestamp -Format "dd-MMM-yyyy HH:mm"
        $outputObject.Last_stop=$stop_log_date

        foreach($vnic in $vmDetails1.NetworkProfile.NetworkInterfaces) 
        {
            $MatchingNic = $AllNetworkInterfaces | where-object {$_.id -eq $vnic.id}
            $NICPrivateIP += $MatchingNic.IpConfigurations.PrivateIpAddress
        }
        $ip_address = $NICPrivateIP
        $ucd_obj =  $rest_result | Where-Object {$_.name -match $ip_address }

        if($ucd_obj)
        {
            $outputObject.ucd_agent_name= [string]$ucd_obj[0].name
            $outputObject.ucd_agent_status = [string]$ucd_obj[0].status
        }


        $outputObject.ip_address=$NICPrivateIP -join "`n"
        
    }
    else
    {
        $outputObject.vm_name=$vmname
        $outputObject.rg_name='Not found'
        $outputObject.status='Not found'
        $outputObject.table_name= $table_name
    }

    Export-Csv -Path $csv_path -inputobject $outputObject -Append -Force
  }
}

}

function vm_execute_1{

$StorageAccountName = $args[0]
$StorageAccountRGName = $args[1]
$csv_path = $args[2]

$yesterday_3_Date=(get-date (get-date).addDays(-3) -Format o).Split('T')[0]
$start_date_of_log=$yesterday_3_Date + 'T00:00'
$vm_list = New-Object System.Collections.ArrayList


$Ctx=(Get-AzureRmStorageAccount -ResourceGroupName $StorageAccountRGName -Name $StorageAccountName).Context
$stop_tables_1= Get-AzureStorageTable -Context $Ctx | Where-Object {$_.name -match 'channels' -or $_.name -match 'corm' -or $_.Name -match 'integ'} 

$stop_tables = $stop_tables_1 | Where-Object {$_.name -match 'stop' -or $_.Name -match 'SP'}
  
 foreach($table_name in $stop_tables.Name)
 {
     
  $table = Get-AzureStorageTable -Context $Ctx –Name $table_name
  $table_obj=Get-AzureStorageTableRowAll -table $table

  foreach($a in $table_obj)
  {
    $vm_list_items = @{}
    $vm_list_items.add('table_name',$table_name)
    $vm_list_items.add('VmName',$a.VmName)
    $vm_list_items.add('ResourceGroupName',$a.ResourceGroupName)

    $vm_list.add($vm_list_items)
    
  }

 }

 Select-AzureRmSubscription -SubscriptionName 'REBUS_SIT-B_TEST'
 $az_resources = Find-AzureRmResource
 $AllNetworkInterfaces = Get-AzureRmNetworkInterface
 foreach($obj in $vm_list)
 {
    $vm=''
    $vm_status=''
    $MatchingNic=''
    $NICPrivateIP = @()

    $outputObject.vm_name=''
    $outputObject.rg_name=''
    $outputObject.status=''
    $outputObject.ip_address=''
    $outputObject.table_name=''
    $outputObject.ucd_agent_name=''
    $outputObject.ucd_agent_status=''
    $outputObject.Last_stop=''
    $outputObject.Last_start=''
    [string]$vmname=$obj.VmName
    [string]$ResourceGroupName=$obj.ResourceGroupName

     $vm = $az_resources | where {$_.ResourceType -eq "Microsoft.Compute/virtualMachines" -and $_.ResourceName -eq $vmname}    

    if($vm)
    {
        $start_log=""
        $stop_log=""

        $vm_status = Get-AzureRMVM -ResourceGroupName $ResourceGroupName -Name $vmname -Status
        $vmDetails1 = Get-AzureRMVM -ResourceGroupName $ResourceGroupName -Name $vmname
        $outputObject.status=[string]$vm_status.Statuses[1].DisplayStatus
        $outputObject.vm_name= $vm_status.Name
        $outputObject.rg_name= $vm_status.ResourceGroupName
        $outputObject.table_name= $obj.table_name

        $log_contents=Get-AzureRmLog -ResourceId $vmDetails1.Id -StartTime $start_date_of_log | Where-Object {$_.Authorization.Action -match 'deallocate' -or $_.Authorization.Action -match 'start'}
        $start_log=$log_contents | Where-Object {$_.Authorization.action -match 'start'} | select -first 1
        $start_log_date=get-date $start_log.EventTimestamp -Format "dd-MMM-yyyy HH:mm"
        $outputObject.Last_start=$start_log_date

        $stop_log=$log_contents | Where-Object {$_.Authorization.action -match 'deallocate'} | select -first 1
        $stop_log_date=get-date $stop_log.EventTimestamp -Format "dd-MMM-yyyy HH:mm"
        $outputObject.Last_stop=$stop_log_date

        foreach($vnic in $vmDetails1.NetworkProfile.NetworkInterfaces) 
        {
            $MatchingNic = $AllNetworkInterfaces | where-object {$_.id -eq $vnic.id}
            $NICPrivateIP += $MatchingNic.IpConfigurations.PrivateIpAddress
        }
        $ip_address = $NICPrivateIP
        $ucd_obj =  $rest_result | Where-Object {$_.name -match $ip_address }

        if($ucd_obj)
        {
            $outputObject.ucd_agent_name= [string]$ucd_obj[0].name
            $outputObject.ucd_agent_status = [string]$ucd_obj[0].status
        }


        $outputObject.ip_address=$NICPrivateIP -join "`n"
        
    }
    else
    {
        $outputObject.vm_name=$vmname
        $outputObject.rg_name='Not found'
        $outputObject.status='Not found'
        $outputObject.table_name= $table_name
    }

    Export-Csv -Path $csv_path -inputobject $outputObject -Append -Force
 }

}

Select-AzureRmSubscription -SubscriptionName 'REBUS_TEST'
vm_execute 'rbctautdepstg01' 'RB-CT-AUT-RG01' $csv_path

Select-AzureRmSubscription -SubscriptionName 'REBUS_SIT-B_SHARED_SVCS'
vm_execute_1 'amrbsibifautostg01' 'AM-RB-SITB-SS-AUTO-RG01' $csv_path

Select-AzureRmSubscription -SubscriptionName 'REBUS_COMPONENT_TEST'
vm_execute 'amrbcicautdepstg01' 'AM-RB-CITC-IF-AUTO-RG01' $csv_path