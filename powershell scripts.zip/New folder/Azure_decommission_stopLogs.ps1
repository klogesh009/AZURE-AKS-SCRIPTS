﻿$server_ips=Import-Csv -Path "F:\Infra\Scripts\Automation\Inputs\decommission_ipList_input.csv"
#$backup_temp_csv="F:\Syed\Scripts\temp\backup_report_temp.csv"


$previous_Date=(get-date (get-date).addDays(-85) -Format o).Split('T')[0]
$start_date_of_log=$previous_Date + 'T00:00'

$today_Date=Get-Date -Format o
$directory_path='F:\Infra\Scripts\Automation\Outputs\decommission_stopLogs\'
$csv_path=$directory_path+"decommission_details_"+ $today_Date.Split('T')[0]+".csv"

$context_1=(Get-AzContext).Subscription
   if(!$context_1){
      [Byte[]] $key = (1..16)
      $SecurePassword =Get-Content "F:\Infra\Scripts\azure.txt" | ConvertTo-SecureString -Key $key
      $Credential = new-Object System.Management.Automation.PSCredential ("5035c5b6-a856-4060-88ca-21122c49d5c9", $SecurePassword)
      Login-AzAccount -credential $Credential -ServicePrincipal -TenantId a095b75b-77a2-4e28-afc2-27edd1d6b0ab -Subscription REBUS_TEST
   }




function get_azure_resourceID {

  $IP_Address=$args[0]
  $break=$false
  $resource_ID=$null
  
  $subscriptions_list=Get-AzSubscription | Where-Object {$_.Name -notmatch "MAYA" -and $_.Name -notmatch "INSIGHTS" -and $_.Name -notmatch "REBUS_PRODUCTION"}

  foreach($sub in $subscriptions_list)
  {
    Select-AzSubscription -Subscription $sub.Name -ErrorAction Stop | Out-Null
    foreach($NIC in Get-AzNetworkInterface)
    {
        foreach($IP in $NIC.IpConfigurations)
        {
            if ($IP.PrivateIpAddress -eq $IP_Address)
            {
                $resource_ID=$NIC.VirtualMachine.id
                $break=$true
            }
            if($break -eq $true)
            {
                break
            }
        }
        if($break -eq $true)
        {
            break
        }
    }
    if($break -eq $true)
    {
        break
    }
    
  }
  if($resource_ID){
    Write-Output "$resource_ID"
  }
  else{
    Write-Output "NIL"
  }

 }

 function get_azure_resourceID_with_subscription {

  $IP_Address=$args[0]
  $subscription_id_func=$args[1]
  $break=$false
  $resource_ID="NIL"
  
    Select-AzSubscription -Subscription $subscription_id_func -ErrorAction Stop | Out-Null
    foreach($NIC in Get-AzNetworkInterface)
    {
        foreach($IP in $NIC.IpConfigurations)
        {
            if ($IP.PrivateIpAddress -eq $IP_Address)
            {
                $resource_ID=$NIC.VirtualMachine.id
                $break=$true
            }
            if($break -eq $true)
            {
                break
            }
        }
        if($break -eq $true)
        {
            break
        }
    }
    

   Write-Output  "$resource_ID"

 }

 
$prev_subscription=""

$deploy = {
   Param($resource_ID_get,$csv_path,$start_date_of_log)
   $outputCollection = @()
   $outputObject =  "" | Select vm_name,ip,rg_name,status,subscription,Last_start,Last_stop
   $outputObject.vm_name=""
   $outputObject.ip=""
   $outputObject.rg_name=""
   $outputObject.status=""
   $outputObject.subscription=""
   $outputObject.Last_start=""
   $outputObject.Last_stop=""
   $vm_name=$resource_ID_get.Split("/")[-1]
   $vm_rg_name=$resource_ID_get.Split("/")[4]
   $subscription_id=$resource_ID_get.Split("/")[2]
   $outputObject.vm_name=$vm_name
   $outputObject.rg_name=$vm_rg_name

   $context_1=(Get-AzContext).Subscription
   if(!$context_1){
     [Byte[]] $key = (1..16)
      $SecurePassword =Get-Content "F:\Infra\Scripts\azure.txt" | ConvertTo-SecureString -Key $key
      $Credential = new-Object System.Management.Automation.PSCredential ("5035c5b6-a856-4060-88ca-21122c49d5c9", $SecurePassword)
      Login-AzAccount -credential $Credential -ServicePrincipal -TenantId a095b75b-77a2-4e28-afc2-27edd1d6b0ab -Subscription $subscription_id
   }
   else{
     Select-AzSubscription -Subscription $subscription_id
   }
   $context=(Get-AzContext).Subscription
   $subscription_id_1=$context.Id
   if($subscription_id_1 -ne $subscription_id){
     Logout-AzAccount
     [Byte[]] $key = (1..16)
      $SecurePassword =Get-Content "F:\Infra\Scripts\azure.txt" | ConvertTo-SecureString -Key $key
      $Credential = new-Object System.Management.Automation.PSCredential ("5035c5b6-a856-4060-88ca-21122c49d5c9", $SecurePassword)
      Login-AzAccount -credential $Credential -ServicePrincipal -TenantId a095b75b-77a2-4e28-afc2-27edd1d6b0ab -Subscription $subscription_id
   }
   $outputObject.subscription=(Get-AzContext).Subscription.Name
   $vm_status = Get-AzVM -ResourceGroupName $vm_rg_name -Name $vm_name -Status
   $outputObject.status = $vm_status.Statuses[1].DisplayStatus
   $vm_obj = Get-AzVM -ResourceGroupName $vm_rg_name -Name $vm_name
   $vm_nic_id = $vm_obj.NetworkProfile.NetworkInterfaces[0].Id
   $outputObject.ip = (Get-AzNetworkInterface -ResourceId $vm_nic_id).IpConfigurations[0].PrivateIpAddress

   $today_unixtime=[int][double]::Parse((get-date -UFormat %s))
   $log_contents=Get-AzLog -ResourceId $resource_ID_get  -StartTime $start_date_of_log | Where-Object {($_.Authorization.Action -match 'deallocate' -or $_.Authorization.Action -match 'start') -and $_.Status -eq "Succeeded"}
   $start_details=@()
   $stop_details=@()
   if($log_contents){
     $start_logs=$log_contents | Where-Object {$_.Authorization.action -match 'start'} | select -first 3
     foreach($start_log in $start_logs){
       $start_log_date=get-date $start_log.EventTimestamp -Format "dd-MMM-yyyy HH:mm"
       $start_details+=$start_log_date+" $ "+$start_log.Caller+""      
     }
  #   $Start_unixtime= [int][double]::Parse((get-date $start_log.EventTimestamp -UFormat %s))
     if($start_details){
       $outputObject.Last_start=$start_details -join "`n"
     }
	 
     $stop_logs=$log_contents | Where-Object {$_.Authorization.action -match 'deallocate'} | select -first 3
     foreach($stop_log in $stop_logs){
       $stop_log_date=get-date $stop_log.EventTimestamp -Format "dd-MMM-yyyy HH:mm"
       $stop_details+=$stop_log_date+" $ "+$stop_log.Caller+""      
     }
  #   $Stop_unixtime= [int][double]::Parse((get-date $stop_log.EventTimestamp -UFormat %s))
     if($stop_details){
       $outputObject.Last_stop=$stop_details -join "`n"
     }     
     
     
   }

   

   Export-Csv -Path $csv_path -inputobject $outputObject -Append -Force -NoTypeInformation

}


foreach($IP_input in $server_ips){
    
   $server_ip=""
   $server_subscription=""
   $subscription_id=""
   $vm_name=""
   $vm_rg_name=""
   $resource_ID_get=""
   $server_ip=$IP_input.IPs.trim()
   $server_subscription=$IP_input.subscription

   $jobs_running = Get-Job | where {$_.State -eq "Running"}
   while($jobs_running.Count -ge 15){
        Start-Sleep -Seconds 10
        $jobs_running = Get-Job | where {$_.State -eq "Running"}
   }
<#
   if($prev_subscription -eq ""){
     $resource_ID_get= get_azure_resourceID $IP_input
   }
   else{
     $resource_ID_get= get_azure_resourceID_with_subscription $IP_input $prev_subscription
     if($resource_ID_get -eq "NIL"){
       $resource_ID_get= get_azure_resourceID $IP_input
     }
   }
#>
  $resource_ID_get= get_azure_resourceID_with_subscription $server_ip $server_subscription

 if($resource_ID_get -ne "" -and $resource_ID_get -ne "NIL"){
   
   echo $resource_ID_get

   $vm_name=$resource_ID_get.Split("/")[-1]
   $vm_rg_name=$resource_ID_get.Split("/")[4]
   $subscription_id=$resource_ID_get.Split("/")[2]
   $prev_subscription=$subscription_id
   echo $vm_name $vm_rg_name $subscription_id

   $job = Start-Job -ScriptBlock $deploy -ArgumentList $resource_ID_get,$csv_path,$start_date_of_log
 
 }
 else{
   echo "Resource Not found"
 }

}

$jobs = Get-Job
$job_result = New-Object System.Collections.ArrayList
while($jobs | Where-Object {$_.State -eq "Running" })
{
    $jobs_completed = $jobs | Where-Object { $_.State -eq "Completed" -and $_.HasMoreData -match "True"}
    foreach( $job in $jobs_completed ){
      $job_id = $job.Id
      $result_1 = Receive-Job -id $job_id
      if($result_1){
        $job_result.Add($result_1)
        $result_1
      }
   }
}

Logout-AzAccount