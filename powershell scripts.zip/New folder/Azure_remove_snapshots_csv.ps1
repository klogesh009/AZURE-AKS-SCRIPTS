﻿$outputCollection = @()
$outputObject = "" | Select snapshot_name,rg_name
$snapshot_list = import-csv "F:\Infra\Scripts\Snapshot\Deletion\Sanpshots\snapshots_delete-Input.csv"

foreach ($snapshot_row in $snapshot_list) {
    $deploy = {
          Param($rg_name,$snapshot_name,$subscription)            
           [Byte[]] $key = (1..16)
       $SecurePassword =Get-Content "F:\Infra\Scripts\azure_nonprod.txt" | ConvertTo-SecureString -Key $key
       $Credential = new-Object System.Management.Automation.PSCredential ("962a8e28-2e38-486f-aa23-0dd7befe0c53", $SecurePassword)
       Login-AzAccount -credential $Credential -ServicePrincipal -TenantId a095b75b-77a2-4e28-afc2-27edd1d6b0ab -Subscription $subscription
             
       Remove-AzSnapshot -ResourceGroupName $rg_name -SnapshotName $snapshot_name -Force
    }
    $is_triggered=0
    $snapshot_name = ""
    $rg_name = ""
    $subscription= ""
    $snapshot_name = $snapshot_row.snapshot_name
    $rg_name = $snapshot_row.rg_name
    $subscription= $snapshot_row.subscription

      $jobs_running = Get-Job | where {$_.State -eq "Running"}
     while($jobs_running.Count -ge 50){
        Start-Sleep -Seconds 5
        $jobs_running = Get-Job | where {$_.State -eq "Running"}
     }

    foreach($subscription_check in (Get-AzSubscription).Name){
      if($subscription_check -eq $subscription){
          "$snapshot_name  $subscription  Triggered"
         $is_triggered=1
         $job = Start-Job -ScriptBlock $deploy -ArgumentList $rg_name,$snapshot_name,$subscription
      }
    }   
    if($is_triggered -eq 0){
       "$snapshot_name Not deleted"
    }
    

}

$jobs = Get-Job
$job_result = New-Object System.Collections.ArrayList
while($jobs | Where-Object {$_.State -eq "Running" })
{
    $jobs_completed = $jobs | Where-Object { $_.State -eq "Completed" -and $_.HasMoreData -match "True"}
    foreach( $job in $jobs_completed ){
      $job_id = $job.Id
      $result_1 = Receive-Job -id $job_id
      if($result_1){
        $job_result.Add($result_1)
        $result_1
      }
   }
}

