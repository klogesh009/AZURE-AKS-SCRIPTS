﻿$vms_input=import-csv -Path "F:\Infra\Scripts\Automation\Inputs\vm_MMAInstall_input.csv"
$csv_path="F:\Infra\Scripts\Automation\Outputs\vm_MMAInstall_status.csv"

$context_1=(Get-AzContext).Subscription
   if(!$context_1){
      [Byte[]] $key = (1..16)
      $SecurePassword =Get-Content "F:\Infra\Scripts\azure_nonprod.txt" | ConvertTo-SecureString -Key $key
      $Credential = new-Object System.Management.Automation.PSCredential ("962a8e28-2e38-486f-aa23-0dd7befe0c53", $SecurePassword)
      Login-AzAccount -credential $Credential -ServicePrincipal -TenantId a095b75b-77a2-4e28-afc2-27edd1d6b0ab -Subscription REBUS_TEST
   }

$deploy = {
        Param($vm_name,$rg_name,$subscription,$csv_path)
  $context_1=(Get-AzContext).Subscription
   #if(!$context_1){
      [Byte[]] $key = (1..16)
      $SecurePassword =Get-Content "F:\Infra\Scripts\azure_nonprod.txt" | ConvertTo-SecureString -Key $key
      $Credential = new-Object System.Management.Automation.PSCredential ("962a8e28-2e38-486f-aa23-0dd7befe0c53", $SecurePassword)
      Login-AzAccount -credential $Credential -ServicePrincipal -TenantId a095b75b-77a2-4e28-afc2-27edd1d6b0ab -Subscription $subscription
  # }
   #else{
 #    Select-AzSubscription -Subscription $subscription
  # }
   $outputCollection = @()
   $outputObject =  "" | Select vm_name,rg_name,location,subscription,status

   "$vm_name--$rg_name"
   $vm_obj = Get-AzVM -ResourceGroupName $rg_name -Name $vm_name
   $vm_obj_1 = Get-AzVM -ResourceGroupName $rg_name -Name $vm_name -Status
   $vm_status=$vm_obj_1.Statuses[1].DisplayStatus
   if($vm_status -match "running"){
     $location=$vm_obj.Location
     $Tag_environment=$vm_obj.Tags["ENVIRONMENT"]
     $os_type=$vm_obj.StorageProfile.OsDisk.OsType
     if($os_type -match "windows"){
       $output1=Invoke-AzVMRunCommand -ResourceGroupName $rg_name -Name $vm_name -CommandId 'RunPowerShellScript' -ScriptPath 'F:\Syed\Scripts\Windows\MMAInstall.ps1' -Parameter @{"Location"=$location;"Environment"=$Tag_environment}
       
     }
     elseif($os_type -match "linux"){
       $output1=Invoke-AzVMRunCommand -ResourceGroupName $rg_name -Name $vm_name -CommandId 'RunShellScript' -ScriptPath 'F:\Syed\Scripts\linux\oms-agent-install.sh' -Parameter @{"Location"=$location;"Environment"=$Tag_environment}
     }
     if($output1){  
       $temp=[string]$output1.Value[0].Message
       $temp
       $outputObject.vm_name=$vm_name
       $outputObject.rg_name=$rg_name
       $outputObject.location=$location
       $outputObject.status=$temp
       $outputObject.subscription=$subscription
      # $temp >> F:\Syed\2021\Feb\vm_MMAInstall_status_1.csv

       Export-Csv -Path $csv_path -inputobject $outputObject -Append -Force -NoTypeInformation
     }
   }

}

foreach($vm_input in $vms_input){
  $jobs_running = Get-Job | where {$_.State -eq "Running"}
 
      while($jobs_running.Count -ge 30){
        Start-Sleep -Seconds 5
        $jobs_running = Get-Job | where {$_.State -eq "Running"}
      } 
  $vm_input.vm_name;$vm_input.rg_name
  $job = Start-Job -ScriptBlock $deploy -ArgumentList $vm_input.vm_name,$vm_input.rg_name,$vm_input.subscription,$csv_path
}

#$subscription="REBUS_SIT-B_SHARED_SVCS"

$jobs = Get-Job
$job_result = New-Object System.Collections.ArrayList
while($jobs | Where-Object {$_.State -eq "Running" })
{
    $jobs_completed = $jobs | Where-Object { $_.State -eq "Completed" -and $_.HasMoreData -match "True"}
    foreach( $job in $jobs_completed ){
      $job_id = $job.Id
      $result_1 = Receive-Job -id $job_id
      if($result_1){
        $job_result.Add($result_1)
        $result_1
      }
   }
}