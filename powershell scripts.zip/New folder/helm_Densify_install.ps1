﻿$csv_input= Import-Csv -Path "F:\Infra\Scripts\Automation\Inputs\helm_densify_upgrade_input.csv"

Write-Output "Do you want to remove existing densify. Enter number?"
Write-Output "1.Yes`r`n2.No"
$user_input = Read-Host "Option No"


foreach( $aks_obj in $csv_input ){
  $cluster_name=$aks_obj.cluster_name
  $rg_grp=$aks_obj.rg_name
  $subscription=$aks_obj.subscription
  $taints_added=$aks_obj.taints_added
$kube_state_metrics_path="F:\Infra\Scripts\AKS\CAAS\helm\kube-state-metrics"
$prometheus_path="F:\Infra\Scripts\AKS\CAAS\helm\prometheus"
$densify_container_path="F:\Infra\Scripts\AKS\CAAS\helm\container-optimization-data-forwarder"

az account set --s $subscription
cmd.exe /c "az aks get-credentials --resource-group $rg_grp --name $cluster_name --admin --overwrite-existing"
#az aks get-credentials --resource-group am-rb-sib-it-ftl-arg01 --name rbsibitftlkaa01 --admin


if( $user_input -eq "1" ){
  #Removal of previous resources
  kubectl delete serviceaccount kube-state-metrics -n densify
  kubectl delete service kube-state-metrics -n densify
  kubectl delete deployment kube-state-metrics -n densify
  kubectl delete clusterrole kube-state-metrics
  kubectl delete clusterrolebinding kube-state-metrics
  
  kubectl delete deployment prometheus-deployment -n densify
  kubectl delete service node-exporter -n densify
  kubectl delete daemonset node-exporter -n densify
  kubectl delete service prometheus-service -n densify
  kubectl delete cronjob densify-job -n densify

  #kubectl delete namespace densify
}

#Installation of kube-state-metrics
kubectl create namespace densify
cd $kube_state_metrics_path
helm install kube-state-metrics -n densify --set taints_added=$taints_added .

$pods_kubeMetrics_status=""
$pods_kubeMetrics=""
$pods_kubeMetrics_notRunning=$true

while($pods_kubeMetrics_notRunning){
  $pods_kubeMetrics=kubectl get pods -n densify
  $pods_status = $pods_kubeMetrics | Select-String -SimpleMatch "kube-state-metrics" | Select-String -SimpleMatch "Running"
  if($pods_status){
    $pods_kubeMetrics_notRunning=$false
  }else{
    Start-Sleep -Seconds 10
  }
}

if($?){
  echo "kube-state-metrics installed successfully"
}

#Installation of Prometheus
cd $prometheus_path
if($taints_added -eq "yes"){
  cmd.exe /c "helm install prometheus --set taints_added=$taints_added --set app_code={aks,ftl} -n densify . --atomic"
}
else{
 cmd.exe /c "helm install prometheus --set taints_added=$taints_added --set app_code={aks,nil} -n densify . --atomic"
}

if($?){
  echo "Prometheus installed successfully"
}

Start-Sleep -Seconds 10

#Installation of densify-forwarder
cd $densify_container_path
helm install densify-forwarder --set taints_added=$taints_added --set config.prometheus.clustername=$cluster_name --set config.zipname="data/$cluster_name" -n densify . --atomic

if($?){
  echo "Densify Forwarder installed successfully"
}
##--dry-run --debug

}