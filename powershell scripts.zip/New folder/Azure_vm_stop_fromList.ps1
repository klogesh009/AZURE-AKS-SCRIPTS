﻿## Input csv fields vmName,rgName,subscription


$tags = import-csv "F:\Infra\Scripts\Automation\Inputs\vm_stop_input.csv"

#$vm_list_input = Import-Csv -Path "F:\Syed\Reports\vm_status_with_uptime.csv"

$vm_sorted_list = $tags | Sort-Object -Property subscription


$context_1=(Get-AzContext).Subscription
if(!$context_1){
  [Byte[]] $key = (1..16)
   $SecurePassword =Get-Content "F:\Infra\Scripts\azure_nonprod.txt" | ConvertTo-SecureString -Key $key
   $Credential = new-Object System.Management.Automation.PSCredential ("962a8e28-2e38-486f-aa23-0dd7befe0c53", $SecurePassword)
   Login-AzAccount -credential $Credential -ServicePrincipal -TenantId a095b75b-77a2-4e28-afc2-27edd1d6b0ab -Subscription REBUS_TEST
}

$prev_subscription=""
 foreach($vm_input in $vm_sorted_list){
   $vm_obj=""
   if($vm_input.subscription -ne $prev_subscription){
     Select-AzSubscription -Subscription $vm_input.subscription | Out-Null
     $prev_subscription=$vm_input.subscription
   }
   $vm_obj=Get-AzVM -ResourceGroupName $vm_input.rgName -Name $vm_input.vmName
   "VM: "+$vm_obj.Name+" RG: "+$vm_obj.ResourceGroupName+" Subscription: "+ $vm_input.subscription
 }
 Write-Output "Do you want to Shutdown above servers?"
 Write-Output "1.Yes`r`n2.No"
 $user_input = Read-Host "Option No"
 if($user_input -ne "1"){
   exit
 }

foreach ($vm_obj in $vm_sorted_list) {

$deploy = {
        Param($vm_name,$rg_name,$subscription)
        $context_1=(Get-AzContext).Subscription
        if(!$context_1){
          [Byte[]] $key = (1..16)
           $SecurePassword =Get-Content "F:\Infra\Scripts\azure_nonprod.txt" | ConvertTo-SecureString -Key $key
           $Credential = new-Object System.Management.Automation.PSCredential ("962a8e28-2e38-486f-aa23-0dd7befe0c53", $SecurePassword)
           Login-AzAccount -credential $Credential -ServicePrincipal -TenantId a095b75b-77a2-4e28-afc2-27edd1d6b0ab -Subscription $subscription
        }
        else{
         Select-AzSubscription -Subscription $subscription
        }
        
        Stop-AzVM -Name $vm_name -ResourceGroupName $rg_name -force
        Write-Output ("Stopped"+"  "+$vm_name)
}


 #$vm_obj=$vm_list_input | where-object {$_.vm_name -eq $tag.VmName -and $_.subscription -eq $tag.subscription -and $_.rg_name -eq $tag.rgName}

 $jobs_running = Get-Job | where {$_.State -eq "Running"}
 while($jobs_running.Count -ge 50){
        Start-Sleep -Seconds 5
        $jobs_running = Get-Job | where {$_.State -eq "Running"}
 }

 

#foreach($vm in $vm_obj){
    $vm_obj.vmName+"  "+$vm_obj.rgName
    $job = Start-Job -ScriptBlock $deploy -ArgumentList $vm_obj.vmName,$vm_obj.rgName,$vm_obj.subscription

#}

}

$jobs = Get-Job
$job_result = New-Object System.Collections.ArrayList
while($jobs | Where-Object {$_.State -eq "Running" })
{
    $jobs_completed = $jobs | Where-Object { $_.State -eq "Completed" -and $_.HasMoreData -match "True"}
    foreach( $job in $jobs_completed ){
      $job_id = $job.Id
      $result_1 = Receive-Job -id $job_id
      if($result_1){
        $job_result.Add($result_1)
        $result_1
      }
   }
}

