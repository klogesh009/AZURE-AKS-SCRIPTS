﻿Import-AzureRmContext -Path F:\Infra\Scripts\profile1.json

$today_Date=Get-Date -Format o
$directory_path='F:\Infra\Reports\tag_status\'+$today_Date.Split('T')[0]
if(!(Test-Path -Path $directory_path )){
    New-Item -ItemType directory -Path $directory_path
}



$outputCollection = @()
$outputObject = "" | Select rname,rgname,Tag_PROJECT,Tag_ENVIRONMENT,Tag_OWNER,Tag_APPLICATION,Tag_COSTCENTERID,Tag_APPLICATION_CODE,rt
$all_subscriptions= Get-AzureRmSubscription
foreach($current_scubscription in $all_subscriptions)
{
    Select-AzureRmSubscription -SubscriptionName $current_scubscription.Name
    $az_resources = Find-AzureRmResource | where {$_.ResourceType -ne "Microsoft.Compute/virtualMachines/extensions"}
    foreach ($azureResourceInfo in $az_resources) {

	
      #  $azureResourceInfo = Find-AzureRmResource -ResourceGroupNameEquals $tag.rgname -ResourceNameEquals $tag.rname -ResourceType $tag.rt

	    $tags=$azureResourceInfo.tags
	    [array]$test=$tags.Keys
	    [array]$test1=$tags.Values

        $key_temp=""
        $outputObject.Tag_PROJECT=""
        $outputObject.Tag_ENVIRONMENT=""
        $outputObject.Tag_OWNER=""
        $outputObject.Tag_APPLICATION=""
        $outputObject.Tag_COSTCENTERID=""
        $outputObject.Tag_APPLICATION_CODE=""
	    $outputObject.rname=$azureResourceInfo.ResourceName
	    $outputObject.rgname=$azureResourceInfo.ResourceGroupName
	    $outputObject.rt=$azureResourceInfo.ResourceType
	    for($i=0;$i -lt $tags.Count;$i=$i+1 )
	    {
		    $key_temp=$test[$i]
		    if($key_temp -eq "PROJECT")
		    {
			    $outputObject.Tag_PROJECT = $test1[$i]
		    }
		    elseif($key_temp -eq "ENVIRONMENT")
		    {
			    $outputObject.Tag_ENVIRONMENT = $test1[$i]
		    }
		    elseif($key_temp -eq "OWNER")
		    {
			    $outputObject.Tag_OWNER = $test1[$i]
		    }
            elseif($key_temp -eq "APPLICATION_CODE")
		    {
			    $outputObject.Tag_APPLICATION_CODE = $test1[$i]
		    }
		    elseif($key_temp -eq "APPLICATION")
		    {
			    $outputObject.Tag_APPLICATION = $test1[$i]
		    }
		    elseif($key_temp -eq "COSTCENTERID")
		    {			    
			    $outputObject.Tag_COSTCENTERID = $test1[$i]
		    }            

	    }
        $csv_path=$directory_path + "\Tags_"+$current_scubscription.Name+".csv"
	    Export-Csv -Path $csv_path -inputobject $outputObject -Append -Force

    }
}