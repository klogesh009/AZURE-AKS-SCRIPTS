﻿$context=(Get-AzContext).Subscription
if(!$context){
  [Byte[]] $key = (1..16)
  $SecurePassword =Get-Content "F:\Infra\Scripts\azure_nonprod.txt" | ConvertTo-SecureString -Key $key
  $Credential = new-Object System.Management.Automation.PSCredential ("962a8e28-2e38-486f-aa23-0dd7befe0c53", $SecurePassword)
  Login-AzAccount -credential $Credential -ServicePrincipal -TenantId a095b75b-77a2-4e28-afc2-27edd1d6b0ab -Subscription REBUS_TEST
}
$disks_csv=Import-Csv -Path "F:\Infra\Scripts\Automation\Inputs\disks_detach_delete.csv"
$previous_sub=""

$disks_csv | ft

Write-Output "Operation to perform. Enter number?"
Write-Output "1.Detach disk`r`n2.Delete disk"
$user_input = Read-Host "Option No"

$deploy = {
          Param($rg_name,$disk_name,$subscription)            
       [Byte[]] $key = (1..16)
       $SecurePassword =Get-Content "F:\Infra\Scripts\azure_nonprod.txt" | ConvertTo-SecureString -Key $key
       $Credential = new-Object System.Management.Automation.PSCredential ("962a8e28-2e38-486f-aa23-0dd7befe0c53", $SecurePassword)
       Login-AzAccount -credential   $Credential -ServicePrincipal -TenantId a095b75b-77a2-4e28-afc2-27edd1d6b0ab -Subscription $subscription
       
       "$disk_name $subscription"      
       Remove-AzDisk -DiskName $disk_name -ResourceGroupName $rg_name -Force
}

foreach($disk_csv in $disks_csv){
  
  
  $disk_obj=""
  $vm_obj=""
  $disk_name=""

  

   $jobs_running = Get-Job | where {$_.State -eq "Running"}
     while($jobs_running.Count -ge 25){
        Start-Sleep -Seconds 10
        $jobs_running = Get-Job | where {$_.State -eq "Running"}
     }

  if($previous_sub -ne $disk_csv.subscription){
    Select-AzSubscription -Subscription $disk_csv.subscription
    $previous_sub=$disk_csv.subscription
  }

  if( $user_input -eq "1"){
    
    $disk_obj=get-azdisk -ResourceGroupName $disk_csv.rgname -DiskName $disk_csv.disk_name
    $vm_obj = Get-AzVM -ResourceGroupName $disk_csv.rgname -Name $disk_obj.ManagedBy.Split("/")[-1]
    $disk_name=$disk_csv.disk_name
    if($disk_obj.Tags["DISK-SHRINK"] -match "OLDDATADISK" -and $disk_obj.DiskSizeGB -eq $disk_csv.disk_size_in_GB){
      Remove-AzVMDataDisk -VM $vm_obj -DataDiskNames $disk_csv.disk_name | Update-AzVM
      echo "$disk_name detached from the server"
    }
    else{
      echo "Tag DISK_SHRINK is missing or Size mismatch in the disk $disk_name"
    }
    
  }

  if( $user_input -eq "2" ){
    $disk_obj=get-azdisk -ResourceGroupName $disk_csv.rgname -DiskName $disk_csv.disk_name
    if($disk_obj.DiskState -eq "Unattached" -and $disk_obj.Name -notmatch "ASRReplica" -and $disk_obj.Tags["DISK-SHRINK"] -match "OLDDATADISK"){
      $disk_obj.DiskState+"  "+$disk_obj.Name+"  "+$disk_csv.subscription
      $job = Start-Job -ScriptBlock $deploy -ArgumentList $disk_csv.rgname,$disk_obj.Name,$disk_csv.subscription
    }
    else{
      $disk_name=$disk_csv.disk_name
      "$disk_name is not Deleted. Tag DISK_SHRINK might be missing"
    }
  }
}

$jobs = Get-Job
$job_result = New-Object System.Collections.ArrayList
while($jobs | Where-Object {$_.State -eq "Running" })
{
    $jobs_completed = $jobs | Where-Object { $_.State -eq "Completed" -and $_.HasMoreData -match "True"}
    foreach( $job in $jobs_completed ){
      $job_id = $job.Id
      $result_1 = Receive-Job -id $job_id
      if($result_1){
        $job_result.Add($result_1)
        $result_1
      }
   }
}

$jobs_completed = $jobs | Where-Object { $_.State -eq "Completed" -and $_.HasMoreData -match "True"}
    foreach( $job in $jobs_completed ){
      $job_id = $job.Id
      $result_1 = Receive-Job -id $job_id
      if($result_1){
        $job_result.Add($result_1)
        $result_1
      }
   }