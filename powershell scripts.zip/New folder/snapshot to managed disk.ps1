﻿#Provide the subscription Id
$subscriptionId = 'aa57ae38-e1b4-42ca-8b10-0aebc280a57b'

#Provide the name of your resource group
$resourceGroupName ='AM-RB-UATA-CO-OMS-RG01'

#Provide the name of the snapshot that will be used to create Managed Disks
$snapshotName = 'rbsiacoocsclw01-datadisk01-SNAP01'

#Provide the name of the Managed Disk
$diskName = 'rbsiacoocsclw01-datadisk01-res'

#Provide the size of the disks in GB. It should be greater than the VHD file size.
$diskSize = '128'

#Provide the storage type for Managed Disk. PremiumLRS or StandardLRS.
$storageType = 'Standard_LRS'

#Provide the Azure region (e.g. westus) where Managed Disks will be located.
#This location should be same as the snapshot location
#Get all the Azure location using command below:
#Get-AzLocation
$location = 'northeurope'

#Set the context to the subscription Id where Managed Disk will be created
Select-AzSubscription -SubscriptionId $SubscriptionId

$snapshot = Get-AzSnapshot -ResourceGroupName $resourceGroupName -SnapshotName $snapshotName 

$diskConfig = New-AzDiskConfig -SkuName $storageType -Location $location -CreateOption Copy -SourceResourceId $snapshot.Id

# Create the new disk from the snapshot
New-AzDisk -Disk $diskConfig -ResourceGroupName $resourceGroupName -DiskName $diskName