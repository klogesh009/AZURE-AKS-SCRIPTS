﻿<#

.Intoduction
    This script is the intellectual property of NTT DATA – a part of NTT Group. NTT Data is a trusted global 
    innovator of IT and business services headquartered in Tokyo. We help clients transform through consulting, 
    industry solutions, business process services, IT modernization and managed services. NTT DATA enables 
    clients, as well as society, to move confidently into the digital future. We are committed to our clients’ 
    long-term success and combine global reach with local client attention to serve them in over 50 countries.

    https://www.nttdata.com/global/en/about-us

    For Terms of use see: https://www.nttdata.com/global/en/term-of-use

.SYNOPSIS
  PowerShell script to be ran against Azure Tenant for converting a Virtual Machine from an Availability Set to a Availability Zone.

.DESCRIPTION
  The script creates a new virtual machine from a snapshot taken of the OS and data disk drives in a newly specified Resource Group, the existing (orginal) shutdown and orphaned which will require cleanup at a later date, the original NIC is also migrated to the new Resource Group and the old VM given a placeholder NIC.

.PARAMETERS

    $subscriptionId = Enter the Subscription ID for where the VM is created
    $resourceGroup = Enter the VM Resource Group Name
    $vmName = Enter the VM Name
    $location = Enter the VM location Group Name, e.g. uksouth
    $zone = Enter the new avaliability zone number, either 1, 2 or 3, ensure you change the zone number for each VM type

.INPUTS
  None

.OUTPUTS
  None

.NOTES
  Version:        3.0
  Author:         Dylan Hughes, Daniel Cubley
  Creation Date:  01/07/2022
  Purpose/Change: Release Ready Version
  
.EXAMPLE
  Execute vm-migrateto-availabilityzone-v3.ps1

.REQUIREMENTS

  Install the Az module if you haven't done so already.
  Install-Module Az
 
  Login to your Azure account.
  Login-AzAccount

#>

# Set variables
param (
$subscriptionId = $(Read-Host -Prompt 'Enter the Subscription ID for where the VM is created'),
$resourceGroup = $(Read-Host -Prompt 'Enter the Current VM Resource Group Name'),
$vmName = (Read-Host -Prompt 'Enter the VM Name'),
$location = (Read-Host -Prompt 'Enter the VM location Group Name, e.g. uksouth'),
$zone = (Read-Host -Prompt 'Enter the new avaliability zone number, either 1, 2 or 3, ensure you change the zone number for each VM type'),
$NewRG = $(Read-Host -Prompt 'Enter the name of the new resource group you want the VM to reside in')
)

Write-Host "The script will now run against subscription $subscriptionId, Resource Group $resourceGroup, for VM $vmname in Location $location. The script will set the Avaliability Zone for the VM to $zone and create the new resource in $NewRG." -ForegroundColor Yellow

#Set the subscription
Set-AzContext -Subscription $subscriptionId

# Get the details of the VM to be moved to the Availability Zone
$originalVM = Get-AzVM -ResourceGroupName $resourceGroup -Name $vmName -ErrorAction SilentlyContinue

if($originalVM -eq $null) {
Write-Host "VM Not found in Azure, please ensure you have provided the correct informaiton in the parameters" -ForegroundColor Red
Write-Host "Script will now exit"
Start-Sleep -Seconds 2
Exit
}

$datadiskcheck = $originalVM.StorageProfile.DataDisks

#Check if VM is in Avaliability Set
$VMCheck = Get-AzVM -Name $vmName
$AvailCheck = $VMCheck.AvailabilitySetReference
if($AvailCheck -eq $null) {
Write-Host "Availability Set not detected, this script is intended to run against VM's that have an Availability Set assigned. Please ensure this VM has an Availability Set assigned if you think this VM should be migrated." -ForegroundColor Red
Write-Host "Script will now exit"
Start-Sleep -Seconds 2
Exit
}

#Check if NewRG is a new RG
$RGCheck = $VMCheck.ResourceGroupName
if($RGCheck -eq $NewRG) {
Write-Host "You have entered the same Resource Group name as the existing VM, this script is intended to move the VM to a new Resource Group. Please re run the script and enter a new Resource Group name that doesnt match the existing Resource Group." -ForegroundColor Red
Write-Host "Script will now exit"
Start-Sleep -Seconds 2
Exit
}

#Determine if a recent restore point exists for VM
$BackupStatus = Get-AzRecoveryServicesBackupStatus -Name $originalVM.Name -ResourceGroupName $resourceGroup -Type AzureVM
if ($BackupStatus.BackedUp -eq $true) {
$Container = Get-AzRecoveryServicesBackupContainer -ContainerType AzureVM -Status Registered -FriendlyName $originalVM.Name -VaultId $BackupStatus.VaultId
$BackupItem = Get-AzRecoveryServicesBackupItem -Container $Container -WorkloadType AzureVM -VaultId $BackupStatus.VaultId
$RecoveryPoints = Get-AzRecoveryServicesBackupRecoveryPoint -Item $BackupItem -VaultId $BackupStatus.VaultId
$LatestRecoveryPoint = $RecoveryPoints | Select-Object -First 1
$LatestRecoveryPointTime = $LatestRecoveryPoint.RecoveryPointTime
$LatestRecoveryPointType = $LatestRecoveryPoint.RecoveryPointType
$Warning = "Warning $VMName is currently backed up via Azure Backup, the latest restore point is $LatestRecoveryPointTime and is type $LatestRecoveryPointType, If you are happy to continue type CONTINUE, the script will take a new disk snapshot for the OS disk and Data disks, then create new managed disks from the snapshots, The exsiting VM will be shutdown and a new VM will be created from the snapshots in $NewRG. If you are not happy type STOP to end the script NOW...."
} else {
$Warning = "Warning $VMName is not currently backed up via Azure Backup, it is recommended to ensure the VM has a valid backup before continuing. If you are happy to continue without a valid Azure Backup type CONTINUE..., the script will take a new disk snapshot for the OS disk and Data disks, then create new managed disks from the snapshots, The exsiting VM will be shutdown and a new VM will be created from the snapshots in $NewRG. If you are not happy type STOP to end the script NOW...."
}

#Ask the user if they would like to continue
$Option = Read-Host -Prompt $Warning

if ($Option -eq "CONTINUE") {
    Write-Host "You chose to continue the script, the VM will now be recreated" -ForegroundColor Green
} else {
    Write-Warning -Message "You chose not to continue the script or did not type continue correctly, the script will now end."
    Start-Sleep -Seconds 2
    Exit
}

# Create new RG if needed
$NewRGCheck = Get-AzResourceGroup -Name $NewRG -ErrorAction SilentlyContinue
if($NewRGCheck -eq $null){
Write-Host "Creating new Resource Group $newRG" -ForegroundColor Yellow
New-AzResourceGroup -Name $NewRG -Location $location
} Else {
Write-Host "Resource Group $newRG already exists" -ForegroundColor Yellow
}


# Stop the VM to take snapshot
Write-Host "Stopping VM $vmName" -ForegroundColor Yellow
Stop-AzVM -ResourceGroupName $resourceGroup -Name $vmName -Force 

# Give the shutdown VM a new NIC So we can move the existing NIC to the new RG
Write-Host "Adding a placeholder NIC to existing $vmName" -ForegroundColor Yellow
$ExistingNics = $originalVM.NetworkProfile.NetworkInterfaces
$ExistingNic = $ExistingNics | Select-Object -First 1
$ExistingnetInterface = Get-AzNetworkInterface -ResourceId $ExistingNic.Id
$ExistingSubnetID = $ExistingnetInterface.IpConfigurations.Subnet.Id
$PlaceholderNic = New-AzNetworkInterface -Location $location -Name ($originalVM.Name + "PlaceHolderNIC") -ResourceGroupName $resourceGroup -SubnetId $ExistingSubnetID
Add-AzVMNetworkInterface -VM $originalVM -Id $PlaceholderNic.Id -Primary | Update-AzVM -ResourceGroupName $resourceGroup -VM $originalVM

# Create a SnapShot of the OS disk and then, create an Azure Disk with Zone information
$snapshotOSConfig = New-AzSnapshotConfig -SourceUri $originalVM.StorageProfile.OsDisk.ManagedDisk.Id -Location $location -CreateOption copy -SkuName Standard_ZRS
Write-Host "Creating new VM Snapshot" -ForegroundColor Yellow
$OSSnapshot = New-AzSnapshot -Snapshot $snapshotOSConfig -SnapshotName ($originalVM.StorageProfile.OsDisk.Name + "-snapshot") -ResourceGroupName $resourceGroup
$originalOSDisk = Get-AzDisk -DiskName $originalVM.StorageProfile.OsDisk.Name -ResourceGroupName $originalVM.ResourceGroupName
$diskSkuOS = $originalOSDisk.Sku.Name
$osversion = $originalOSDisk.OsType

#Create new OS Disk
$diskConfig = New-AzDiskConfig -Location $OSSnapshot.Location -SourceResourceId $OSSnapshot.Id -CreateOption Copy -SkuName $diskSkuOS -Zone $zone
Write-Host "Creating new OS Disk from Snapshot" -ForegroundColor Yellow
#$OSdisk = New-AzDisk -Disk $diskConfig -ResourceGroupName $resourceGroup -DiskName ($originalVM.StorageProfile.OsDisk.Name + "-Migrated")
$OSdisk = New-AzDisk -Disk $diskConfig -ResourceGroupName $NewRG -DiskName ($originalVM.StorageProfile.OsDisk.Name)
$OSdiskTags = New-AzTag -ResourceId $OSdisk.Id -Tag $originalVM.Tags


# Create a Snapshot from the Data Disks and the Azure Disks with Zone information
if($datadiskcheck -ne $null) {
Write-Host "Creating new Data Disks from Snapshot" -ForegroundColor Yellow
foreach ($disk in $originalVM.StorageProfile.DataDisks) { 

   $snapshotDataConfig = New-AzSnapshotConfig -SourceUri $disk.ManagedDisk.Id -Location $location -CreateOption copy -SkuName Standard_ZRS
   $DataSnapshot = New-AzSnapshot -Snapshot $snapshotDataConfig -SnapshotName ($disk.Name + '-snapshot') -ResourceGroupName $resourceGroup

   $diskSkuData = (Get-AzDisk -DiskName $disk.Name -ResourceGroupName $originalVM.ResourceGroupName).Sku.Name
   $datadiskConfig = New-AzDiskConfig -Location $DataSnapshot.Location -SourceResourceId $DataSnapshot.Id -CreateOption Copy -SkuName $diskSkuData -Zone $zone
   #$datadisk = New-AzDisk -Disk $datadiskConfig -ResourceGroupName $resourceGroup -DiskName ($disk.Name + '-migrated')
   $datadisk = New-AzDisk -Disk $datadiskConfig -ResourceGroupName $NewRG -DiskName $disk.Name
   $datadisktags = New-AzTag -ResourceId $datadisk.Id -Tag $originalVM.Tags
}
}

# Detach the existing Nics from the VM
$originalVM2 = Get-AzVM -ResourceGroupName $resourceGroup -Name $vmName
$ExistingNics2 = $originalVM2.NetworkProfile.NetworkInterfaces | Where-Object {$_.id -notlike "*PlaceHolderNIC"}
$NicNames = ($ExistingNics2.id -split '/')[-1]  
$nicIds = @()
$nicIds = foreach ($cnic in $NicNames) { (Get-AzNetworkInterface -ResourceGroupName $resourceGroup -Name $cnic).Id }
Write-Host "Removing NICS from original $vmName" -ForegroundColor Yellow
Remove-AzVMNetworkInterface -VM $originalVM2 -NetworkInterfaceIDs $nicIds | Update-AzVM -ResourceGroupName $resourceGroup -VM $originalVM2

# Move the existing Nics to the new RG
Write-Host "Moving Nics to new RG" -ForegroundColor Yellow
foreach($movednic in $ExistingNics2){
$movingnics = Get-AzResource -ResourceId $movednic.id
Move-AzResource -ResourceId $movingnics.ResourceId -DestinationResourceGroupName $NewRG -Force
}


# Remove the original VM
#Write-Host "Deleting the existing Azure VM: $vmName" -ForegroundColor Yellow
#Remove-AzVM -ResourceGroupName $resourceGroup -Name $vmName -Force

# Create the basic configuration for the replacement VM
$newVM = New-AzVMConfig -VMName $originalVM.Name -VMSize $originalVM.HardwareProfile.VmSize -Zone $zone -Tags $originalVM.Tags

# Add the pre-existed OS disk (for Linux servers - change to -Windows if for windows servers)
Write-Host "Setting New VM OS Disk" -ForegroundColor Yellow
if($osversion -eq "Windows") {
$OSConfig = Set-AzVMOSDisk -VM $newVM -CreateOption Attach -ManagedDiskId $OSdisk.Id -Name $OSdisk.Name -Windows
} else {
$OSConfig = Set-AzVMOSDisk -VM $newVM -CreateOption Attach -ManagedDiskId $OSdisk.Id -Name $OSdisk.Name -Linux
}


# Add NIC(s) and keep the same NIC as primary
# If there is a Public IP from the Basic SKU remove it because it doesn't supports zones
Write-Host "Adding Network Interfaces to VM" -ForegroundColor Yellow
foreach ($nic in $ExistingNics2) { 
  
   $NicName = ($nic.id -split '/')[-1]   
   $netInterface = Get-AzNetworkInterface -Name $NicName -ResourceGroupName $NewRG
   $publicIPId = $netInterface.IpConfigurations[0].PublicIpAddress.Id
   $publicIP = Get-AzPublicIpAddress -Name $publicIPId.Substring($publicIPId.LastIndexOf("/")+1) 
   if ($publicIP)
   {      
      if ($publicIP.Sku.Name -eq 'Basic')
      {
         $netInterface.IpConfigurations[0].PublicIpAddress = $null
         $NicConfig = Set-AzNetworkInterface -NetworkInterface $netInterface
      }
   }
if ($nic.Primary -eq "True")
   {
      $NicVMConfig = Add-AzVMNetworkInterface -VM $newVM -Id $netInterface.Id -Primary
   }
   else
   {
     $NicVMConfig = Add-AzVMNetworkInterface -VM $newVM -Id $netInterface.Id 
   }
}

# Recreate the VM
$newvmname = $newVM.name
Write-Host "Recreating Azure VM: $newvmname" -ForegroundColor Yellow
$NewVMStatus = New-AzVM -ResourceGroupName $NewRG -Location $originalVM.Location -VM $newVM -DisableBginfoExtension -WarningAction SilentlyContinue

$NewVMStatusCode = $NewVMStatus.StatusCode

# Add the pre-existed data disks
$NewcreatedVM = Get-AzVM -ResourceGroupName $NewRG -Name $newvmname
if($datadiskcheck -ne $null) {
Write-Host "Setting New VM Data Disks" -ForegroundColor Yellow
foreach ($d in $originalVM.StorageProfile.DataDisks) {
    $newdiskname = $d.name 
    Write-Host "Working on Disk $newdiskname" -ForegroundColor Yellow
    $newdatadisk = Get-AzDisk -ResourceGroupName $NewRG -DiskName $d.Name
    Add-AzVMDataDisk -VM $NewcreatedVM -Name $newdatadisk.Name -ManagedDiskId $newdatadisk.Id -Caching $d.Caching -Lun $d.Lun -DiskSizeInGB $d.DiskSizeGB -CreateOption Attach | Update-AzVM -ResourceGroupName $NewRG -VM $NewcreatedVM
}
}

if($NewVMStatus.IsSuccessStatusCode -eq $true) {
Write-Host "The VM: $newvmname, Has been successfully Migrated with Status Code: $NewVMStatusCode. Please now ensure any additional application configuration is completed such as configuring backups or patching if required. Please also check for any legacy Azure resources which may require removing" -ForegroundColor Green
} Else {
Write-Host "The VM: $newvmname, was not migrated successfully, Status Code: $NewVMStatusCode please restore VM from backup or attempt to recover from Snapshot" -ForegroundColor Red
}

# If the machine is SQL server, create a new SQL Server object
# New-AzSqlVM -ResourceGroupName $resourceGroup -Name $newVM.Name -Location $location -LicenseType PAYG 

<# This section deletes the original disk resources, following testing this can be un hashed if needed to help with tidy up. To enable this section delete line 205 and 220
#Clean up original disks
$originalVMOSDiskName = $originalVM.StorageProfile.OsDisk.Name
Write-Host "Deleting Original OSDisk $originalVMOSDiskName" -ForegroundColor Yellow
Remove-AzDisk -ResourceGroupName $originalVM.ResourceGroupName -DiskName $originalVMOSDiskName

#Clean up Data Disks
if($datadiskcheck -ne $null) {
Write-Host "Deleting Original Data Disks" -ForegroundColor Yellow
foreach ($disk in $originalVM.StorageProfile.DataDisks) {
$DDName = $disk.Name
Write-Host "Deleting Original Data Disk $DDName" -ForegroundColor Yellow
Remove-AzDisk -ResourceGroupName $originalVM.ResourceGroupName -Name $DDName
}
}
#>