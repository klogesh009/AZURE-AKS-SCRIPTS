﻿
$context=""
$context_account=(Get-AzContext).Account.Id
if($context_account -ne "5035c5b6-a856-4060-88ca-21122c49d5c9"){
  [Byte[]] $key = (1..16)
       $SecurePassword =Get-Content "F:\Infra\Scripts\azure.txt" | ConvertTo-SecureString -Key $key
       $Credential = new-Object System.Management.Automation.PSCredential ("5035c5b6-a856-4060-88ca-21122c49d5c9", $SecurePassword)
  Login-AzAccount -credential $Credential -ServicePrincipal -TenantId a095b75b-77a2-4e28-afc2-27edd1d6b0ab -Subscription REBUS_TEST
}
$outputCollection = @()
$outputObject = "" | Select subscription,snapshot_name,rg_name,tag_expiry,size_in_GB,region,id

$today_Date=Get-Date -Format o
$directory_path='F:\Infra\Reports\Snapshots'
$csv_path=$directory_path+"\Snapshots_prod_list_"+$today_Date.Split('T')[0]+".csv"

$all_subscriptions= Get-AzSubscription | Where-Object {$_.Name -eq "REBUS_PRODUCTION_SHARED_SVCS" -or $_.Name -eq "REBUS_PRODUCTION" -or $_.Name -eq "REBUS_PRODUCTION_COMMON_TOOLS"  }
foreach($current_subscription in $all_subscriptions)
{
    Select-AzSubscription -Subscription $current_subscription.Name
    $current_subscription.Name
    $snapshot=""
    $snapshots =""
    $snapshots = Get-AzSnapshot
    foreach($snapshot in $snapshots){
        $outputObject.subscription=""
        $outputObject.snapshot_name=""
        $outputObject.rg_name=""
        $outputObject.tag_expiry=""
        $outputObject.size_in_GB=""
        $outputObject.region=""
        $outputObject.id=""

        $outputObject.subscription=$current_subscription.Name
        $outputObject.snapshot_name=$snapshot.Name
        $outputObject.rg_name=$snapshot.ResourceGroupName
        $outputObject.tag_expiry=$snapshot.Tags["EXPIRY"]
        $outputObject.size_in_GB=$snapshot.DiskSizeGB
        $outputObject.region=$snapshot.Location
        $outputObject.id=$snapshot.Id

	    Export-Csv -Path $csv_path -inputobject $outputObject -Append -Force -NoTypeInformation
    }

}

Logout-AzAccount

