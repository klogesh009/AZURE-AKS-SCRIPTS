﻿param (
    [Parameter(Mandatory=$true)][string]$IP_input,
    [Parameter(Mandatory=$true)][string]$subscription,
    [Parameter(Mandatory=$true)][string]$disk_SKU,
    [Parameter(Mandatory=$true)][string]$disk_size
)

<#
$IP_input="10.110.5.6"
$subscription="REBUS_POC"
$disk_SKU="Standard_LRS"
$disk_size="32"
#>

#$context_1=(Get-AzContext).Subscription
#if(!$context_1){
      [Byte[]] $key = (1..16)
      $SecurePassword =Get-Content "F:\Infra\Scripts\azure.txt" | ConvertTo-SecureString -Key $key
      $Credential = new-Object System.Management.Automation.PSCredential ("5035c5b6-a856-4060-88ca-21122c49d5c9", $SecurePassword)
      Login-AzAccount -credential $Credential -ServicePrincipal -TenantId a095b75b-77a2-4e28-afc2-27edd1d6b0ab -Subscription REBUS_TEST
#}

function get_azure_resourceID_with_subscription {

  $IP_Address=$args[0]
  $subscription_id_func=$args[1]
  $break=$false
  $resource_ID="NIL"
  
    Select-AzSubscription -Subscription $subscription_id_func -ErrorAction Stop | Out-Null
    foreach($NIC in Get-AzNetworkInterface)
    {
        foreach($IP in $NIC.IpConfigurations)
        {
            if ($IP.PrivateIpAddress -eq $IP_Address)
            {
                $resource_ID=$NIC.VirtualMachine.id
                $break=$true
            }
            if($break -eq $true)
            {
                break
            }
        }
        if($break -eq $true)
        {
            break
        }
    }
    

   Write-Output  "$resource_ID"

 }

$resource_ID_get= get_azure_resourceID_with_subscription $IP_input $subscription
if($resource_ID_get -ne "" -and $resource_ID_get -ne "NIL"){   
   echo $resource_ID_get
   $vm_disk_names_list=@()
   $vm_disk_LUN_list=@()
   $i=0
   $vm_name=$resource_ID_get.Split("/")[-1]
   $vm_rg_name=$resource_ID_get.Split("/")[4]
   $subscription_id=$resource_ID_get.Split("/")[2]

   $vm_details=Get-AzVM -ResourceGroupName $vm_rg_name -Name $vm_name
   $vm_disk_count=$vm_details.StorageProfile.DataDisks.Count
   $new_disk_number=$vm_disk_count+1
   
   ## Assigning new disk name
   if($new_disk_number.ToString().Length -eq 1){
     $new_disk_name=$vm_name + "-datadisk" + '{0}{1}' -f '0',$new_disk_number
   }
   else{
     $new_disk_name=$vm_name + "-datadisk" + '{1}' -f '0',$new_disk_number
   }
   $vm_disk_names_list=($vm_details.StorageProfile.DataDisks).Name
   while($new_disk_name -in $vm_disk_names_list -and $i -lt 20){
     $new_disk_number++
     if($new_disk_number.ToString().Length -eq 1){
       $new_disk_name=$vm_name + "-datadisk" + '{0}{1}' -f '0',$new_disk_number
     }
     else{
       $new_disk_name=$vm_name + "-datadisk" + '{1}' -f '0',$new_disk_number
     }
     $i++
   }
   if($i -ge 20){
     echo "PROCESS FAILURE: Issue in naming the the Disk"
     exit 1
   }
   echo "New disk name is $new_disk_name"

   ## Assigning new disk LUN
   $i=0
   $vm_disk_LUN_list=($vm_details.StorageProfile.DataDisks).Lun
   $new_disk_LUN=$vm_disk_count
   while($new_disk_LUN -in $vm_disk_LUN_list -and $i -lt 20){
     $new_disk_LUN++
     $i++
   }
   if($i -ge 20){
     echo "PROCESS FAILURE: Issue in naming the LUN of the Disk"
     exit 1
   }
   echo "New disk LUN is $new_disk_LUN"

   $vm=Get-AzVM -ResourceGroupName $vm_rg_name -Name $vm_name
   if($vm.Zones){
     $diskConfig = New-AzDiskConfig -Location $vm_details.Location -CreateOption Empty -DiskSizeGB $disk_size -SkuName $disk_SKU -Tag $vm_details.Tags -Zone $vm.Zones
   }
   else{
     $diskConfig = New-AzDiskConfig -Location $vm_details.Location -CreateOption Empty -DiskSizeGB $disk_size -SkuName $disk_SKU -Tag $vm_details.Tags
   }
   
   $dataDisk = New-AzDisk -ResourceGroupName $vm_rg_name -DiskName $new_disk_name -Disk $diskConfig
   $vm = Add-AzVMDataDisk -VM $vm -Name $new_disk_name -CreateOption Attach -ManagedDiskId $dataDisk.Id -Lun $new_disk_LUN
   Update-AzVM -ResourceGroupName $vm_rg_name -VM $vm
   if(!$?){
     echo "PROCESS FAILURE: Operation not successful"
   }
}
 else{
   echo "PROCESS FAILURE: Resource Not found"
   exit 1
 }
