﻿
$context=(Get-AzContext).Subscription
if(!$context){
    Login-AzAccount -TenantId a095b75b-77a2-4e28-afc2-27edd1d6b0ab
}


$udr_input=import-csv -Path "F:\Infra\Scripts\Network\UDR_delete_input.csv"
$prev_sub=""
foreach($udr in $udr_input){
  if($prev_sub -ne $udr.Subscription){
    Select-AzSubscription -Subscription $udr.Subscription
    $prev_sub=$udr.Subscription
  }
  Get-AzRouteTable -ResourceGroupName $udr.ResourceGroupName -Name $udr.route_table | Remove-AzRouteConfig -Name $udr.route_name | Set-AzRouteTable
}