Get-AzVMSize -ResourceGroupName AM-RB-SITB-SS-CYB-RG01 -VMName rbsibtestbpvm01
$virtualMachine = Get-AzVM -ResourceGroupName AM-RB-SITB-SS-CYB-RG01 -VMName rbsibtestbpvm01

# The .HardwareProfile.VmSize is a property that is used from the $virtualMachine variable which contains the virtual machine information from the output of Get-AzVM
$virtualMachine.HardwareProfile.VmSize = "Standard_D2_v3"
#The .HardwareProfile.VmSize is used to define the new size of the virtual machine.

Update-AzVM -VMName rbsibtestbpvm01 -ResourceGroupName AM-RB-SITB-SS-CYB-RG01
$virtualMachine = Get-AzVM -ResourceGroupName AM-RB-SITB-SS-CYB-RG01 -VMName rbsibtestbpvm01
$virtualMachine.HardwareProfile
