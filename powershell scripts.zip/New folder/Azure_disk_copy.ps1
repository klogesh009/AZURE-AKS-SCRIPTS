﻿$source_subscription="REBUS_SIT-B_TEST" 
$source_rg_name="AM-RB-SITB-CO-SVW-RG01"
$source_disk_name="rbsibcosvwrlw01-datadisk01"
$destination_subscription="REBUS_SIT-B_TEST"
$destination_vm="rbsibcosvwrla02"
$destination_rg_name="AM-RB-SIB-CO-SVW-ARG01"
$destination_disk_name="rbsibcosvwrla02-datadisk01"
$zone=""

$context=(Get-AzContext).Subscription
if(!$context){
   [Byte[]] $key = (1..16)
    $SecurePassword =Get-Content "F:\Infra\Scripts\azure_nonprod.txt" | ConvertTo-SecureString -Key $key
    $Credential = new-Object System.Management.Automation.PSCredential ("962a8e28-2e38-486f-aa23-0dd7befe0c53", $SecurePassword)
    Login-AzAccount -credential   $Credential -ServicePrincipal -TenantId a095b75b-77a2-4e28-afc2-27edd1d6b0ab -Subscription $subscription
}

Select-AzSubscription -SubscriptionName $source_subscription

$managedDisk= Get-AzDisk -ResourceGroupName $source_rg_name -DiskName $source_disk_name

Select-AzSubscription -SubscriptionName $destination_subscription

$tags = @{ PROJECT="REBUS"; ENVIRONMENT="PRE PRODUCTION"; OWNER="INFRASTRUCTURE"; APPLICATION="Insights Microstrategy Reporting & Visualization"; COSTCENTERID="NA"; APPLICATION_CODE="RPV" }
#$vm_obj=Get-AzVM -ResourceGroupName $destination_rg_name -Name $destination_vm
if($zone -ne "NA" -and $zone -ne ""){
  $diskConfig = New-AzDiskConfig -SourceResourceId $managedDisk.id -Location $managedDisk.Location -Tag $tags -Zone $zone -CreateOption Copy
}
else{
  $diskConfig = New-AzDiskConfig -SourceResourceId $managedDisk.id -Location $managedDisk.Location -Tag $tags -CreateOption Copy
}


 New-AzDisk -Disk $diskConfig -DiskName $destination_disk_name -ResourceGroupName $destination_rg_name

