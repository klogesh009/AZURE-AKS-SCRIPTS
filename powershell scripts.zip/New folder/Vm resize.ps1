﻿Stop-AzVM -ResourceGroupName AM-RB-DVD-IT-IMG-RG01 -Name cemacppoc -Force
$vm = Get-AzVM -ResourceGroupName AM-RB-DVD-IT-IMG-RG01 -VM cemacppoc
$vm.HardwareProfile.VmSize = 'Standard_D3'
$vm.HardwareProfile.VmSize = "Standard_D3"
Update-AzVM -VM $vm -ResourceGroupName "AM-RB-DVD-IT-IMG-RG01"
$vm | Update-AzVM

[string]$vmname = 'cemacppoc'

Update-AzVM -VM $vm -ResourceGroupName $resourceGroup

Update-AzureRmVm -VM $VM -ResourceGroupName $VM.ResourceGroupName

Update-AzVm -VM $vmname -ResourceGroupName AM-RB-DVD-IT-IMG-RG01

 -Verbose

Start-AzVM -ResourceGroupName AM-RB-DVD-IT-IMG-RG01 -Name cemacppoc


login-azaccount