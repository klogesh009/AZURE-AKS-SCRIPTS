﻿$context=(Get-AzContext).Subscription
if(!$context){
   [Byte[]] $key = (1..16)
   $SecurePassword =Get-Content "F:\Infra\Scripts\azure_nonprod.txt" | ConvertTo-SecureString -Key $key
   $Credential = new-Object System.Management.Automation.PSCredential ("962a8e28-2e38-486f-aa23-0dd7befe0c53", $SecurePassword)
   Login-AzAccount -credential $Credential -ServicePrincipal -TenantId a095b75b-77a2-4e28-afc2-27edd1d6b0ab -Subscription REBUS_TEST
}

$outputObject = "" | Select jobID,time,output,error
$csv_path="F:\Infra\Reports\vm_resize_status.csv"
$temp_csv_path="F:\Syed\Scripts\2019\temp.csv"

Select-AzSubscription -SubscriptionName REBUS_DEVELOPMENT

$job_ids = New-Object System.Collections.ArrayList
$automation_account_name="AM-RB-DEV-D-AUT02"
$automation_account_rg_name="AM-RB-DEV-D-AUT-RG01"

$table=@()
$tableob=@()
Select-AzSubscription -Subscription fb0e2610-b464-45d2-a17f-efb765d887b8 | Out-null
$Ctx=(Get-AzStorageAccount -ResourceGroupName RB-DEV-AUTOMATION -Name rbdevautomationstg).Context
$cloudTable=(Get-AzStorageTable –Name VMRESIZE –Context $Ctx).CloudTable
$table_rows=Get-AzTableRow -table $cloudTable

foreach ($table_row in $table_rows) {
 $subscription=$table_row.subscription;
 $resourceGroup=$table_row.resourceGroup;
 $vmName=$table_row.vmName;
 $vmSize=$table_row.vmSize;

 $vmName+" "+$resourceGroup+" "+$subscription+" "+$vmSize
}

Write-Output "Do you want to resize for above servers ? Enter number"
Write-Output "1.Yes`r`n2.No"
$user_input = Read-Host "Option No"
if($user_input -ne "1"){
  exit
}

foreach ($table_row in $table_rows) {
$uri = "https://s2events.azure-automation.net/webhooks?token=r%2fc%2fDqZ9OoeZCkm279PIhtOW7mxMU2sNBXQ0wXgCOUc%3d"


$params = @{
 "subscription"=$table_row.subscription;
 "resourceGroup"=$table_row.resourceGroup;
 "vmName"=$table_row.vmName;
 "vmSize"=$table_row.vmSize;
}
$body = ConvertTo-Json -InputObject $params

$response = Invoke-RestMethod -Method Post -Uri $uri -Body $body
$job = (Get-AzAutomationJob –AutomationAccountName $automation_account_name –RunbookName "VM_RESIZE" -ResourceGroupName $automation_account_rg_name | sort LastModifiedDate –desc)[0]

$job_ids.Add($job)
Start-Sleep -Seconds 3

}


#$temp_job_status="dummy"
#while($temp_job_status -ne "Completed" -or $temp_job_status -ne "Suspended" -or $temp_job_status -ne "Stopped" -or $temp_job_status -ne "Failed"){
$job_count=$job_ids.Count
$temp_count=0
while($temp_count -lt $job_count){
 foreach($job1_obj in $job_ids){
  $job_id_check=""
  $vm_resize_csv=Import-Csv -Path $csv_path
  $job_obj=Get-AzAutomationJob –AutomationAccountName $automation_account_name –RunbookName "VM_RESIZE" -ResourceGroupName $automation_account_rg_name | Where-Object {$_.JobId -eq $job1_obj.JobId}
  if($job_obj.Status -eq "Completed" -or $job_obj.Status -eq "Suspended" -or $job_obj.Status -eq "Stopped" -or $job_obj.Status -eq "Failed"){
    $job_id_check=$vm_resize_csv | Where-Object{$_.jobID -eq $job_obj.JobId}
    if(!$job_id_check){
     $outputObject.jobID = ""
     $outputObject.output = ""
     $outputObject.time = ""
     $outputObject.error = ""
     $job_errors=""
     $job_outputs=""
     $job_outputs_error= Get-AzAutomationJobOutput -AutomationAccountName $automation_account_name -Id $job_obj.JobId -ResourceGroupName $automation_account_rg_name -Stream Error | Get-AzAutomationJobOutputRecord
     foreach($job_output_error in $job_outputs_error)
     {
      $job_error_1=$job_output_error.Value["Exception"]
      $job_error_1 | ConvertTo-Csv -NoTypeInformation > $temp_csv_path
      $job_error_2=Import-Csv $temp_csv_path
      $job_error_3=$job_error_2.parent[0] | ConvertFrom-Json
      $job_errors += $job_error_3.Message
#      $job_errors += (Get-AzAutomationJobOutputRecord -ResourceGroupName $automation_account_rg_name -JobId $job_output_error.JobId -AutomationAccountName $automation_account_name -id $job_output_error.StreamRecordId).Value["Exception"]    
     }
     $outputObject.error= $job_errors -join "`n"
     $job_outputs_output= Get-AzAutomationJobOutput -AutomationAccountName $automation_account_name -Id $job_obj.JobId -ResourceGroupName $automation_account_rg_name -Stream Output | Get-AzAutomationJobOutputRecord
     foreach($job_output_output in $job_outputs_output)
     {
      if($job_output_output.Value["value"]){
       $job_outputs += $job_output_output.Value["value"]

      }
#      $job_outputs += (Get-AzAutomationJobOutputRecord -ResourceGroupName $automation_account_rg_name -JobId $job_output_output.JobId -AutomationAccountName $automation_account_name -id $job_output_output.StreamRecordId).Value["value"]       
     }
     $outputObject.output = $job_outputs -join "`n"
     $outputObject.jobID = $job_obj.JobId
     $outputObject.time = $job_obj.StartTime
     $temp_count++
     Export-Csv -Path $csv_path -inputobject $outputObject -Append -Force -NoTypeInformation
    }
  }

 }
 Start-Sleep -Seconds 10

}




