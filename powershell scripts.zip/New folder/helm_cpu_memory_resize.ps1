﻿$csv_input= Import-Csv -Path "F:\Infra\Scripts\Automation\Inputs\helm_densify_upgrade_input.csv"

$csv_input | Format-Table
Write-Output "Do you want to resize for above containers ? Enter number"
Write-Output "1.Yes`r`n2.No"
$user_input = Read-Host "Option No"
if($user_input -ne "1"){
  exit
}

 # Write-Output "Which component do you want to perform upgrade ? Enter number"
 #   Write-Output "1.kube-state-metrics`r`n2.Prometheus`r`n3.Densify-forwarder`r`n4.All-Desnify`r`n5.Dynatrace"
 #   $user_input = Read-Host "Option No"

$previous_cluster=""
foreach( $aks_obj in $csv_input ){
  $cluster_name=""
  $rg_grp=""
  $subscription=""
  $taints_added=""
  $container_name=""
  $pod_name=""
  $controller=""

  $cluster_name=$aks_obj.cluster_name
  $rg_grp=$aks_obj.rg_name
  $subscription=$aks_obj.subscription
  $taints_added=$aks_obj.taints_added
  $taints_name=$aks_obj.taints_name
  if($taints_name){ $taints_name=$taints_name.replace(";",",") }
  $container_name=$aks_obj.container_name
  $pod_name=$aks_obj.pod_name
  $controller=$aks_obj.controller
  
  $app_code="{aks,ftl}"
  $kube_state_metrics_path="F:\Infra\Scripts\AKS\CAAS\helm\kube-state-metrics"
  $prometheus_path_server="F:\Infra\Scripts\AKS\CAAS\helm\prometheus"
  $prometheus_path_nodeExporter="F:\Infra\Scripts\AKS\CAAS\helm\prometheus\node-exporter"
  $densify_container_path="F:\Infra\Scripts\AKS\CAAS\helm\container-optimization-data-forwarder"
  $dynatrace_path="F:\Infra\Scripts\AKS\CAAS\helm\dynatrace"
  $dynatrace_cr_path="F:\Infra\Scripts\AKS\CAAS\helm\dynatrace\cr_files"

  if($previous_cluster -ne $cluster_name){
    az account set --s $subscription
    cmd.exe /c "az aks get-credentials --resource-group $rg_grp --name $cluster_name --admin --overwrite-existing"
    $previous_cluster=$cluster_name
  }
  
  $nodes_status_json=kubectl get nodes -o json | ConvertFrom-Json
  $node_ready=0
  foreach($nodes_status_obj in $nodes_status_json.items){
    $nodes_status_obj.metadata.name
    
    foreach( $nodes_status_cond_obj in $nodes_status_obj.status.conditions ){
      if( $nodes_status_cond_obj.reason -match "KubeletReady" ){      
        $nodes_status_cond_obj.type
        $node_ready=1
      }
    }
    if($node_ready -eq 0){
      "Nodes are not in READY state"
       exit
    }
  }

  $cpu_requests=""
  $cpu_limits=""
  $memory_requests=""
  $memory_limits=""

  $cpu_requests=$aks_obj.cpu_requests
  $cpu_limits=$aks_obj.cpu_limits
  $memory_requests=$aks_obj.memory_requests
  $memory_limits=$aks_obj.memory_limits
  
  
    
  if($container_name -eq "kube-state-metrics"){  
    $pods_kube_state=""
    $pods_kube_state=kubectl get pods -n densify | Select-String -SimpleMatch "kube-state-metrics"
    if($pods_kube_state ){
      
      #Upgrade of kube-state-metrics
      cd $kube_state_metrics_path
      if($cpu_requests -and $cpu_limits -and $memory_requests -and $memory_limits){
        $cpu_requests=$cpu_requests+"m"
        $cpu_limits=$cpu_limits+"m"
        $memory_requests=$memory_requests+"Mi"
        $memory_limits=$memory_limits+"Mi"
        helm upgrade kube-state-metrics -n densify --set taints_added=$taints_added --set resources.requests.cpu=$cpu_requests --set resources.requests.memory=$memory_requests --set resources.limits.cpu=$cpu_limits --set resources.limits.memory=$memory_limits . --atomic
       
        $pods_kubeMetrics_status=""
        $pods_kubeMetrics=""
        $pods_kubeMetrics_notRunning=$true
        
        while($pods_kubeMetrics_notRunning){
          $pods_kubeMetrics=kubectl get pods -n densify
          $pods_status = $pods_kubeMetrics | Select-String -SimpleMatch "kube-state-metrics" | Select-String -SimpleMatch "Running"
          if($pods_status){
            $pods_kubeMetrics_notRunning=$false
          }else{
            Start-Sleep -Seconds 10
          }
        }
        
        if($?){
          echo "kube-state-metrics upgraded successfully"
        }
      }
      else{
        echo "Please check if all values set for CPU and Memory for the container"
      }
      
        
    }
    else{
      echo "kube-state-metrics pods are not running"
    }
  }  

  if($container_name -match "prometheus"){  
    $pods_prometheus=""
    $pods_prometheus=kubectl get pods -n densify | Select-String -SimpleMatch "prometheus"
    if($pods_prometheus){
      #Installation of Prometheus
      $prometheus_pods=""
      $prometheus_pods=kubectl get pods -n densify -o json | ConvertFrom-Json
      $match_found=0
      $prometheus_pod_name=""
      $prometheus_pod=""
      $prom_pod_res=""
      $prom_pod_res_limits_cpu=""
      $prom_pod_res_limits_memory=""
      $prom_pod_res_requests_cpu=""
      $prom_pod_res_requests_memory=""

      ## Getting the other pod's cpu and memory values
      if($container_name -eq "prometheus-server"){ $pod_match_name="prometheus-node-exporter" }
      elseif($container_name -eq "prometheus-node-exporter"){ $pod_match_name="prometheus-server" }

      foreach($prometheus_pod in $prometheus_pods.items){  
        if($prometheus_pod.metadata.name -match $pod_match_name -and $match_found -eq 0){
          $match_found=1
          $prometheus_pod_name=$prometheus_pod.metadata.name
          $prometheus_pod=kubectl get pods $prometheus_pod_name -n densify -o json | ConvertFrom-Json
          $prom_pod_res=$prometheus_pod.spec.containers[0].resources
          $prom_pod_res_limits_cpu=$prom_pod_res.limits.cpu
          $prom_pod_res_limits_memory=$prom_pod_res.limits.memory
          $prom_pod_res_requests_cpu=$prom_pod_res.requests.cpu
          $prom_pod_res_requests_memory=$prom_pod_res.requests.memory
          break
        }
      }

       if($container_name -eq "prometheus-server"){
        
         if($cpu_requests -and $cpu_limits -and $memory_requests -and $memory_limits){
           cd $prometheus_path_server
           $cpu_requests=$cpu_requests+"m"
           $cpu_limits=$cpu_limits+"m"
           $memory_requests=$memory_requests+"Mi"
           $memory_limits=$memory_limits+"Mi"
           if($prom_pod_res_requests_cpu -and $prom_pod_res_requests_memory -and $prom_pod_res_limits_cpu -and $prom_pod_res_limits_memory){
            helm upgrade prometheus --set taints_added=$taints_added --set app_code=$taints_name `
            --set nodeExporter.resources.requests.cpu=$prom_pod_res_requests_cpu --set nodeExporter.resources.requests.memory=$prom_pod_res_requests_memory --set nodeExporter.resources.limits.cpu=$prom_pod_res_limits_cpu --set nodeExporter.resources.limits.memory=$prom_pod_res_limits_memory `
            --set server.resources.requests.cpu=$cpu_requests --set server.resources.requests.memory=$memory_requests --set server.resources.limits.cpu=$cpu_limits --set server.resources.limits.memory=$memory_limits -n densify . --atomic
           }
           else{
            helm upgrade prometheus --set taints_added=$taints_added --set app_code=$taints_name `
            --set server.resources.requests.cpu=$cpu_requests --set server.resources.requests.memory=$memory_requests --set server.resources.limits.cpu=$cpu_limits --set server.resources.limits.memory=$memory_limits -n densify . --atomic
           }
           
           if($?){
             echo "Prometheus installed successfully"
           }
         }
         else{
           echo "Please check if all values set for CPU and Memory for the container"
         }
       }
       elseif($container_name -eq "prometheus-node-exporter"){
         
         if($cpu_requests -and $cpu_limits -and $memory_requests -and $memory_limits){
           cd $prometheus_path_server
           $cpu_requests=$cpu_requests+"m"
           $cpu_limits=$cpu_limits+"m"
           $memory_requests=$memory_requests+"Mi"
           $memory_limits=$memory_limits+"Mi"
           if($prom_pod_res_requests_cpu -and $prom_pod_res_requests_memory -and $prom_pod_res_limits_cpu -and $prom_pod_res_limits_memory){
            helm upgrade prometheus --set taints_added=$taints_added --set app_code=$taints_name `
            --set server.resources.requests.cpu=$prom_pod_res_requests_cpu --set server.resources.requests.memory=$prom_pod_res_requests_memory --set server.resources.limits.cpu=$prom_pod_res_limits_cpu --set server.resources.limits.memory=$prom_pod_res_limits_memory `
            --set nodeExporter.resources.requests.cpu=$cpu_requests --set nodeExporter.resources.requests.memory=$memory_requests --set nodeExporter.resources.limits.cpu=$cpu_limits --set nodeExporter.resources.limits.memory=$memory_limits -n densify . --atomic
           }
           else{
            helm upgrade prometheus --set taints_added=$taints_added --set app_code=$taints_name `
            --set nodeExporter.resources.requests.cpu=$cpu_requests --set nodeExporter.resources.requests.memory=$memory_requests --set nodeExporter.resources.limits.cpu=$cpu_limits --set nodeExporter.resources.limits.memory=$memory_limits -n densify . --atomic
           }
           if($?){
             echo "Prometheus installed successfully"
           }
         }
         else{
           echo "Please check if all values set for CPU and Memory for the container"
         }
       }

      Start-Sleep -Seconds 10
    }
    else{
      echo "Prometheus pods are not running"
    }  
  }
    
  if($user_input -eq 3 -or $user_input -eq 4){
    $pods_densify=kubectl get pods -n densify | Select-String -SimpleMatch "densify"  
    if($pods_densify){
      #Installation of densify-forwarder
      
      cd $densify_container_path
      #helm delete densify-forwarder -n densify
      helm install densify-forwarder --set taints_added=$taints_added --set config.prometheus.clustername=$cluster_name --set config.zipname="data/$cluster_name" -n densify . --atomic
      
      if($?){
        echo "Densify Forwarder installed successfully"
      }
    }
  }
  

  
  if($container_name -match "dynatrace" -or $pod_name -match "dynatrace"){
    $pods_dynatrace=kubectl get pods -n dynatrace
    if($pods_dynatrace){
      #Upgrade of Dynatrace

      $dynatrace_pods=""
      $dynatrace_pods=kubectl get pods -n dynatrace -o json | ConvertFrom-Json
      $match_found=0
      $dynatrace_pod_name=""
      $dynatrace_pod=""
      $dyn_pod_res=""
      $dyn_pod_res_limits_cpu=""
      $dyn_pod_res_limits_memory=""
      $dyn_pod_res_requests_cpu=""
      $dyn_pod_res_requests_memory=""

      $env_name=$cluster_name.Substring(2,3)
      $owner_name=$cluster_name.Substring(5,2)
      $app_code=$cluster_name.Substring(7,3)
      $helm_dyn_name="dynatrace-"+$env_name+"-"+$app_code
      $helm_dyn_cr_name=$helm_dyn_name+"-cr"
      cd $dynatrace_path


      ## Getting the other pod's cpu and memory values
      if($container_name -eq "dynatrace-operator" -and $pod_name -match "dynatrace-operator"){ $pod_match_name="dynatrace-webhook" }
      elseif($container_name -eq "webhook"){ $pod_match_name="dynatrace-operator" }
      elseif($container_name -eq "dynatrace-oneagent"){ $pod_match_name="dynakube-activegate" }
      elseif($container_name -eq "dynatrace-operator" -and $pod_name -match "dynakube-activegate"){ $pod_match_name="dynakube-oneagent" }

      foreach($dynatrace_pod in $dynatrace_pods.items){  
        if($dynatrace_pod.metadata.name -match $pod_match_name -and $match_found -eq 0){
          $match_found=1
          $dynatrace_pod_name=$dynatrace_pod.metadata.name
          $dynatrace_pod=kubectl get pods $dynatrace_pod_name -n dynatrace -o json | ConvertFrom-Json
          $dyn_pod_res=$dynatrace_pod.spec.containers[0].resources
          $dyn_pod_res_limits_cpu=$dyn_pod_res.limits.cpu
          $dyn_pod_res_limits_memory=$dyn_pod_res.limits.memory
          $dyn_pod_res_requests_cpu=$dyn_pod_res.requests.cpu
          $dyn_pod_res_requests_memory=$dyn_pod_res.requests.memory
          break
        }
      }

      if($cpu_requests -and $cpu_limits -and $memory_requests -and $memory_limits){
       $cpu_requests=$cpu_requests+"m"
       $cpu_limits=$cpu_limits+"m"
       $memory_requests=$memory_requests+"Mi"
       $memory_limits=$memory_limits+"Mi"
      if($container_name -eq "dynatrace-operator" -and $pod_name -match "dynatrace-operator"){    
        if($taints_added -match "yes"){
          helm upgrade $helm_dyn_name -n dynatrace --set env=$env_name --set tolerations_app_codes=$taints_name `
          --set resources.operator.requests.cpu=$cpu_requests --set resources.operator.requests.memory=$memory_requests --set resources.operator.limits.cpu=$cpu_limits --set resources.operator.limits.memory=$memory_limits `
          --set resources.webhook.requests.cpu=$dyn_pod_res_requests_cpu --set resources.webhook.requests.memory=$dyn_pod_res_requests_memory --set resources.webhook.limits.cpu=$dyn_pod_res_limits_cpu --set resources.webhook.limits.memory=$dyn_pod_res_limits_memory `
          --set app_code=$app_code --set owner=$owner_name --set namespace_create=no --set tolerations_set=yes . --atomic
        }
        else{
          helm upgrade $helm_dyn_name -n dynatrace --set env=$env_name --set app_code=$app_code `
          --set resources.operator.requests.cpu=$cpu_requests --set resources.operator.requests.memory=$memory_requests --set resources.operator.limits.cpu=$cpu_limits --set resources.operator.limits.memory=$memory_limits `
          --set resources.webhook.requests.cpu=$dyn_pod_res_requests_cpu --set resources.webhook.requests.memory=$dyn_pod_res_requests_memory --set resources.webhook.limits.cpu=$dyn_pod_res_limits_cpu --set resources.webhook.limits.memory=$dyn_pod_res_limits_memory `
          --set owner=$owner_name --set namespace_create=no --set tolerations_set=no . --atomic
        }
      }
      elseif($container_name -eq "webhook"){       
        if($taints_added -match "yes"){
          helm upgrade $helm_dyn_name -n dynatrace --set env=$env_name --set tolerations_app_codes=$taints_name `
          --set resources.webhook.requests.cpu=$cpu_requests --set resources.webhook.requests.memory=$memory_requests --set resources.webhook.limits.cpu=$cpu_limits --set resources.webhook.limits.memory=$memory_limits `
          --set resources.operator.requests.cpu=$dyn_pod_res_requests_cpu --set resources.operator.requests.memory=$dyn_pod_res_requests_memory --set resources.operator.limits.cpu=$dyn_pod_res_limits_cpu --set resources.operator.limits.memory=$dyn_pod_res_limits_memory `
          --set app_code=$app_code --set owner=$owner_name --set namespace_create=no --set tolerations_set=yes . --atomic
        }
        else{
          helm upgrade $helm_dyn_name -n dynatrace --set env=$env_name --set app_code=$app_code `
          --set resources.webhook.requests.cpu=$cpu_requests --set resources.webhook.requests.memory=$memory_requests --set resources.webhook.limits.cpu=$cpu_limits --set resources.webhook.limits.memory=$memory_limits `
          --set resources.operator.requests.cpu=$dyn_pod_res_requests_cpu --set resources.operator.requests.memory=$dyn_pod_res_requests_memory --set resources.operator.limits.cpu=$dyn_pod_res_limits_cpu --set resources.operator.limits.memory=$dyn_pod_res_limits_memory `
          --set owner=$owner_name --set namespace_create=no --set tolerations_set=no . --atomic
        }
      }
      elseif($container_name -eq "dynatrace-oneagent"){       
        cd $dynatrace_cr_path
        if($taints_added -match "yes"){
          helm upgrade $helm_dyn_cr_name -n dynatrace --set env=$env_name --set tolerations_app_codes=$taints_name `
          --set resources.oneAgent.requests.cpu=$cpu_requests --set resources.oneAgent.requests.memory=$memory_requests --set resources.oneAgent.limits.cpu=$cpu_limits --set resources.oneAgent.limits.memory=$memory_limits `
          --set resources.activeGate.requests.cpu=$dyn_pod_res_requests_cpu --set resources.activeGate.requests.memory=$dyn_pod_res_requests_memory --set resources.activeGate.limits.cpu=$dyn_pod_res_limits_cpu --set resources.activeGate.limits.memory=$dyn_pod_res_limits_memory `
          --set app_code=$app_code --set owner=$owner_name --set namespace_create=no --set tolerations_set=yes . --atomic
        }
        else{
          helm upgrade $helm_dyn_cr_name -n dynatrace --set env=$env_name --set app_code=$app_code `
          --set resources.oneAgent.requests.cpu=$cpu_requests --set resources.oneAgent.requests.memory=$memory_requests --set resources.oneAgent.limits.cpu=$cpu_limits --set resources.oneAgent.limits.memory=$memory_limits `
          --set resources.activeGate.requests.cpu=$dyn_pod_res_requests_cpu --set resources.activeGate.requests.memory=$dyn_pod_res_requests_memory --set resources.activeGate.limits.cpu=$dyn_pod_res_limits_cpu --set resources.activeGate.limits.memory=$dyn_pod_res_limits_memory `
          --set owner=$owner_name --set namespace_create=no --set tolerations_set=no . --atomic
        }
      }
      elseif($container_name -eq "dynatrace-operator" -and $pod_name -match "dynakube-activegate"){       
        cd $dynatrace_cr_path
        if($taints_added -match "yes"){
          helm upgrade $helm_dyn_cr_name -n dynatrace --set env=$env_name --set tolerations_app_codes=$taints_name `
          --set resources.activeGate.requests.cpu=$cpu_requests --set resources.activeGate.requests.memory=$memory_requests --set resources.activeGate.limits.cpu=$cpu_limits --set resources.activeGate.limits.memory=$memory_limits `
          --set resources.oneAgent.requests.cpu=$dyn_pod_res_requests_cpu --set resources.oneAgent.requests.memory=$dyn_pod_res_requests_memory --set resources.oneAgent.limits.cpu=$dyn_pod_res_limits_cpu --set resources.oneAgent.limits.memory=$dyn_pod_res_limits_memory `
          --set app_code=$app_code --set owner=$owner_name --set namespace_create=no --set tolerations_set=yes . --atomic
        }
        else{
          helm upgrade $helm_dyn_cr_name -n dynatrace --set env=$env_name --set app_code=$app_code `
          --set resources.activeGate.requests.cpu=$cpu_requests --set resources.activeGate.requests.memory=$memory_requests --set resources.activeGate.limits.cpu=$cpu_limits --set resources.activeGate.limits.memory=$memory_limits `
          --set resources.oneAgent.requests.cpu=$dyn_pod_res_requests_cpu --set resources.oneAgent.requests.memory=$dyn_pod_res_requests_memory --set resources.oneAgent.limits.cpu=$dyn_pod_res_limits_cpu --set resources.oneAgent.limits.memory=$dyn_pod_res_limits_memory `
          --set owner=$owner_name --set namespace_create=no --set tolerations_set=no . --atomic
        }
      }


      }
      else{
        echo "Please check if all values set for CPU and Memory for the container"
      }

    }

  }


  if($pod_name -match "trident-csi"){
    $pods_trident=""
    $pods_trident=kubectl get pods -n trident
    if($pods_trident){
      #Upgrade of Trident

      $trident_Deployment_pods=@('csi-provisioner','csi-attacher','csi-resizer','csi-snapshotter','trident-main','trident-autosupport')
      $trident_Daemonset_pods=@('trident-main','driver-registrar')

      if($cpu_requests -and $cpu_limits -and $memory_requests -and $memory_limits){
        $file_path=""
        $deployment_yaml=""
        $cpu_requests=$cpu_requests+"m"
        $cpu_limits=$cpu_limits+"m"
        $memory_requests=$memory_requests+"Mi"
        $memory_limits=$memory_limits+"Mi"
        $trident_pods=""
        $trident_pods=kubectl get pods -n trident -o json | ConvertFrom-Json
        if($container_name -in $trident_Deployment_pods -and $controller -match "Deployment"){
          $file_path="F:\Infra\Scripts\AKS\CAAS\trident-deployment-update.yaml"
          $deployment_yaml="
spec:
  template:
    spec:
      containers:
      - name: $container_name
        resources:
          requests:
            cpu: $cpu_requests
            memory: $memory_requests
          limits:
            cpu: $cpu_limits
            memory: $memory_limits
          "
          echo $deployment_yaml > $file_path
          kubectl patch deployment trident-csi --patch-file $file_path -n trident
          Start-Sleep -Seconds 10
        }

        elseif($container_name -in $trident_Daemonset_pods -and $controller -match "DaemonSet"){
          $file_path="F:\Infra\Scripts\AKS\CAAS\trident-deployment-update.yaml"
          $deployment_yaml="
spec:
  template:
    spec:
      containers:
      - name: $container_name
        resources:
          requests:
            cpu: $cpu_requests
            memory: $memory_requests
          limits:
            cpu: $cpu_limits
            memory: $memory_limits
          "
          echo $deployment_yaml > $file_path
          kubectl patch daemonset trident-csi --patch-file $file_path -n trident
          Start-Sleep -Seconds 10
        }

      }
      else{
        echo "Please check if all values set for CPU and Memory for the container"
      }

    }
    else{
      echo "Trident pods are not present"
    }
  }


  

}