﻿Az#Import-AzureRmContext -Path F:\Infra\Scripts\profile1.json
#login-AzAccount -TenantId "a095b75b-77a2-4e28-afc2-27edd1d6b0ab"
#Select-AzSubscription -Subscription $subscription

$context=(Get-AzContext).Subscription
if(!$context){
   [Byte[]] $key = (1..16)
   $SecurePassword =Get-Content "F:\Infra\Scripts\azure.txt" | ConvertTo-SecureString -Key $key
   $Credential = new-Object System.Management.Automation.PSCredential ("5035c5b6-a856-4060-88ca-21122c49d5c9", $SecurePassword)
   Login-AzAccount -credential $Credential -ServicePrincipal -TenantId a095b75b-77a2-4e28-afc2-27edd1d6b0ab -Subscription REBUS_TEST
   }

$outputObject = "" | Select source_vmname,target_vmname,job_id,start_time,end_time

Select-AzSubscription -SubscriptionName REBUS_DEVELOPMENT

$tags = import-csv "F:\Infra\Scripts\VM Migrate\vm_migrate_6.csv"

foreach ($tag in $tags) {
$uri = "https://s2events.azure-automation.net/webhooks?token=4kZDIOAivn2MjbBrS14l5PQWP2mQtDrTt%2bGsfvFuJc8%3d"

$outputObject.source_vmname = ""
$outputObject.target_vmname = ""
$outputObject.job_id = ""
$outputObject.start_time = ""
$outputObject.end_time = ""

$outputObject.source_vmname = $tag.sourcevmname
$outputObject.target_vmname = $tag.VmName

$params = @{
 "sourcevmname"=$tag.sourcevmname;
 "sourceresourcegroupname"=$tag.sourceresourcegroupname;
 "sourcesubscriptionname"=$tag.sourcesubscriptionname;
 "VmName"=$tag.VmName;
 "Vnetname"=$tag.Vnetname;
 "Subnetname"=$tag.Subnetname;
 "privateIPAddress"=$tag.privateIPAddress;
 "VMSize"=$tag.VMSize;
 "ResourceGroupName"=$tag.ResourceGroupName;
 "SubscriptionName"=$tag.SubscriptionName;
 "vnetrgname"=$tag.vnetrgname;
 "AvailabilitySetName"=$tag.AvailabilitySetName;
 "zone"=$tag.zone;
 "Tag_Application"=$tag.Tag_APPLICATION
 "Tag_Application_Code"=$tag.Tag_Application_Code
 "Tag_CostCenterID"=$tag.Tag_COSTCENTERID
 "Tag_Environment"=$tag.Tag_ENVIRONMENT
 "Tag_Owner"=$tag.Tag_OWNER
 "Tag_Project"=$tag.Tag_PROJECT
}
$body = ConvertTo-Json -InputObject $params

[Net.ServicePointManager]::SecurityProtocol = 'Tls12'
$response = Invoke-RestMethod -Method Post -Uri $uri -Body $body
$job = (Get-AzAutomationJob –AutomationAccountName "AM-RB-DEV-D-AUT02" –RunbookName "AM-RB-VM_Clone_Webhook" -ResourceGroupName "AM-RB-DEV-D-AUT-RG01" | sort LastModifiedDate –desc)[0]


Start-Sleep -Seconds 5

$outputObject.job_id = $job.JobId
$outputObject.start_time = $job.CreationTime
$outputObject.end_time = $job.LastModifiedTime

Export-Csv -Path "F:\Infra\Scripts\VM Migrate\data_vm_migrate_1.csv" -inputobject $outputObject -Append -Force

}