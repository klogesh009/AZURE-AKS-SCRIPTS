﻿$context=(Get-AzContext).Subscription
if(!$context){
   [Byte[]] $key = (1..16)
  $SecurePassword =Get-Content "F:\Infra\Scripts\azure.txt" | ConvertTo-SecureString -Key $key
  $Credential = new-Object System.Management.Automation.PSCredential ("5035c5b6-a856-4060-88ca-21122c49d5c9", $SecurePassword)
   Login-AzAccount -credential $Credential -ServicePrincipal -TenantId a095b75b-77a2-4e28-afc2-27edd1d6b0ab -Subscription REBUS_TEST
}

 $console_output=@"
Please input the VM's at F:\Infra\Scripts\VM_Start_Stop\vm_table_Update_Insert.csv
You want to
1. Update
2. Insert
"@

echo $console_output
$update_input = Read-Host 'Option ?'

if($update_input -eq 1){
 $table_details_csv=Import-Csv -Path F:\Infra\Scripts\VM_Start_Stop\VM_ScheduleDetails_start_stop.csv

 $vm_input_csv=Import-csv -path F:\Infra\Scripts\VM_Start_Stop\vm_table_Update_Insert.csv
 $updated_table_rows = New-Object System.Collections.ArrayList
 $updated_table_rows_notFound_list = New-Object System.Collections.ArrayList

 $sub_previous=""
 foreach($vm in $vm_input_csv){
    $table_vm_obj=$table_details_csv | where-object {$_.VmName -eq $vm.VMName.Trim() -and $_.table_name -eq $vm.table_name.Trim() -and $_.ResourceGroupName -eq $vm.ResourceGroupName.Trim()}
    if($table_vm_obj -eq $null){
        $temp_output=$vm.VMName+"   "+"Not Found"
        $updated_table_rows_notFound_list.Add($temp_output)
    }
    else{
       $Ctx=""
       $table = ""
       $vm_table_row=""
       $table_vm_obj_count=($table_vm_obj | measure).Count
       if($table_vm_obj_count -eq 1){
         if($table_vm_obj.sub_id -ne $sub_previous){
           Select-AzSubscription -Subscription $table_vm_obj.sub_id
           $sub_previous=$table_vm_obj.sub_id
         }
         $Ctx=(Get-AzStorageAccount -ResourceGroupName $table_vm_obj.stg_rg -Name $table_vm_obj.stg).Context
         $table = Get-AzStorageTable -Context $Ctx –Name $table_vm_obj.table_name
		 $cloudTable = (Get-AzStorageTable –Name $table_vm_obj.table_name –Context $Ctx).CloudTable
		 $vm_table_row=Get-AzTableRow -table $cloudTable -columnName "PartitionKey" -value $table_vm_obj.partition_key -operator Equal
#         $vm_table_row=Get-AzureStorageTableRowByColumnName -table $table -columnName "PartitionKey" -value $table_vm_obj.partition_key -operator Equal
         $vm_table_row.ScheduleGroup=$vm.ScheduleGroup.Trim()
         $vm_table_row.Time=$vm.Time.Trim()
         $vm_table_row | Update-AzTableRow -table $cloudTable
		 $vm_table_row_updated=Get-AzTableRow -table $cloudTable -columnName "PartitionKey" -value $table_vm_obj.partition_key -operator Equal
#         $vm_table_row_updated=Get-AzureStorageTableRowByColumnName -table $table -columnName "PartitionKey" -value $table_vm_obj.partition_key -operator Equal
         $updated_table_rows.Add($vm_table_row_updated)
       }
       else{
         $temp_output=$vm.VMName+"   "+"More values found"
         $updated_table_rows_notFound_list.Add($temp_output)
       }

    }
 }

 $updated_table_rows | Format-Table
 $updated_table_rows_notFound_list

}

elseif($update_input -eq 2){
 F:\Syed\Scripts\Azure_get_TableScheduleDetails.ps1
 $table_details_csv=Import-Csv -Path F:\Infra\Scripts\VM_Start_Stop\VM_ScheduleDetails_start_stop.csv
 $vm_details_csv=Import-Csv -Path F:\Syed\Reports\vm_status_with_uptime.csv

 $vm_input_csv=Import-csv -path F:\Infra\Scripts\VM_Start_Stop\vm_table_Update_Insert.csv
 $inserted_table_rows = New-Object System.Collections.ArrayList
 $inserted_table_rows_notFound_list  = New-Object System.Collections.ArrayList
 $sub_previous=""
 foreach($vm in $vm_input_csv){
    $Ctx=""
    $table=""
    $vm_table_row=""
    $table_vm_obj=""
    $table_vm_obj=$table_details_csv | where-object { $_.table_name -eq $vm.table_name } | Select-Object -First 1
    if($table_vm_obj.sub_id -ne $sub_previous){
        Select-AzSubscription -Subscription $table_vm_obj.sub_id
        $sub_previous=$table_vm_obj.sub_id
    }
    $Ctx=(Get-AzStorageAccount -ResourceGroupName $table_vm_obj.stg_rg -Name $table_vm_obj.stg).Context
    $table = Get-AzStorageTable -Context $Ctx –Name $table_vm_obj.table_name
	$cloudTable = (Get-AzStorageTable –Name $table_vm_obj.table_name –Context $Ctx).CloudTable
    $table_Max_PartitionKey=[int](Get-AzTableRow -table $cloudTable | Sort-Object { [int]$_.PartitionKey } -Descending | Select-Object -First 1).PartitionKey
    $partion_key=$row_key=$table_Max_PartitionKey+1
    $vm_environment=($vm_details_csv | Where-Object{$_.vm_name -eq $vm.VmName -and $_.rg_name -eq $vm.ResourceGroupName} | Select-Object -First 1).environment
    if($table_Max_PartitionKey -and $vm_environment){
      $ScheduleGroup=$vm.ScheduleGroup.Trim()
      $Time=$vm.Time.Trim()
      $VMName=$vm.VmName.Trim()
      $ResourceGroupName=$vm.ResourceGroupName.Trim()
      $vm_environment=$vm_environment.Trim()
 #     $vm_table_exists=Get-AzureStorageTableRowByColumnName -table $table -columnName "VMName" -value $VMName -operator Equal
      $vm_table_exists=Get-AzTableRow -table $cloudTable -columnName "VMName" -value $VMName -operator Equal
      if($vm_table_exists){
        if($vm_table_exists.VMName -eq $vm.VmName -and $vm_table_exists.ResourceGroupName -eq $vm.ResourceGroupName){
            $temp_output=$vm.VmName+"   "+"Already exists"
            $inserted_table_rows_notFound_list.Add($temp_output)
        }
        else{
            Add-AzTableRow -table $cloudTable -partitionKey $partion_key -rowKey $row_key -property @{"Environment"=("$vm_environment");"ResourceGroupName"=("$ResourceGroupName");"ScheduleGroup"=("$ScheduleGroup");"Time"=("$Time");"VMName"=("$VMName")}
 #           $vm_table_row_inserted=Get-AzureStorageTableRowByColumnName -table $Table -columnName "PartitionKey" -value $partion_key -operator Equal
			$vm_table_row_inserted=Get-AzTableRow -table $cloudTable -columnName "PartitionKey" -value $partion_key -operator Equal
            $inserted_table_rows.Add($vm_table_row_inserted)
        }
      }
      else{
         Add-AzTableRow -table $cloudTable -partitionKey $partion_key -rowKey $row_key -property @{"Environment"=("$vm_environment");"ResourceGroupName"=("$ResourceGroupName");"ScheduleGroup"=("$ScheduleGroup");"Time"=("$Time");"VMName"=("$VMName")}
         $vm_table_row_inserted=Get-AzTableRow -table $cloudTable -columnName "PartitionKey" -value $partion_key -operator Equal
         $inserted_table_rows.Add($vm_table_row_inserted)
      }
      
    }
    else{
         $temp_output=$vm.VmName+"   "+"Issues found in Inserting"
         $inserted_table_rows_notFound_list.Add($temp_output)
    }
    
    

 }

 $inserted_table_rows | Format-Table
 $inserted_table_rows_notFound_list

}