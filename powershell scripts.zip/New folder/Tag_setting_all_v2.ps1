﻿$outputCollection = @()
$outputObject = "" | Select rname

##Input Path
$tags = import-csv "F:\Syed\2020\Oct\tags_update_191020.csv"

$context_account=(Get-AzContext).Account.Id
if($context_account -ne "5035c5b6-a856-4060-88ca-21122c49d5c9"){
  [Byte[]] $key = (1..16)
  $SecurePassword =Get-Content "F:\Infra\Scripts\azure.txt" | ConvertTo-SecureString -Key $key
  $Credential = new-Object System.Management.Automation.PSCredential ("5035c5b6-a856-4060-88ca-21122c49d5c9", $SecurePassword)
  Login-AzAccount -credential $Credential -ServicePrincipal -TenantId a095b75b-77a2-4e28-afc2-27edd1d6b0ab -Subscription REBUS_TEST
}


$output_csv="F:\Infra\Reports\tag_status\updated_tags.csv"

#Select-AzureRmProfile -Path F:\Infra\Scripts\profile1.json

$previous_sub=''


foreach ($tag in $tags) {

    if($previous_sub -ne $tag.subscription)
    {
        Select-AzSubscription -Subscription $tag.subscription
        $previous_sub=$tag.subscription
    }

    if($tag.ResourceType -eq "ResourceGroup" ){
        Set-AzResourceGroup -Tag @{ 
"PROJECT"=$tag.Tag_PROJECT.Trim();
"ENVIRONMENT"=$tag.Tag_ENVIRONMENT.Trim();
"OWNER"=$tag.Tag_OWNER.Trim();
"APPLICATION"=$tag.Tag_APPLICATION.Trim();
"COSTCENTERID"="NA";
"APPLICATION_CODE"=$tag.Tag_APPLICATION_CODE.Trim();
"VENDOR"=$tag.Tag_VENDOR.Trim();
"DOMAIN"=$tag.Tag_DOMAIN.Trim();
"SL_CATEGORY"=$tag.Tag_SL_CATEGORY.Trim() } -Name $tag.ResourceGroupName
        $outputObject.rname = $tag.ResourceGroupName
        Export-Csv -Path $output_csv -inputobject $outputObject -Append -Force
    
    }
    else{
  #      $resource_obj=Get-AzResource -Name $tag.Resource -ResourceGroupName $tag.ResourceGroupName
Set-AzResource -Tag @{ 
"PROJECT"=$tag.Tag_PROJECT.Trim();
"ENVIRONMENT"=$tag.Tag_ENVIRONMENT.Trim();
"OWNER"=$tag.Tag_OWNER.Trim();
"APPLICATION"=$tag.Tag_APPLICATION.Trim();
"COSTCENTERID"="NA";
"APPLICATION_CODE"=$tag.Tag_APPLICATION_CODE.Trim();
"VENDOR"=$tag.Tag_VENDOR.Trim();
"DOMAIN"=$tag.Tag_DOMAIN.Trim();
"SL_CATEGORY"=$tag.Tag_SL_CATEGORY.Trim() } -ResourceName $tag.Resource -ResourceType $tag.ResourceType -ResourceGroupName $tag.ResourceGroupName -Force

$outputObject.rname = $tag.Resource
Export-Csv -Path $output_csv -inputobject $outputObject -Append -Force

}

}

Logout-AzAccount