﻿$subscription = Read-Host 'Subscription Name'

$context=(Get-AzContext).Subscription
if(!$context){
    Login-AzAccount -TenantId a095b75b-77a2-4e28-afc2-27edd1d6b0ab
}

Select-AzSubscription -Subscription $subscription

$udr_input_csv=Import-Csv -Path "F:\Infra\Scripts\Network\udr_create_input.csv"

$prev_rg=""
$prev_udr=""
foreach($udr_input in $udr_input_csv){
  if($udr_input.Resourcegroupname -ne $prev_rg -and $udr_input.RouteName -ne $prev_udr){
    $prev_rg=$udr_input.Resourcegroupname
    $prev_udr=$udr_input.RouteName
    $RouteTable = Get-AzRouteTable -ResourceGroupName $udr_input.Resourcegroupname -Name $udr_input.RouteName
  }Add-AzRouteConfig -Name $udr_input.UDRName -AddressPrefix $udr_input.addressPrefix -NextHopType $udr_input.nextHopType -NextHopIpAddress $udr_input.nextHopIpAddress -RouteTable $RouteTable | Set-AzRouteTable
  
}
