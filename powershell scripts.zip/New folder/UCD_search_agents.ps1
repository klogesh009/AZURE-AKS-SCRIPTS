﻿$udclient_path="C:\opt\ibm-ucd\WIN_SHAREDSERVICES_RB-DV-RDS-RG01.10.10.105.18\opt\udclient"
cd $udclient_path
$agents_list=.\udclient.cmd -username PasswordIsAuthToken -password c20169e4-d457-4b27-901b-87d1e04cb3f9 -weburl https://172.29.175.78:8443 getAgents | ConvertFrom-Json
$relay_list=.\udclient.cmd -username PasswordIsAuthToken -password c20169e4-d457-4b27-901b-87d1e04cb3f9 -weburl https://172.29.175.78:8443 getRelays | ConvertFrom-Json
#$resources_list=.\udclient.cmd -username PasswordIsAuthToken -password e90b4cb4-d6ce-4bb0-a68f-dc81cf4a1b2a -weburl https://172.29.175.78:8443 getRelayStatuses | ConvertFrom-Json

$offline_agents = New-Object System.Collections.ArrayList
$outputCollection = @()
$outputObject = "" | Select IP,agent_name,status,relay,groovy_home

$agent_list=Import-Csv -Path "F:\Infra\Scripts\Automation\Inputs\ucd_agents_ip_input.csv"

$today_Date=Get-Date -Format o
$directory_path='F:\Infra\Scripts\Automation\Outputs\UCD_agents_status'
$csv_path=$directory_path+"\ucd_agent_status_"+ $today_Date.Split('T')[0]+".csv"

foreach($agent in $agent_list){

  $outputObject.IP=""
  $outputObject.agent_name=""
  $outputObject.status=""
  $outputObject.relay=""
  $outputObject.groovy_home=""
  
  $agent_obj=$agents_list | Where-Object {$_.name -match $agent.ips}
  if($agent_obj){
   if($agent_obj.Count -gt 1){
     foreach($agent_obj_1 in $agent_obj ){
        $ucd_agent_ip=($agent_obj_1.name  |  Select-String -Pattern "\b(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\b" -AllMatches).Matches.Value 
        if($agent.ips -eq $ucd_agent_ip){
            $outputObject.IP=$agent.ips
            $outputObject.agent_name=$agent_obj_1.name
            $outputObject.status=$agent_obj_1.status
 #           $groovy_home=.\udclient.cmd -username PasswordIsAuthToken -password c20169e4-d457-4b27-901b-87d1e04cb3f9 -weburl https://172.29.175.78:8443 getAgentProperty -agent $agent_obj_1.name -name GROOVY_HOME
            $outputObject.groovy_home=$groovy_home
            if($agent_obj_1.relayId){
              $relay_obj = $relay_list | Where-Object{$_.endpointId -match $agent_obj_1.relayId }
              if($relay_obj){
                $outputObject.relay=$relay_obj.name  
              }

            }
            if($agent_obj_1.status -match "OFFLINE"){
              $offline_agents.Add($agent_obj_1.name)
            }
        }
     }
     if($outputObject.IP -eq ""){
        $outputObject.IP=$agent.ips
        $outputObject.agent_name="Not found"
        $outputObject.status="NA"
     }
   }
   else{
     $ucd_agent_ip=($agent_obj.name  |  Select-String -Pattern "\b(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\b" -AllMatches).Matches.Value 
     if($agent.ips -eq $ucd_agent_ip){
            $outputObject.IP=$agent.ips
            $outputObject.agent_name=$agent_obj.name
            $outputObject.status=$agent_obj.status
     #       $groovy_home=.\udclient.cmd -username PasswordIsAuthToken -password c20169e4-d457-4b27-901b-87d1e04cb3f9 -weburl https://172.29.175.78:8443 getAgentProperty -agent $agent_obj.name -name GROOVY_HOME
            $outputObject.groovy_home=$groovy_home
            if($agent_obj.relayId){
              $relay_obj = $relay_list | Where-Object{$_.endpointId -match $agent_obj.relayId }
              if($relay_obj){
                $outputObject.relay=$relay_obj.name  
              }

            }
            if($agent_obj_1.status -match "OFFLINE"){
              $offline_agents.Add($agent_obj_1.name)
            }
     }
     else{
        $outputObject.IP=$agent.ips
        $outputObject.agent_name="Not found"
        $outputObject.status="NA"
     }
   }
  
  }
  else{
    $outputObject.IP=$agent.ips
    $outputObject.agent_name="Not found"
    $outputObject.status="NA"
  }
  Export-Csv -Path $csv_path -inputobject $outputObject -Append -Force -NoTypeInformation

}

<#
foreach($agent_name in $offline_agents){
 # .\udclient.cmd -username PasswordIsAuthToken -password c20169e4-d457-4b27-901b-87d1e04cb3f9 -weburl https://172.29.175.78:8443 restartAgent -agent $agent_name
}
#>