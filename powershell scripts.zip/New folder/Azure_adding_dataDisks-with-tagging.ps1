﻿#Login-AzAccount -TenantId a095b75b-77a2-4e28-afc2-27edd1d6b0ab
#Select-AzureRmSubscription -Subscription REBUS_SIT-B_TEST
#Select-AzSubscription -Subscription REBUS_SIT-B_SHARED_SVCS

$rgName = 'DU-RB-DRX-CO-OMS-RG01'
$vmName = 'rbdrxcoomsold02'
$location = 'westeurope' 
$storageType = 'Premium_SSD'
$no_of_disks = 20
$disk_size = 2048
$tags = @{ PROJECT="REBUS"; ENVIRONMENT="PRODUCTION DR"; OWNER="CORM"; APPLICATION="Order Management System"; COSTCENTERID="NA"; APPLICATION_CODE="OMS" }

$vm = Get-AzVM -Name $vmName -ResourceGroupName $rgName 


for($i=1;$i -le $no_of_disks;$i++){

    $diskConfig=""
    $dataDisk1=""
    $disk_no = $i+3
    $disk_number = "$disk_no"
    $dataDiskName = $vmName + '-datadisk' + $disk_number.PadLeft(2,'0')
    #$diskConfig = New-AzDiskConfig -SkuName $storageType -Location $location -CreateOption Empty -DiskSizeGB $disk_size -Tag $tags -Zone 3
    $diskConfig = New-AzDiskConfig -SkuName $storageType -Location $location -CreateOption Empty -DiskSizeGB $disk_size -Tag $tags
    $dataDisk1 = New-AzDisk -DiskName $dataDiskName -Disk $diskConfig -ResourceGroupName $rgName

    
    $vm = Add-AzVMDataDisk -VM $vm -Name $dataDiskName -CreateOption Attach -ManagedDiskId $dataDisk1.Id -Lun $disk_no

}

Update-AzVM -VM $vm -ResourceGroupName $rgName