﻿$vms_csv = import-csv "F:\Infra\Scripts\VM Migrate\Disk Migrate\vm_create_details.csv"


#Select-AzSubscription -SubscriptionName $subscription
#$subscription = "REBUS_DEVELOPMENT"


$deploy = {
   Param($sub_path,$vmName,$resourcegroupname,$vnetname,$vnetrgname,$subnetName,$PrivateIpAddress,$VMSize,$avset,$zone,$tag_project,$tag_owner,$tag_env,$tag_app,$tag_appcode,$subscription,$ucd_relay,$vm_os)
   [Byte[]] $key = (1..16)
   $SecurePassword =Get-Content "F:\Infra\Scripts\azure.txt" | ConvertTo-SecureString -Key $key
   $Credential = new-Object System.Management.Automation.PSCredential ("5035c5b6-a856-4060-88ca-21122c49d5c9", $SecurePassword)
   Login-AzAccount -credential $Credential -ServicePrincipal -TenantId a095b75b-77a2-4e28-afc2-27edd1d6b0ab -Subscription $subscription

   $vmName
   $disk_storageType="Standard_LRS"
   #$storage_account="amrbdeacodihadiag01"
   #VM Creation in Destination

    $newdisknames = New-Object System.Collections.ArrayList
    $disks = Get-AzResource | Where-Object {$_.ResourceGroupName -eq $resourcegroupname -and $_.ResourceType -eq "Microsoft.Compute/disks" -and $_.Name -match $vmName}
    $os_disk_name = ($disks | Where-Object {$_.Name -match "osdisk"}).Name
    $newdisknames.Add($os_disk_name)
    foreach ($disk in $disks){
    
        if($disk.Name -notmatch "osdisk"){
            $newdisknames.Add($disk.Name)
        }

    }

$rg_obj=Get-AzResourceGroup -Name $resourcegroupname
$tags = @{ PROJECT=$tag_project; ENVIRONMENT=$tag_env; OWNER=$tag_owner; APPLICATION=$tag_app; COSTCENTERID="NA"; APPLICATION_CODE=$tag_appcode }

$vnet=Get-AzVirtualNetwork -Name $vnetname -ResourceGroupName $vnetrgname
$subnet = Get-AzVirtualNetworkSubnetConfig -Name $subnetName -VirtualNetwork $vnet
$nic = New-AzNetworkInterface -Name "$VMName-nic01" -ResourceGroupName $resourcegroupname -Location $rg_obj.Location -SubnetId $Subnet.Id -PrivateIpAddress $PrivateIpAddress -Tag $tags -force
#$AvailabilitySet = Get-AzAvailabilitySet -ResourceGroupName $using:resourcegroupname -Name $using:av_set
if($zone -ne "na"){
	  $vm = New-AzVMConfig -VMName $VMName -VMSize $VMSize -Zone $zone
}
elseif($avset -ne "na"){
      $AvailabilitySet = Get-AzResource | Where-Object{$_.Name -eq $avset}
	  if($AvailabilitySet)
	  {
        $AvailabilitySet = Get-AzAvailabilitySet -ResourceGroupName $resourcegroupname -Name $avset
	  	$vm = New-AzVMConfig -VMName $VMName -VMSize $VMSize -AvailabilitySetId $AvailabilitySet.Id
	  }
	  else
	  {
		$temp=New-AzAvailabilitySet -Location $rg_obj.Location -Name $avset -ResourceGroupName $resourcegroupname -Sku aligned -Tag $tags -PlatformFaultDomainCount 3 -PlatformUpdateDomainCount 20
		Start-Sleep -Seconds 5
		$AvailabilitySet1 = Get-AzAvailabilitySet -ResourceGroupName $resourcegroupname -Name $avset
		$vm = New-AzVMConfig -VMName $vmName -VMSize $VMSize -AvailabilitySetId $AvailabilitySet1.Id
	  }
}
else{
    $vm = New-AzVMConfig -VMName $vmName -VMSize $VMSize -Tags $tags
}

#Set-AzureRmVMPlan -VM $vm -Publisher "kali-linux" -Product "kali-linux" -Name "kali"
$vm = Add-AzVMNetworkInterface -VM $vm -Id $nic.Id
#$VM=Set-AzureRmVMOperatingSystem -VM $VM -Windows -ComputerName $vmname -Credential $Credential -EnableAutoUpdate -ProvisionVMAgent
$osDisk=Get-AzDisk -ResourceGroupName $resourcegroupname -DiskName $newdisknames[0]
if($osDisk.OsType -match 'Linux' -or $vm_os -match 'Linux' )
{
    $vm = Set-AzVMOSDisk -VM $vm -ManagedDiskId $osDisk.Id -StorageAccountType $disk_storageType -CreateOption Attach -Linux
}
elseif($osDisk.OsType -match 'Windows' -or $vm_os -match 'Windows')
{
    $vm = Set-AzVMOSDisk -VM $vm -ManagedDiskId $osDisk.Id -StorageAccountType $disk_storageType -CreateOption Attach -Windows
}
$vm = Set-AzVMBootDiagnostic -VM $VM -Enable -ResourceGroupName $resourcegroupname
#New-AzureRmVM -ResourceGroupName $using:resourcegroupname -Location westeurope -VM $vm
#$vmobj= get-azurermvm -ResourceGroupName $targetResourceGroupName -Name $VMName
if($newdisknames.count -gt 1){ 
 for($i=1; $i -lt $newdisknames.count;$i++)
 {
  $datadisk=Get-AzDisk -ResourceGroupName $resourcegroupname -DiskName $newdisknames[$i]
  $vm = Add-AzVMDataDisk -VM $vm -Name $newdisknames[$i] -CreateOption Attach -ManagedDiskId $DataDisk.Id -Lun $i
  #Update-AzureRmVM -VM $vmobj -ResourceGroupName $using.ResourceGroupName
 }
}
New-AzVM -ResourceGroupName $resourcegroupname -Location $rg_obj.Location -VM $vm -tag $tags
#$resources = Get-AzResource | Where-Object {$_.ResourceGroupName -eq $resourcegroupname -or $_.ResourceName -match $VMName }
 #   foreach($resource in $resources){
 #               Set-AzResource -Tag @{ 
 #               "PROJECT"=$tag_project;
 #               "ENVIRONMENT"=$tag_env;
  #              "OWNER"=$tag_owner;
  #              "APPLICATION"=$tag_app;
  #              "COSTCENTERID"="NA";
  #              "APPLICATION_CODE"=$tag_appcode } -ResourceName $resource.ResourceName -ResourceType $resource.ResourceType -ResourceGroupName $resource.ResourceGroupName -Force

#     }

Start-Sleep -Seconds 180

## Enable Accelerated Networking
   $vm_obj = Get-AzVM -ResourceGroupName $resourcegroupname -Name $VMName
   $nics_list=$vm_obj.NetworkProfile.NetworkInterfaces
   $vm_size=$VMSize
   if($vm_size -notmatch "Standard_A" -and $vm_size -notmatch "Standard_E2_v3"){
    if($vm_size -match "Standard_B"){
        if( $vm_size -eq "Standard_B12ms" -or $vm_size -eq "Standard_B16ms" -or $vm_size -eq "Standard_B20ms"){
          Stop-AzVM -ResourceGroup $resourcegroupname -Name $VMName -force
          foreach($nic in $nics_list){
            $nic_name=$nic.Id.Split("/")[-1]
            $nic_rg=$nic.Id.Split("/")[4]
            $nic_obj= Get-AzNetworkInterface -ResourceGroupName $nic_rg -Name $nic_name 
            $nic_obj.EnableAcceleratedNetworking = $true
            $nic_obj | Set-AzNetworkInterface
          }
          Start-AzVM -ResourceGroup $resourcegroupname -Name $VMName
        }
    }
    else{
        Stop-AzVM -ResourceGroup $resourcegroupname -Name $VMName -force
        foreach($nic in $nics_list){
          $nic_name=$nic.Id.Split("/")[-1]
          $nic_rg=$nic.Id.Split("/")[4]
          $nic_obj= Get-AzNetworkInterface -ResourceGroupName $nic_rg -Name $nic_name 
          $nic_obj.EnableAcceleratedNetworking = $true
          $nic_obj | Set-AzNetworkInterface
        }
        Start-AzVM -ResourceGroup $resourcegroupname -Name $VMName
    }
   }

   Start-Sleep 120
## Run-Command for Clone Postbuild
   $vm_obj=Get-AzVM -ResourceGroupName $resourcegroupname -Name $VMName
   $os_type=$vm_obj.StorageProfile.OsDisk.OsType
   if($dynatrace_hg -eq ""){
        $dynatrace_hg="NA"
   }
   
   if($os_type -match "linux"){
      $ucd_agent_name="Lin_"+$vm_obj.tags["ENVIRONMENT"]+"_"+$vm_obj.ResourceGroupName
      $ucd_name = $ucd_agent_name -replace "\s",""
      
      echo "Linux"
      $ucd_agent_name+" "+$dynatrace_hg+" "+$ucd_relay
      Invoke-AzVMRunCommand -ResourceGroupName $resourcegroupname -Name $VMName -CommandId 'RunShellScript' -ScriptPath 'F:\Syed\Scripts\templates\Linux\Non-Prod\Run-command\All-Clone-Unix-PostBuild-NonProd.sh' -Parameter @{"UCD_NAME"=$ucd_name;"RELAY"=$ucd_relay;"Location"=$vm_obj.Location;"HostGroup"=$dynatrace_hg}
   }
   elseif($os_type -match "windows"){
      $tag_env=$vm_obj.tags["ENVIRONMENT"]
      $tag_env = $tag_env -replace "\s",""
      $ucd_agent_name="Win_"+$tag_env+"_"+$vm_obj.ResourceGroupName
      
      $ucd_name = $ucd_agent_name -replace "\s",""
      echo "Windows"   
      Invoke-AzVMRunCommand -ResourceGroupName $resourcegroupname -Name $VMName -CommandId 'RunShellScript' -ScriptPath 'F:\Syed\Scripts\UCD\ucd_install_windows_blob_v3.ps1' -Parameter @{"UCD_NAME"=$ucd_name;"RELAY"=$ucd_relay;"Location"=$vm_obj.Location;"Environment"=$tag_env}
   }


}


foreach ($vms in $vms_csv) {

    $j = Start-Job -ScriptBlock $deploy -ArgumentList $sub_path,$vms.vmName,$vms.resourcegroupname,$vms.vnetname,$vms.vnetrgname,$vms.subnetName,$vms.PrivateIpAddress,$vms.VMSize,$vms.AvailabilitySetName,$vms.zone,$vms.Tag_Project,$vms.Tag_Owner,$vms.Tag_Environment,$vms.Tag_Application,$vms.Tag_Application_Code,$vms.SubscriptionName,$vms.UCD_Relay,$vms.OS

}



$jobs = Get-Job
$job_result = New-Object System.Collections.ArrayList
while($jobs | Where-Object {$_.State -eq "Running" })
{
    $jobs_completed = $jobs | Where-Object { $_.State -eq "Completed" -and $_.HasMoreData -match "True"}
    foreach( $job in $jobs_completed ){
      $job_id = $job.Id
      $result_1 = Receive-Job -id $job_id
      if($result_1){
        $job_result.Add($result_1)
        $result_1
      }
   }
}

$jobs = Get-Job
$job_result = New-Object System.Collections.ArrayList
    $jobs_completed = $jobs | Where-Object { $_.State -eq "Completed" -and $_.HasMoreData -match "True"}
    foreach( $job in $jobs_completed ){
      $job_id = $job.Id
      $result_1 = Receive-Job -id $job_id
      if($result_1){
        $job_result.Add($result_1)
        $result_1
      }
   }
