﻿#Import-AzureRmContext -Path F:\Infra\Scripts\profile1.json
$relay="None"
$subscription=""
Select-AzureRmSubscription -Subscription $subscription
$sub_path= '.\' + $subscription + '_profile1.json'
Save-AzureRmProfile -Path $sub_path -Force

$result_jobs = New-Object System.Collections.ArrayList

$vm_resources = Get-AzureRmResource | where {$_.ResourceType -eq "Microsoft.Compute/virtualMachines" -and $_.Location -eq "westeurope" }

$vm_list = import-csv "F:\Infra\Scripts\Windows\ucd_install.csv"

$deploy = {
   Param($rgname,$vmname,$ucd_name,$relay,$sub_path)
   Import-AzureRmContext -Path $sub_path

    Invoke-AzureRmVMRunCommand -ResourceGroupName $rgname -Name $vmname -CommandId 'RunPowerShellScript' -ScriptPath 'F:\Syed\Scripts\UCD\ucd_install_windows_blob_v2.ps1' -Parameter @{"UCD_NAME"=$ucd_name;"RELAY"=$relay}

}

foreach ($vm_obj in $vm_list) {

$vm = $vm_resources | where {$_.ResourceName -eq $vm_obj.vmname}

$j = Start-Job -ScriptBlock $deploy -ArgumentList $vm.ResourceGroupName,$vm.ResourceName,$vm_obj.ucd_name,$relay,$sub_path

$result_jobs.Add($j)

}


$jobs = Get-Job
$job_result = New-Object System.Collections.ArrayList
while($jobs | Where-Object {$_.State -eq "Running" })
{
    $jobs_completed = $jobs | Where-Object { $_.State -eq "Completed" -and $_.HasMoreData -match "True"}
    foreach( $job in $jobs_completed ){
      $job_id = $job.Id
      $result_1 = Receive-Job -id $job_id
      if($result_1){
        $job_result.Add($result_1)
        $result_1
      }
   }
}