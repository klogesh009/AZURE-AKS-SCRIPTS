﻿$subscription="REBUS_POC"
$vnet_name="AM-RB-DEMO-RA-APPS-VNET02"
$rg_name="AM-RB-DEMO-RA-APPS-RG02"
$location="westeurope"
$AddressPrefix="10.110.5.128/25"
$Tag_Project="REBUS"
$Tag_Environment="POC / TEST"
$Tag_Owner="INFRASTRUCTURE"
$Tag_Application="AZURE VIRTUAL NETWORK"
$Tag_Application_code="AVN"

Select-AzSubscription -Subscription $subscription
$tags = @{ PROJECT=$Tag_Project; ENVIRONMENT=$Tag_Environment; OWNER=$Tag_Owner; APPLICATION=$Tag_Application; COSTCENTERID="NA"; APPLICATION_CODE=$Tag_Application_code }
New-AzVirtualNetwork -Name $vnet_name -ResourceGroupName $rg_name -Location $location -AddressPrefix $AddressPrefix -tag $tags