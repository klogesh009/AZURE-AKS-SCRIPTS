﻿## CSV fields : HostPoolName,UserPrincipalName

$input_csv_path =  "F:\Infra\Scripts\Windows\wvd_inputs.csv"

$input_csv = import-csv -Path $input_csv_path

Install-Module -Name Microsoft.RDInfra.RDPowerShell -scope CurrentUser

foreach($input_obj in $input_csv){

  Add-RdsAppGroupUser -TenantName "REBUS_WVD_NONPROD" -HostPoolName $input_obj.HostPoolName -AppGroupName "Desktop Application Group" -UserPrincipalName $input_obj.UserPrincipalName

}