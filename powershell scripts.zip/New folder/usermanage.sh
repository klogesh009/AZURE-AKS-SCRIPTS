#!/bin/bash

echo " Please enter the user name : "
read USER1

echo " Is the user new local account ? [Yes/No] : "
read USER1TYPE

groupmgmt()
{
echo " Please mention the primary group for this user to be set "
read PRIMGROUP

echo " Please enter all sub groups for this user : [ Example:  developer sudogrp ] "
read SUBGROUPS

for GRP in `echo $SUBGROUPS`
do
	echo $GRP
	cat /etc/group | grep $GRP
	SGRC=`echo $?`
	if [ $SGRC != "0" ]
	then
		groupadd $GRP
	fi

	cp -p  /etc/group /etc/group_bkp_original2 <<< y
	sed -e '/'"${GRP}"'/{s/$/'\,"${USER1}"'/p}' /etc/group | uniq > /etc/group_bkp2
	mv /etc/group_bkp2 /etc/group <<< y
	cat /etc/group | grep -w $GRP
done

cat /etc/sudoers | grep sudogrp
SRC=`echo $?`
if [ $SRC != "0" ] 
then 
	echo "%sudogrp  ALL=(ALL)       ALL" >> /etc/sudoers
fi

}

if [ $USER1TYPE == "Yes" ] || [ $USER1TYPE == "yes" ] || [ $USER1TYPE == "YES" ]
then
	echo " Enter the password to be set if the user is new local/service account : "
	read PASS
	groupmgmt;
	SUBGROUP=`echo $SUBGROUPS | sed 's/ /,/g'`
	useradd -g $PRIMGROUP -G $SUBGROUP $USER1 
	if [ $PASS != "NILL" ]
	then
		( echo $PASS; echo $PASS; ) | passwd `echo $USER1`
	fi
else
	PASS="NILL"
	groupmgmt;
fi