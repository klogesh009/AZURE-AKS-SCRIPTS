﻿## Image info
$image_id= "/subscriptions/84833e4b-da31-46ab-8eca-de2a18064714/resourceGroups/AM-RB-DVD-IT-IMG-RG01/providers/Microsoft.Compute/images/rhel82pocimage"
## Shared Image gallery info
$imageDefinitionName="RHEL-8.2"
$imageVersionName="8.2.3"
$imageLocation="westeurope"
$shared_image_gallery_name="REBUS_IMAGE_GALLERY"
$shared_image_gallery_rg="SHARED-IMAGE-GALLERY"
#$shared_image_gallery_name="amrbprxifsig01"
#$shared_image_gallery_rg="AM-RB-PRX-IF-AUTO-RG01"

$context=(Get-AzContext).Subscription
if($context.Id -ne "5035c5b6-a856-4060-88ca-21122c49d5c9"){
   [Byte[]] $key = (1..16)
   $SecurePassword =Get-Content "F:\Infra\Scripts\azure.txt" | ConvertTo-SecureString -Key $key
   $Credential = new-Object System.Management.Automation.PSCredential ("5035c5b6-a856-4060-88ca-21122c49d5c9", $SecurePassword)
   Login-AzAccount -credential   $Credential -ServicePrincipal -TenantId a095b75b-77a2-4e28-afc2-27edd1d6b0ab -Subscription REBUS_TEST
}

$image_subscription=$image_id.Split("/")[2]
$image_name=$image_id.Split("/")[8]
$image_RGname=$image_id.Split("/")[4]

## Image details
Select-AzSubscription -Subscription $image_subscription
$managedImage = Get-AzImage `
   -ImageName $image_name `
   -ResourceGroupName $image_RGname

## Gallery details
Select-AzSubscription -Subscription REBUS_PRODUCTION_SHARED_SVCS
$gallery=Get-AzGallery -ResourceGroupName $shared_image_gallery_rg -Name $shared_image_gallery_name

## Image definition details
$galleryImage=Get-AzGalleryImageDefinition -ResourceGroupName $shared_image_gallery_rg -GalleryName $shared_image_gallery_name -Name $imageDefinitionName

## Image version create

$region1 = @{Name='West Europe';ReplicaCount=1}
$region2 = @{Name='North Europe';ReplicaCount=1}
$targetRegions = @($region1,$region2)
$job = $imageVersion = New-AzGalleryImageVersion `
   -GalleryImageDefinitionName $galleryImage.Name `
   -GalleryImageVersionName $imageVersionName `
   -GalleryName $gallery.Name `
   -ResourceGroupName $galleryImage.ResourceGroupName `
   -Location $imageLocation `
   -TargetRegion $targetRegions  `
   -Source $managedImage.Id.ToString() `
   -asJob 

Logout-AzAccount