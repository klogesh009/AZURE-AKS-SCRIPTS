﻿$input_csv = Import-Csv -Path "F:\Infra\Scripts\Automation\Inputs\Adding_user.csv"


Write-Output "Do you want to perform the installation for above?"
$console_output=@"
1. Admin
2. Remote-Desktop-Users
"@
Write-Output $console_output
$option_input = Read-Host 'Please select one option'

foreach($user in $input_csv)
{
 if($option_input -eq '1')
        {
         $adminuser = $user.name
        Add-LocalGroupMember -Group 'Administrators' -Member $adminuser
        Write-Output "$adminuser added to administrators"
}
elseif($option_input -eq '2')
        {
        $Remoteuser = $user.name
        Add-LocalGroupMember -Group 'Remote Desktop Users' -Member $Remoteuser
        Write-Output "$Remoteuser added to Remoteadministor group"
    }
}
