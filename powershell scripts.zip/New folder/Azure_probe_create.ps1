﻿#az login
$lb_name="rbdeditftlalb02"
$lb_resource_group="AM-RB-DEVD-RA-APPS-RG01"
$subscription="REBUS_DEVELOPMENT"
$frontendIP_name="LoadBalancerFrontEnd"
az account set -s $subscription
#$slb = Get-AzLoadBalancer -Name $lb_name -ResourceGroupName $lb_resource_group
$lb_inputs=Import-Csv -Path "F:\Infra\Scripts\Network\lb_details2.csv"

foreach($lb_input in $lb_inputs){
  $probe=""
  $probe_name=""
  $rule_name=""
  $probe_name="TCP_"+$lb_input.port
  #$rule_name=$lb_name+"_"+$lb_input.port
  $rule_name="Rule-TCP-"+$lb_input.port

#  $probe_details=az network lb probe show --lb-name $lb_name --name $probe_name --resource-group $lb_resource_group
#  if(!$probe_details){
   az network lb probe create -g $lb_resource_group --lb-name $lb_name -n $probe_name --protocol Tcp --port $lb_input.port
#  Add-AzLoadBalancerProbeConfig -Name $lb_input.name -LoadBalancer $slb -Port $lb_input.port -IntervalInSeconds 5 -ProbeCount 2 -Protocol Tcp | Set-AzLoadBalancer
  
   az network lb rule create -g $lb_resource_group --frontend-ip-name $frontendIP_name --lb-name $lb_name -n $rule_name --protocol Tcp --frontend-port $lb_input.port --probe-name $probe_name --backend-port $lb_input.port

#  }
  
}

