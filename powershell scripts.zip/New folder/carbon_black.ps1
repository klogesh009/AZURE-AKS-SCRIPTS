###############################################################
##### Installing Carbon Black Agent ###########################
###############################################################

$CarbonBlackGroup="SIT-B-Shared-Services"
$CompanyCode="U6LA37A7W301Q!BX3O9"

if($Location -eq "northeurope"){
	$CB_install_uri="https://durbdevautomationstg.blob.core.windows.net/run-command/CarbonBlackAgent.msi"
}
else{
	$CB_install_uri="https://rbdevautomationstg.blob.core.windows.net/runcommand/CarbonBlackAgent.msi"
}

$directory_path='C:\PostBuild\CarbonBlackAgent'
if(!(Test-Path -Path $directory_path )){
    New-Item -ItemType directory -Path $directory_path
}

$WebClient = New-Object System.Net.WebClient
$WebClient.DownloadFile($CB_install_uri, "C:\PostBuild\CarbonBlackAgent\CarbonBlackAgent.msi")
if($?){
   echo "Success"
}
else{
   $WebClient = New-Object System.Net.WebClient
   $WebProxy = New-Object System.Net.WebProxy($Proxy,$true)
   $WebClient.Proxy=$WebProxy
   $WebClient.DownloadFile($CB_install_uri, "C:\PostBuild\CarbonBlackAgent\CarbonBlackAgent.msi")
}

Try{
    $Agent = "C:\PostBuild\CarbonBlackAgent\CarbonBlackAgent.msi"
    $Log = "C:\PostBuild\CarbonBlackAgent\CarbonBlackInstall.log"
    $Arguments = @(
        "/i"
        ($Agent)
        "/qn"
        "/norestart"
        "COMPANY_CODE=$CompanyCode"
        "GROUP_NAME=$CarbonBlackGroup"
        "PROXY_SERVER=$Proxy"
        "/L*v"
        $Log
    )
    Start-Process "msiexec.exe" -ArgumentList $Arguments -Wait -NoNewWindow
}
Catch{
    echo "Installation Failed !"
    exit 1
}