﻿$input_csv_path=Import-Csv -Path "F:\Infra\Scripts\linux\Inputs\vm_DiagnosticsExtension_input.csv"

#$storageAccountName = "amrbcicautdepstg01"
#$storageAccountResourceGroup = "AM-RB-CITC-IF-AUTO-RG01"

$deploy = {
   Param($vmName,$VMresourceGroup,$subscription,$storageAccountName,$storageAccountResourceGroup)
   $csv_path="F:\Infra\Scripts\Automation\Outputs\vm-diagnostics-extension_report.csv"
   $outputCollection = @()
   $outputObject =  "" | Select vm_name,rg_name,subscription,diagnostic_extension,diagnostic_extension_version,diagnostic_extension_state
   
   $context=(Get-AzContext).Subscription
   if(!$context){
      [Byte[]] $key = (1..16)
       $SecurePassword =Get-Content "F:\Infra\Scripts\azure_nonprod.txt" | ConvertTo-SecureString -Key $key
       $Credential = new-Object System.Management.Automation.PSCredential ("962a8e28-2e38-486f-aa23-0dd7befe0c53", $SecurePassword)
       Login-AzAccount -credential   $Credential -ServicePrincipal -TenantId a095b75b-77a2-4e28-afc2-27edd1d6b0ab -Subscription $subscription
   }
   else{
     Select-AzSubscription -Subscription $subscription
   }
   (Get-AzContext).Subscription
   # Get the VM object
  $vm = Get-AzVM -Name $vmName -ResourceGroupName $VMresourceGroup
  $os_type=$vm.StorageProfile.OsDisk.OsType
  $outputObject.vm_name=$vm.Name
  $outputObject.rg_name=$vm.ResourceGroupName
  $outputObject.subscription=$subscription
  $vm.Name,$vm.ResourceGroupName

  # Get the public settings template from GitHub and update the templated values for storage account and resource ID
  if($os_type -eq "Linux"){
    $publicSettings = Get-Content -Path F:\Syed\Scripts\templates\public_settings_LinuxDiagnostic.json
    $publicSettings = $publicSettings.Replace('__DIAGNOSTIC_STORAGE_ACCOUNT__', $storageAccountName)
    $publicSettings = $publicSettings.Replace('__VM_RESOURCE_ID__', $vm.Id)
    $publicSettings = [string]$publicSettings
  }
  elseif($os_type -eq "Windows"){
    $publicSettings_path = "F:\Syed\Scripts\templates\public_settings_WindowsDiagnostic.json"
  }

  
  
  if($os_type -eq "Linux"){ 
    # Generate a SAS token for the agent to use to authenticate with the storage account
    $sasToken = New-AzStorageAccountSASToken -Service Blob,Table -ResourceType Service,Container,Object -Permission "racwdlup" -Context (Get-AzStorageAccount -ResourceGroupName $storageAccountResourceGroup -AccountName $storageAccountName).Context -ExpiryTime $([System.DateTime]::Now.AddYears(10))
    # Build the protected settings (storage account SAS token)
    #$protectedSettings="{'storageAccountName': '$storageAccountName', 'storageAccountSasToken': '$sasToken', 'mdsdHttpProxy': 'proxy.threatpulse.net:8080'}"
    $protectedSettings="{'storageAccountName': '$storageAccountName', 'storageAccountSasToken': '$sasToken'}"
    $old_ext_install_check = Get-AzVMExtension -ResourceGroupName $VMresourceGroup -VMName $vmName | Where-Object {$_.Name -match "LinuxDiagnostic"}
    if($old_ext_install_check){
      if($old_ext_install_check.TypeHandlerVersion -ne "3.0"){
        Remove-AzVMExtension -ResourceGroupName $VMresourceGroup -VMName $vmName -Name LinuxDiagnostic -Force
        Set-AzVMExtension -ResourceGroupName $VMresourceGroup -VMName $vmName -Location $vm.Location -ExtensionType LinuxDiagnostic -Publisher Microsoft.Azure.Diagnostics -Name LinuxDiagnostic -SettingString $publicSettings -ProtectedSettingString $protectedSettings -TypeHandlerVersion 3.0 
      }
    }
    else{
      Set-AzVMExtension -ResourceGroupName $VMresourceGroup -VMName $vmName -Location $vm.Location -ExtensionType LinuxDiagnostic -Publisher Microsoft.Azure.Diagnostics -Name LinuxDiagnostic -SettingString $publicSettings -ProtectedSettingString $protectedSettings -TypeHandlerVersion 3.0 
    }
    
  }
  elseif($os_type -eq "Windows"){
    #Set-AzVMExtension -ResourceGroupName $VMresourceGroup -VMName $vmName -Location $vm.Location -ExtensionType IaaSDiagnostics -Publisher Microsoft.Azure.Diagnostics -Name Microsoft.Insights.VMDiagnosticsSettings -SettingString $publicSettings -ProtectedSettingString $protectedSettings -TypeHandlerVersion 1.5
    $storageAccountKey = (Get-AzStorageAccountKey -ResourceGroupName $storageAccountResourceGroup -Name $storageAccountName)[0].Value
    $old_ext_install_check = Get-AzVMExtension -ResourceGroupName $VMresourceGroup -VMName $vmName | Where-Object {$_.Name -match "Microsoft.Insights.VMDiagnosticsSettings"}
    if($old_ext_install_check){
      if($old_ext_install_check.TypeHandlerVersion -ne "1.5"){
        Remove-AzVMExtension -ResourceGroupName $VMresourceGroup -VMName $vmName -Name Microsoft.Insights.VMDiagnosticsSettings -Force
        Set-AzVMDiagnosticsExtension -ResourceGroupName $VMresourceGroup -VMName $vmName -DiagnosticsConfigurationPath $publicSettings_path -StorageAccountName $storageAccountName -StorageAccountKey $storageAccountKey
      }
    }
    else{
      Set-AzVMDiagnosticsExtension -ResourceGroupName $VMresourceGroup -VMName $vmName -DiagnosticsConfigurationPath $publicSettings_path -StorageAccountName $storageAccountName -StorageAccountKey $storageAccountKey
    }
    
  }

  $ext_install_check = Get-AzVMExtension -ResourceGroupName $VMresourceGroup -VMName $vmName | Where-Object {$_.Name -match "diagnostic"}
  if($ext_install_check){
    $outputObject.diagnostic_extension= $ext_install_check.Name
    $outputObject.diagnostic_extension_version= $ext_install_check.TypeHandlerVersion
    $outputObject.diagnostic_extension_state= $ext_install_check.ProvisioningState
  }
  else{
    $outputObject.diagnostic_extension="Not Installed"
    $outputObject.diagnostic_extension_version="NA"
    $outputObject.diagnostic_extension_state="NA"
  }
  Export-Csv -Path $csv_path -inputobject $outputObject -Append -Force -NoTypeInformation

}


foreach($input_csv_obj in $input_csv_path){
  $jobs_running = Get-Job | where {$_.State -eq "Running"}
  while($jobs_running.Count -ge 30){
     Start-Sleep -Seconds 5
     $jobs_running = Get-Job | where {$_.State -eq "Running"}
  }
  $vm_name=$input_csv_obj.vm_name
  $subscription_name=$input_csv_obj.subscription
  $vm_name+"  "+$subscription_name
  $job = Start-Job -ScriptBlock $deploy -ArgumentList $input_csv_obj.vm_name,$input_csv_obj.rg_name,$input_csv_obj.subscription,$input_csv_obj.storage_name,$input_csv_obj.storage_rg
}

$jobs = Get-Job
$job_result = New-Object System.Collections.ArrayList
while($jobs | Where-Object {$_.State -eq "Running" })
{
    $jobs_completed = $jobs | Where-Object { $_.State -eq "Completed" -and $_.HasMoreData -match "True"}
    foreach( $job in $jobs_completed ){
      $job_id = $job.Id
      $result_1 = Receive-Job -id $job_id
      if($result_1){
        $job_result.Add($result_1)
        $result_1
      }
   }
}
    $jobs_completed = $jobs | Where-Object { $_.State -eq "Completed" -and $_.HasMoreData -match "True"}
    foreach( $job in $jobs_completed ){
      $job_id = $job.Id
      $result_1 = Receive-Job -id $job_id
      if($result_1){
        $job_result.Add($result_1)
        $result_1
      }
   }

