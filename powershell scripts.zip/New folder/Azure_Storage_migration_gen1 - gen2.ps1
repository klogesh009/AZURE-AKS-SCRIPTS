﻿#Install the Az module if you haven't done so already.
#Install-Module Az
 
#Login to your Azure account.
#Login-AzAccount
<#
$context_1=(Get-AzContext).Subscription
   if(!$context_1){
      [Byte[]] $key = (1..16)
      $SecurePassword =Get-Content "F:\Infra\Scripts\azure.txt" | ConvertTo-SecureString -Key $key
      $Credential = new-Object System.Management.Automation.PSCredential ("5035c5b6-a856-4060-88ca-21122c49d5c9", $SecurePassword)
      Login-AzAccount -credential $Credential -ServicePrincipal -TenantId a095b75b-77a2-4e28-afc2-27edd1d6b0ab -Subscription REBUS_TEST
   }
#>
Param
(
$contentlocation = $(Read-Host -Prompt 'Please Specify the location of csv e.g. C:\temp\storageaccountexport.csv'),
$outputlocation = $(Read-Host -Prompt 'Please Specify the location of outputfile (results) e.g. C:\temp\storageaccountexport.csv')
)

#Import the specified CSV to a variable
$content = Import-Csv $contentlocation

#Pipe all subscriptions to variable
$Subscriptions = Get-AzSubscription

#cycle through each storage account specified in the CSV
$output = foreach ($sa in $content) {

#Split CSV columns to named variables
$name = $sa.StorageAccountName
$resourceGroupName = $sa.ResourceGroupName
$Subscription = $sa.Subscription

#Get the current Azure context (Selected Subscription)
$curentcontext = Get-AzContext
$curentcontextName = $curentcontext.Name

#Check if the current selected sub matches the subscription of the storage account, if not change to the right subscription
if($curentcontextName -ne $Subscription) {
$SelectedSub = $Subscriptions | Where-Object {$_.Name -eq $Subscription}
Select-AzSubscription $SelectedSub.Id | Out-Null
}

#Upgrade the storage account Kind to V2, pipe the results to a variable called conversion
$conversion = Set-AzStorageAccount -ResourceGroupName $resourceGroupName -Name $name -UpgradeToStorageV2 -AccessTier Hot -Force
        
        #Save the conversion SKU to a variable
        $sku = $conversion.Sku.Name

        #Create a new PowerShell object to store the result variables which are then saved to $output
        New-Object -TypeName PSObject -Property @{
        StorageAccountName = $conversion.StorageAccountName
        ResourceGroupName = $conversion.ResourceGroupName
		Subscription = $Subscription
        SKU = $sku
        Kind = $conversion.Kind
        Location = $conversion.Location
        } | Select-Object StorageAccountName, ResourceGroupName, Subscription, SKU, Kind, Location 
}

#Export the results to a CSV to the location designated by the user in the Params
$output | Select-Object StorageAccountName, ResourceGroupName, Subscription, SKU, Kind, Location  | Export-Csv $outputlocation