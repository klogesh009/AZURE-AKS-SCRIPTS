﻿$vm_name="rbsibcosvwold04"
$vm_rg_name="AM-RB-SIB-CO-SVW-DRG01"
$subscription="REBUS_SIT-B_TEST"
$disk_SKU="Standard_LRS"
$disk_size_gb="2048"
$no_of_disks=7

#$csv_input=Import-Csv "G:\Infra\Scripts\Automation\Inputs\disk_create_input.csv"

$context=(Get-AzContext).Subscription
if($context.Id -ne "5035c5b6-a856-4060-88ca-21122c49d5c9"){
   [Byte[]] $key = (1..16)
   $SecurePassword =Get-Content "F:\Infra\Scripts\azure.txt" | ConvertTo-SecureString -Key $key
   $Credential = new-Object System.Management.Automation.PSCredential ("5035c5b6-a856-4060-88ca-21122c49d5c9", $SecurePassword)
   Login-AzAccount -credential   $Credential -ServicePrincipal -TenantId a095b75b-77a2-4e28-afc2-27edd1d6b0ab -Subscription $subscription
}

$k=0
#Select-AzSubscription -Subscription $subscription
$vm_details=Get-AzVM -ResourceGroupName $vm_rg_name -Name $vm_name
$vm_disk_count=$vm_details.StorageProfile.DataDisks.Count
$vm_disk_names_list=($vm_details.StorageProfile.DataDisks).Name
$vm_disk_LUN_list=($vm_details.StorageProfile.DataDisks).Lun
$vm=Get-AzVM -ResourceGroupName $vm_rg_name -Name $vm_name
$new_disk_number=0
$new_disk_name=""
$new_disk_LUN=0

## Validating the disks before addition

while( $k -lt $no_of_disks ){  

   $diskConfig=""
   $dataDisk=""
   $new_disk_number=$vm_disk_count+1
   
   ## Assigning new disk name
   $i=0
   if($new_disk_number.ToString().Length -eq 1){
     $new_disk_name=$vm_name + "-datadisk" + '{0}{1}' -f '0',$new_disk_number
   }
   else{
     $new_disk_name=$vm_name + "-datadisk" + '{1}' -f '0',$new_disk_number
   }
   
   while($new_disk_name -in $vm_disk_names_list -and $i -lt 20){
     $new_disk_number++
     if($new_disk_number.ToString().Length -eq 1){
       $new_disk_name=$vm_name + "-datadisk" + '{0}{1}' -f '0',$new_disk_number
     }
     else{
       $new_disk_name=$vm_name + "-datadisk" + '{1}' -f '0',$new_disk_number
     }
     $i++
   }
   if($i -ge 20){
     echo "Issue in naming the the Disk"
     exit 1
   }
   echo "New disk name is $new_disk_name"

   ## Assigning new disk LUN
   $i=0
   $new_disk_LUN=$vm_disk_count
   while($new_disk_LUN -in $vm_disk_LUN_list -and $i -lt 20){
     $new_disk_LUN++
     $i++
   }
   if($i -ge 20){
     echo "Issue in naming the LUN of the Disk"
     exit 1
   }
   echo "New disk LUN is $new_disk_LUN"

   if($?){
     $vm_disk_count++
     $vm_disk_names_list+=$new_disk_name
     $vm_disk_LUN_list+=$new_disk_LUN
     
   }

   $k++

}

Write-Output "Do you want to add the above disks. Validate the Lun and disk names ? Enter number"
Write-Output "1.Yes`r`n2.No"
$user_input = Read-Host "Option No"
if($user_input -ne "1"){
  exit
}

$k=0
#Select-AzSubscription -Subscription $subscription
$vm_details=Get-AzVM -ResourceGroupName $vm_rg_name -Name $vm_name
$vm_disk_count=$vm_details.StorageProfile.DataDisks.Count
$vm_disk_names_list=($vm_details.StorageProfile.DataDisks).Name
$vm_disk_LUN_list=($vm_details.StorageProfile.DataDisks).Lun
$vm=Get-AzVM -ResourceGroupName $vm_rg_name -Name $vm_name
$new_disk_number=0
$new_disk_name=""
$new_disk_LUN=0

while( $k -lt $no_of_disks ){  

   $diskConfig=""
   $dataDisk=""
   $new_disk_number=$vm_disk_count+1
   
   ## Assigning new disk name
   $i=0
   if($new_disk_number.ToString().Length -eq 1){
     $new_disk_name=$vm_name + "-datadisk" + '{0}{1}' -f '0',$new_disk_number
   }
   else{
     $new_disk_name=$vm_name + "-datadisk" + '{1}' -f '0',$new_disk_number
   }
   
   while($new_disk_name -in $vm_disk_names_list -and $i -lt 20){
     $new_disk_number++
     if($new_disk_number.ToString().Length -eq 1){
       $new_disk_name=$vm_name + "-datadisk" + '{0}{1}' -f '0',$new_disk_number
     }
     else{
       $new_disk_name=$vm_name + "-datadisk" + '{1}' -f '0',$new_disk_number
     }
     $i++
   }
   if($i -ge 20){
     echo "Issue in naming the the Disk"
     exit 1
   }
   echo "New disk name is $new_disk_name"

   ## Assigning new disk LUN
   $i=0
   $new_disk_LUN=$vm_disk_count
   while($new_disk_LUN -in $vm_disk_LUN_list -and $i -lt 20){
     $new_disk_LUN++
     $i++
   }
   if($i -ge 20){
     echo "Issue in naming the LUN of the Disk"
     exit 1
   }
   echo "New disk LUN is $new_disk_LUN"

   if($vm.Zones){
     $diskConfig = New-AzDiskConfig -Location $vm_details.Location -CreateOption Empty -DiskSizeGB $disk_size_gb -SkuName $disk_SKU -Tag $vm_details.Tags -Zone $vm.Zones
   }
   else{
     $diskConfig = New-AzDiskConfig -Location $vm_details.Location -CreateOption Empty -DiskSizeGB $disk_size_gb -SkuName $disk_SKU -Tag $vm_details.Tags
   }
   $dataDisk = New-AzDisk -ResourceGroupName $vm_rg_name -DiskName $new_disk_name -Disk $diskConfig
   
   $vm = Add-AzVMDataDisk -VM $vm -Name $new_disk_name -CreateOption Attach -ManagedDiskId $dataDisk.Id -Lun $new_disk_LUN
   if($?){
     $vm_disk_count++
     $vm_disk_names_list+=$new_disk_name
     $vm_disk_LUN_list+=$new_disk_LUN
     
   }

   $k++

}

Update-AzVM -ResourceGroupName $vm_rg_name -VM $vm

Logout-AzAccount



