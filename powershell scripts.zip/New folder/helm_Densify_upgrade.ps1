﻿$csv_input= Import-Csv -Path "F:\Infra\Scripts\Automation\Inputs\helm_densify_upgrade_input.csv"

$csv_input | Format-Table
  Write-Output "Which component do you want to perform upgrade ? Enter number"
    Write-Output "1.kube-state-metrics`r`n2.Prometheus`r`n3.Densify-forwarder`r`n4.All-Desnify`r`n5.Dynatrace"
    $user_input = Read-Host "Option No"

$previous_cluster=""
foreach( $aks_obj in $csv_input ){
  $cluster_name=""
  $rg_grp=""
  $subscription=""
  $taints_added=""
  $container_name=""
  $pod_name=""

  $cluster_name=$aks_obj.cluster_name
  $rg_grp=$aks_obj.rg_name
  $subscription=$aks_obj.subscription
  $taints_added=$aks_obj.taints_added
  $container_name=$aks_obj.container_name
  $pod_name=$aks_obj.pod_name
  
  $app_code="{aks,ftl}"
  $kube_state_metrics_path="F:\Infra\Scripts\AKS\CAAS\helm\kube-state-metrics"
  $prometheus_path_server="F:\Infra\Scripts\AKS\CAAS\helm\prometheus"
  $prometheus_path_nodeExporter="F:\Infra\Scripts\AKS\CAAS\helm\prometheus\node-exporter"
  $densify_container_path="F:\Infra\Scripts\AKS\CAAS\helm\container-optimization-data-forwarder"
  $dynatrace_path="F:\Infra\Scripts\AKS\CAAS\helm\dynatrace"
  $dynatrace_cr_path="F:\Infra\Scripts\AKS\CAAS\helm\dynatrace\cr_files"

  if($previous_cluster -ne $cluster_name){
    az account set --s $subscription
    cmd.exe /c "az aks get-credentials --resource-group $rg_grp --name $cluster_name --admin --overwrite-existing"
    $previous_cluster=$cluster_name
  }
  
  $nodes_status_json=kubectl get nodes -o json | ConvertFrom-Json
  $node_ready=0
  foreach($nodes_status_obj in $nodes_status_json.items){
    $nodes_status_obj.metadata.name
    
    foreach( $nodes_status_cond_obj in $nodes_status_obj.status.conditions ){
      if( $nodes_status_cond_obj.reason -match "KubeletReady" ){      
        $nodes_status_cond_obj.type
        $node_ready=1
      }
    }
    if($node_ready -eq 0){
      "Nodes are not in READY state"
       exit
    }
  }
  
  $pods_densify=kubectl get pods -n densify
  
  if($pods_densify){
    
    if($user_input -eq 1 -or $user_input -eq 4 -and $container_name -eq "kube-state-metrics"){  
      $cpu_requests=""
      $cpu_limits=""
      $memory_requests=""
      $memory_limits=""
      $ksm_obj=""
      $ksm_obj = $csv_input | Where-Object {$_.cluster_name -eq $cluster_name -and $_.rg_name -eq $rg_grp -and $_.container_name -eq "kube-state-metrics"}      
      
      #Upgrade of kube-state-metrics
      cd $kube_state_metrics_path
      if($ksm_obj.cpu_requests -and $ksm_obj.cpu_limits -and $ksm_obj.memory_requests -and $ksm_obj.memory_limits){
        $cpu_requests=$ksm_obj.cpu_requests+"m"
        $cpu_limits=$ksm_obj.cpu_limits+"m"
        $memory_requests=$ksm_obj.memory_requests+"M"
        $memory_limits=$ksm_obj.memory_limits+"M"
        helm upgrade kube-state-metrics -n densify --set taints_added=$taints_added --set resources.requests.cpu=$cpu_requests --set resources.requests.memory=$memory_requests --set resources.limits.cpu=$cpu_limits --set resources.limits.memory=$memory_limits . --atomic
      }
      else{
        helm upgrade kube-state-metrics -n densify --set taints_added=$taints_added . --atomic
      }
      
      $pods_kubeMetrics_status=""
      $pods_kubeMetrics=""
      $pods_kubeMetrics_notRunning=$true
      
      while($pods_kubeMetrics_notRunning){
        $pods_kubeMetrics=kubectl get pods -n densify
        $pods_status = $pods_kubeMetrics | Select-String -SimpleMatch "kube-state-metrics" | Select-String -SimpleMatch "Running"
        if($pods_status){
          $pods_kubeMetrics_notRunning=$false
        }else{
          Start-Sleep -Seconds 10
        }
      }
      
      if($?){
        echo "kube-state-metrics upgraded successfully"
      }
    }

    if($user_input -eq 2 -or $user_input -eq 4 -and $container_name -match "prometheus"){  
      #Installation of Prometheus
      
      $cpu_requests=""
      $cpu_limits=""
      $memory_requests=""
      $memory_limits=""
      $pms_obj=""
      $pmn_obj=""

       if($container_name -eq "prometheus-server"){
         $pms_obj = $csv_input | Where-Object {$_.cluster_name -eq $cluster_name -and $_.rg_name -eq $rg_grp -and $_.container_name -eq "prometheus-server"}
         if($pms_obj.cpu_requests -and $pms_obj.cpu_limits -and $pms_obj.memory_requests -and $pms_obj.memory_limits){
           cd $prometheus_path_server
           $cpu_requests=$pms_obj.cpu_requests+"m"
           $cpu_limits=$pms_obj.cpu_limits+"m"
           $memory_requests=$pms_obj.memory_requests+"M"
           $memory_limits=$pms_obj.memory_limits+"M"
           helm upgrade prometheus-1 --set taints_added=$taints_added --set app_code=$app_code `
           --set server.resources.requests.cpu=$cpu_requests --set server.resources.requests.memory=$memory_requests --set server.resources.limits.cpu=$cpu_limits --set server.resources.limits.memory=$memory_limits -n densify . --atomic
         }
       }
       elseif($container_name -eq "prometheus-node-exporter"){
         $pmn_obj = $csv_input | Where-Object {$_.cluster_name -eq $cluster_name -and $_.rg_name -eq $rg_grp -and $_.container_name -eq "prometheus-node-exporter"}
         if($pmn_obj.cpu_requests -and $pmn_obj.cpu_limits -and $pmn_obj.memory_requests -and $pmn_obj.memory_limits){
           cd $prometheus_path_nodeExporter
           $cpu_requests=$pmn_obj.cpu_requests+"m"
           $cpu_limits=$pmn_obj.cpu_limits+"m"
           $memory_requests=$pmn_obj.memory_requests+"M"
           $memory_limits=$pmn_obj.memory_limits+"M"
           helm upgrade prometheus-2 --set taints_added=$taints_added --set app_code=$app_code `
           --set nodeExporter.resources.requests.cpu=$cpu_requests --set nodeExporter.resources.requests.memory=$memory_requests --set nodeExporter.resources.limits.cpu=$cpu_limits --set nodeExporter.resources.limits.memory=$memory_limits -n densify . --atomic
         }
       }
       else{
         cmd.exe /c "helm upgrade prometheus --set taints_added=$taints_added --set app_code=$app_code -n densify . --atomic"
       }
      
      if($?){
        echo "Prometheus installed successfully"
      }
      
      Start-Sleep -Seconds 10
    }
    
    if($user_input -eq 3 -or $user_input -eq 4){   
      #Installation of densify-forwarder
      
      cd $densify_container_path
      helm delete densify-forwarder -n densify
      helm install densify-forwarder --set taints_added=$taints_added --set config.prometheus.clustername=$cluster_name --set config.zipname="data/$cluster_name" -n densify . --atomic
      
      if($?){
        echo "Densify Forwarder installed successfully"
      }
    }

    if($user_input -eq 5){
      #Upgrade of Dynatrace
      $cpu_requests=""
      $cpu_limits=""
      $memory_requests=""
      $memory_limits=""

      $dynatrace_pods=kubectl get pods -n dynatrace -o json | ConvertFrom-Json
      $match_found=0
      $dynatrace_pod_name=""
      $dynatrace_pod=""
      $dyn_pod_res=""
      $dyn_pod_res_limits_cpu=""
      $dyn_pod_res_limits_memory=""
      $dyn_pod_res_requests_cpu=""
      $dyn_pod_res_requests_memory=""

      $env_name=$cluster_name.Substring(2,3)
      $owner_name=$cluster_name.Substring(5,2)
      $app_code=$cluster_name.Substring(7,3)
      $helm_dyn_name="dynatrace-"+$env_name+"-"+$app_code
      $helm_dyn_cr_name=$helm_dyn_name+"-cr"
      cd $dynatrace_path

      $cpu_requests=$aks_obj.cpu_requests+"m"
      $cpu_limits=$aks_obj.cpu_limits+"m"
      $memory_requests=$aks_obj.memory_requests+"M"
      $memory_limits=$aks_obj.memory_limits+"M"

      ## Getting the other pod's cpu and memory values
      if($container_name -eq "dynatrace-operator" -and $pod_name -match "dynatrace-operator"){ $pod_match_name="dynatrace-webhook" }
      elseif($container_name -eq "webhook"){ $pod_match_name="dynatrace-operator" }
      elseif($container_name -eq "dynatrace-oneagent"){ $pod_match_name="dynakube-activegate" }
      elseif($container_name -eq "dynatrace-operator" -and $pod_name -match "dynakube-activegate"){ $pod_match_name="dynakube-oneagent" }

      foreach($dynatrace_pod in $dynatrace_pods.items){  
        if($dynatrace_pod.metadata.name -match $pod_match_name -and $match_found -eq 0){
          $match_found=1
          $dynatrace_pod_name=$dynatrace_pod.metadata.name
          $dynatrace_pod=kubectl get pods $dynatrace_pod_name -n dynatrace -o json | ConvertFrom-Json
          $dyn_pod_res=$dynatrace_pod.spec.containers[0].resources
          $dyn_pod_res_limits_cpu=$dyn_pod_res.limits.cpu
          $dyn_pod_res_limits_memory=$dyn_pod_res.limits.memory
          $dyn_pod_res_requests_cpu=$dyn_pod_res.requests.cpu
          $dyn_pod_res_requests_memory=$dyn_pod_res.requests.memory
          break
        }
      }

      if($aks_obj.cpu_requests -and $aks_obj.cpu_limits -and $aks_obj.memory_requests -and $aks_obj.memory_limits){
      
      if($container_name -eq "dynatrace-operator"){    
        if($taints_added -match "yes"){
          helm upgrade $helm_dyn_name -n dynatrace --set env=$env_name --set tolerations_app_codes={ftl} `
          --set app_code=$app_code --set owner=$owner_name --set namespace_create=no --set tolerations_set=yes . --atomic
        }
        else{
          helm upgrade $helm_dyn_name -n dynatrace --set env=$env_name --set app_code=$app_code `
          --set resources.operator.requests.cpu=$cpu_requests --set resources.operator.requests.memory=$memory_requests --set resources.operator.limits.cpu=$cpu_limits --set resources.operator.limits.memory=$memory_limits `
          --set resources.webhook.requests.cpu=$dyn_pod_res_requests_cpu --set resources.webhook.requests.memory=$dyn_pod_res_requests_memory --set resources.webhook.limits.cpu=$dyn_pod_res_limits_cpu --set resources.webhook.limits.memory=$dyn_pod_res_limits_memory `
          --set owner=$owner_name --set namespace_create=no --set tolerations_set=no . --atomic
        }
      }

      if($container_name -eq "webhook"){       
        if($taints_added -match "yes"){
          helm upgrade $helm_dyn_name -n dynatrace --set env=$env_name --set tolerations_app_codes={ftl} `
          --set app_code=$app_code --set owner=$owner_name --set namespace_create=no --set tolerations_set=yes . --atomic
        }
        else{
          helm upgrade $helm_dyn_name -n dynatrace --set env=$env_name --set app_code=$app_code `
          --set resources.webhook.requests.cpu=$cpu_requests --set resources.webhook.requests.memory=$memory_requests --set resources.webhook.limits.cpu=$cpu_limits --set resources.webhook.limits.memory=$memory_limits `
          --set resources.operator.requests.cpu=$dyn_pod_res_requests_cpu --set resources.operator.requests.memory=$dyn_pod_res_requests_memory --set resources.operator.limits.cpu=$dyn_pod_res_limits_cpu --set resources.operator.limits.memory=$dyn_pod_res_limits_memory `
          --set owner=$owner_name --set namespace_create=no --set tolerations_set=no . --atomic
        }
      }

      if($container_name -eq "dynatrace-oneagent"){       
        cd $dynatrace_cr_path
        if($taints_added -match "yes"){
          helm upgrade $helm_dyn_cr_name -n dynatrace --set env=$env_name --set tolerations_app_codes={ftl} `
          --set app_code=$app_code --set owner=$owner_name --set namespace_create=no --set tolerations_set=yes . --atomic
        }
        else{
          helm upgrade $helm_dyn_cr_name -n dynatrace --set env=$env_name --set app_code=$app_code `
          --set resources.oneAgent.requests.cpu=$cpu_requests --set resources.oneAgent.requests.memory=$memory_requests --set resources.oneAgent.limits.cpu=$cpu_limits --set resources.oneAgent.limits.memory=$memory_limits `
          --set resources.activeGate.requests.cpu=$dyn_pod_res_requests_cpu --set resources.activeGate.requests.memory=$dyn_pod_res_requests_memory --set resources.activeGate.limits.cpu=$dyn_pod_res_limits_cpu --set resources.activeGate.limits.memory=$dyn_pod_res_limits_memory `
          --set owner=$owner_name --set namespace_create=no --set tolerations_set=no . --atomic
        }
      }

      if($container_name -eq "dynatrace-operator" -and $pod_name -match "dynakube-activegate"){       
        cd $dynatrace_cr_path
        if($taints_added -match "yes"){
          helm upgrade $helm_dyn_cr_name -n dynatrace --set env=$env_name --set tolerations_app_codes={ftl} `
          --set app_code=$app_code --set owner=$owner_name --set namespace_create=no --set tolerations_set=yes . --atomic
        }
        else{
          helm upgrade $helm_dyn_cr_name -n dynatrace --set env=$env_name --set app_code=$app_code `
          --set resources.activeGate.requests.cpu=$cpu_requests --set resources.activeGate.requests.memory=$memory_requests --set resources.activeGate.limits.cpu=$cpu_limits --set resources.activeGate.limits.memory=$memory_limits `
          --set resources.oneAgent.requests.cpu=$dyn_pod_res_requests_cpu --set resources.oneAgent.requests.memory=$dyn_pod_res_requests_memory --set resources.oneAgent.limits.cpu=$dyn_pod_res_limits_cpu --set resources.oneAgent.limits.memory=$dyn_pod_res_limits_memory `
          --set owner=$owner_name --set namespace_create=no --set tolerations_set=no . --atomic
        }
      }


      }



    }

  }

}