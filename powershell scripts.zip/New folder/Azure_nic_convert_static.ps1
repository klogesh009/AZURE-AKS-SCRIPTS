﻿$input_csv=Import-Csv -Path "F:\Infra\Scripts\Automation\Inputs\nic_convert_static_input.csv"
$subscription="REBUS_MAYA_CEM_PRODUCTION"

$input_csv | ft

Write-Output "Do you want to change the IP to Static for above? Enter number"
Write-Output "1.Yes`r`n2.No"
$user_input = Read-Host "Option No"
if($user_input -ne "1"){
  exit
}


Select-AzSubscription -Subscription $subscription

function get_azure_resourceID_with_subscription {

  $IP_Address=$args[0]
  $subscription_id_func=$args[1]
  $break=$false
  $resource_ID="NIL"
  
  $subscription_check=Get-AzSubscription | Where-Object {$_.Name -eq $subscription_id_func} 
  if($subscription_check){
    Select-AzSubscription -Subscription $subscription_id_func -ErrorAction Stop | Out-Null
    foreach($NIC in Get-AzNetworkInterface)
    {
        foreach($IP in $NIC.IpConfigurations)
        {
            if ($IP.PrivateIpAddress -eq $IP_Address)
            {
                $resource_ID=$NIC.VirtualMachine.id
                $break=$true
            }
            if($break -eq $true)
            {
                break
            }
        }
        if($break -eq $true)
        {
            break
        }
    }
    Write-Output  "$resource_ID"
  }
  else{
    Write-Output "NIL"
  }
    
}

foreach( $csv_obj in $input_csv ){
  $resource_vm=""
  $vm_obj=""
  $Nic =""
  #$resource_vm = Get-AzResource -Name $csv_obj.vm_name -ResourceType Microsoft.Compute/virtualMachines
  $resource_ID_get= get_azure_resourceID_with_subscription $csv_obj.ips $subscription
  if($resource_vm.count -eq 1){
    $vm_name=$resource_ID_get.Split("/")[-1]
    $vm_rg_name=$resource_ID_get.Split("/")[4]
    $vm_obj=Get-AzVM -ResourceGroupName $vm_rg_name -Name $vm_name
    $Nic = Get-AzNetworkInterface -ResourceGroupName $vm_rg_name -Name $vm_obj.NetworkProfile.NetworkInterfaces.id.Split("/")[-1]
    if( $Nic.IpConfigurations[0].PrivateIpAllocationMethod -match "dynamic" ){
      $Nic.IpConfigurations[0].PrivateIpAllocationMethod = "Static"
      Set-AzNetworkInterface -NetworkInterface $Nic -AsJob
    }
    
  }
  else{
    $vm_name=$csv_obj.vm_name
    "$vm_name not part of subscription $subscription"
  }
}
