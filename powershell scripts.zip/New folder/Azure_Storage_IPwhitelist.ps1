##Inputs
$storage_name="amrbctxiftfestg01"
$storage_rg_name="AM-RB-CTX-IF-TFE-ARG01"
$subscription="REBUS_COMMON_TOOLS"
$input_csv=Import-Csv -Path "F:\Infra\Scripts\Automation\Inputs\Storage_Ipaddress.csv"

$context_account=(Get-AzContext).Account.Id
if($context_account -ne "5035c5b6-a856-4060-88ca-21122c49d5c9"){
    [Byte[]] $key = (1..16)
   $SecurePassword =Get-Content "F:\Infra\Scripts\azure.txt" | ConvertTo-SecureString -Key $key
   $Credential = new-Object System.Management.Automation.PSCredential ("5035c5b6-a856-4060-88ca-21122c49d5c9", $SecurePassword)
   Login-AzAccount -credential   $Credential -ServicePrincipal -TenantId a095b75b-77a2-4e28-afc2-27edd1d6b0ab -Subscription $subscription
}
else{
  Select-AzSubscription -Subscription $subscription
}

####Get the list of Ipaddress or range in storage account
(Get-AzStorageAccountNetworkRuleSet -ResourceGroupName $storage_rg_name -AccountName $storage_name).IPRules

foreach ($ip in $input_csv.ipaddress) {
    $ip
    Add-AzStorageAccountNetworkRule -ResourceGroupName $storage_rg_name -AccountName $storage_name -IPAddressOrRange $ip
}


Logout-AzAccount
