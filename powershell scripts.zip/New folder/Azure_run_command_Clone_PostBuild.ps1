﻿#Import-AzContext -Path F:\Infra\Gowtham\profile.json


$result_jobs = New-Object System.Collections.ArrayList

$vm_inputs_csv = import-csv "F:\Infra\Scripts\Automation\Inputs\clone_postbuild_input.csv"



$deploy = {
   Param($vmname,$rgname,$relay,$subscription,$hgroup)
   $context=(Get-AzContext).Subscription
   if(!$context){
       [Byte[]] $key = (1..16)
       $SecurePassword =Get-Content "F:\Infra\Scripts\azure.txt" | ConvertTo-SecureString -Key $key
       $Credential = new-Object System.Management.Automation.PSCredential ("5035c5b6-a856-4060-88ca-21122c49d5c9", $SecurePassword)
       Login-AzAccount -credential   $Credential -ServicePrincipal -TenantId a095b75b-77a2-4e28-afc2-27edd1d6b0ab -Subscription $subscription
   }
   else{
       Select-AzSubscription -Subscription $subscription
   }
   echo $vmname
   $vm_obj=Get-AzVM -ResourceGroupName $rgname -Name $vmname
   $os_type=$vm_obj.StorageProfile.OsDisk.OsType
   if($hgroup -eq ""){
        $hgroup="NA"
   }
   
   if($os_type -match "linux"){
      $ucd_agent_name="Lin_"+$vm_obj.tags["ENVIRONMENT"]+"_"+$vm_obj.ResourceGroupName
      $ucd_name = $ucd_agent_name -replace "\s",""
      
      echo "Linux"
      Invoke-AzVMRunCommand -ResourceGroupName $rgname -Name $vmname -CommandId 'RunShellScript' -ScriptPath 'F:\Syed\Scripts\templates\Linux\Non-Prod\Run-command\All-Clone-Unix-PostBuild-NonProd.sh' -Parameter @{"UCD_NAME"=$ucd_name;"RELAY"=$relay;"Location"=$vm_obj.Location;"HostGroup"=$hgroup;"vm_hostname"=$vmname}
   }
   elseif($os_type -match "windows"){
      $ucd_agent_name="Win_"+$vm_obj.tags["ENVIRONMENT"]+"_"+$vm_obj.ResourceGroupName
      $ucd_name = $ucd_agent_name -replace "\s",""
      echo "Windows"   
   }
   
    

	
}	  

foreach($vm_input in $vm_inputs_csv){

 $break=$false
 $resource_ID=$null
 $IP_Address=$vm_input.ips


    $vm_input.subscription
    Select-AzSubscription -Subscription $vm_input.subscription
    foreach($NIC in Get-AzNetworkInterface)
    {
        foreach($IP in $NIC.IpConfigurations)
        {
            if ($IP.PrivateIpAddress -eq $IP_Address)
            {
                $resource_ID=$NIC.VirtualMachine.id
                $break=$true
            }
            if($break -eq $true)
            {
                break
            }
        }
        if($break -eq $true)
        {
            break
        }
    }

    $vm_resource=Get-AzResource -ResourceId $resource_ID

   $resource_ID
   if($vm_resource){

    $j = Start-Job -Name $vm_obj.vmname -ScriptBlock $deploy -ArgumentList $vm_resource.Name,$vm_resource.ResourceGroupName,$vm_input.UCD_Relay,$vm_input.subscription,$vm_input.Dynatrace_HostGroup
   }

$result_jobs.Add($j)

}


$jobs = Get-Job
$job_result = New-Object System.Collections.ArrayList
while($jobs | Where-Object {$_.State -eq "Running" })
{
    $jobs_completed = $jobs | Where-Object { $_.State -eq "Completed" -and $_.HasMoreData -match "True"}
    foreach( $job in $jobs_completed ){
      $job_id = $job.Id
      $result_1 = Receive-Job -id $job_id
      if($result_1){
        $job_result.Add($result_1)
        $result_1
      }
   }
}