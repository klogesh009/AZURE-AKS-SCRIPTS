﻿$csv_input= Import-Csv -Path "F:\Infra\Scripts\Automation\Inputs\helm_densify_upgrade_input.csv"

foreach( $aks_obj in $csv_input ){
  $cluster_name=$aks_obj.cluster_name
  $rg_grp=$aks_obj.rg_name
  $subscription=$aks_obj.subscription
  $taints_added=$aks_obj.taints_added

  az account set --s $subscription
  cmd.exe /c "az aks get-credentials --resource-group $rg_grp --name $cluster_name --admin --overwrite-existing"
  $pods_densify=kubectl get pods -n densify
  $pods_densify
  $matched=0
  foreach($pods_densify_obj in $pods_densify ){
    if( $pods_densify_obj -match "densify-forwarder" ){
      $densify_forwarder_pod_name=$pods_densify_obj.Split(" ")[0]
      $densify_forwarder_pod_describe=kubectl describe pod $densify_forwarder_pod_name -n densify      
      foreach($densify_forwarder_pod_describe_obj in $densify_forwarder_pod_describe){
        if($densify_forwarder_pod_describe_obj -match "Image:"){
          $densify_forwarder_pod_describe_obj
        }
      }
      $matched=1
    }
    if($matched -eq 1){
      break
    }
  }

}