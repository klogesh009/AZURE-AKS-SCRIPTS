﻿$context=(Get-AzContext).Subscription
if(!$context){
   [Byte[]] $key = (1..16)
   $SecurePassword =Get-Content "F:\Infra\Scripts\azure_nonprod.txt" | ConvertTo-SecureString -Key $key
   $Credential = new-Object System.Management.Automation.PSCredential ("962a8e28-2e38-486f-aa23-0dd7befe0c53", $SecurePassword)
   Login-AzAccount -credential $Credential -ServicePrincipal -TenantId a095b75b-77a2-4e28-afc2-27edd1d6b0ab -Subscription REBUS_TEST
}
 $console_output=@"
Please input the VM's at F:\Infra\Scripts\VM_Start_Stop\vm_table_input.csv
You want to
1. Enable
2. Disable
"@

echo $console_output
$update_input = Read-Host 'Option ?'

F:\Syed\Scripts\Azure_get_TableScheduleDetails.ps1

$table_details_csv=Import-Csv -Path F:\Infra\Scripts\VM_Start_Stop\VM_ScheduleDetails_start_stop.csv

$vm_input_csv=Import-csv -path F:\Infra\Scripts\VM_Start_Stop\vm_table_input.csv
$updated_table_rows = New-Object System.Collections.ArrayList
$updated_table_rows_notFound_list = New-Object System.Collections.ArrayList

$sub_previous=""

foreach($vm in $vm_input_csv){
    $table_vms=$table_details_csv | where-object {$_.VmName -eq $vm.VMName.Trim()}
    if($table_vms -eq $null){
        $temp_output=$vm.VMName+"   "+"Not Found"
        $updated_table_rows_notFound_list.Add($temp_output)
    }
    else{
     foreach($table_vm in $table_vms){
       $Ctx=""
       $table = ""
       $vm_table_row=""
       if($table_vm.sub_id -ne $sub_previous){
         Select-AzSubscription -Subscription $table_vm.sub_id
         $sub_previous=$table_vm.sub_id
       }
       $Ctx=(Get-AzStorageAccount -ResourceGroupName $table_vm.stg_rg -Name $table_vm.stg).Context
       $table = Get-AzStorageTable -Context $Ctx –Name $table_vm.table_name
       $cloudTable = (Get-AzStorageTable –Name $table_vm.table_name –Context $Ctx).CloudTable
       $vm_table_row=Get-AzTableRow -table $cloudTable -columnName "VMName" -value $table_vm.VMName -operator Equal
 #      $vm_table_row=Get-AzStorageTableRowByColumnName -table $table -columnName "VMName" -value $table_vm.VMName -operator Equal
       if($update_input -eq 2){
            if($vm_table_row.ScheduleGroup -notmatch "disable"){
                $vm_table_row.ScheduleGroup+="-disable"
                $vm_table_row | Update-AzTableRow -table $cloudTable
            }            
       }
       elseif($update_input -eq 1){
            if($vm_table_row.ScheduleGroup -match "disable"){
                $schedule_group=$vm_table_row.ScheduleGroup
                $vm_table_row.ScheduleGroup=$schedule_group.split("-")[0].Trim()
                $output_update=$vm_table_row | Update-AzTableRow -table $cloudTable
            }
            
       }
       $vm_table_row_updated=Get-AzTableRow -table $cloudTable -columnName "VMName" -value $table_vm.VMName -operator Equal
#       $vm_table_row_updated=Get-AzureStorageTableRowByColumnName -table $table -columnName "VMName" -value $table_vm.VMName -operator Equal
       $updated_table_rows.Add($vm_table_row_updated)
     }

    }

}

 $updated_table_rows | Format-Table
 $updated_table_rows_notFound_list